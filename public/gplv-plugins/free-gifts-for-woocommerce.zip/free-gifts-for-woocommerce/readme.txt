=== Free Gifts for WooCommerce ===	 		     	 	       
Contributors: Flintop    	     		   	 	   
Tags: woocommerce free gifts, free gifts plugin, gift plugin
Requires at least: 4.6.0
Tested up to: 6.2.2
Tested up to WC: 7.8.0
Requires PHP: 5.6.0
Stable tag: 10.0.0
