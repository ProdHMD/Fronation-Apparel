<?php
/**
 * Privacy handler class file.
 *
 * @package WC_Shipping_Fedex
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Abstract_Privacy' ) ) {
	return;
}

/**
 * Privacy handler class.
 */
class WC_Fedex_Privacy extends WC_Abstract_Privacy {
	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct( __( 'Fedex', 'woocommerce-shipping-fedex' ) );
	}

	/**
	 * Gets the message of the privacy to display.
	 */
	public function get_privacy_message() {
		// translators: %s is plugin documentation URL.
		return wpautop( sprintf( __( 'By using this extension, you may be storing personal data or sharing data with an external service. <a href="%s" target="_blank">Learn more about how this works, including what you may want to include in your privacy policy.</a>', 'woocommerce-shipping-fedex' ), 'https://docs.woocommerce.com/document/privacy-shipping/#woocommerce-shipping-fedex' ) );
	}
}

new WC_Fedex_Privacy();
