<?php
/**
 * WooCommerce Admin inbox note: FedEx Freight needs its own API credentials.
 *
 * @package WC_Shipping_Fedex
 */

defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Admin\Notes\Note;
use Automattic\WooCommerce\Admin\Notes\NoteTraits;

/**
 * The durable half of the freight-credentials signal.
 *
 * The admin notice interrupts and can be dismissed; this note persists in the inbox until the
 * credentials are entered, at which point WC_Shipping_Fedex_Init deletes it outright. Deleting
 * rather than actioning matters: NoteTraits::possibly_add_note() refuses to re-add a note whose
 * name still exists in any state, so removing the row is what lets the note come back if the
 * credentials are ever cleared again.
 *
 * @since 4.8.1
 */
class WC_Fedex_Note_Freight_Credentials {

	use NoteTraits;

	/**
	 * Name of the note in the database.
	 *
	 * Public surface: renaming it orphans every existing note and re-notifies every merchant.
	 *
	 * @var string
	 */
	const NOTE_NAME = 'wc-shipping-fedex-freight-credentials';

	/**
	 * Build the note.
	 *
	 * @return Note
	 */
	public static function get_note() {
		$note = new Note();

		$note->set_title( __( 'FedEx Freight rates need separate API credentials', 'woocommerce-shipping-fedex' ) );
		$note->set_content(
			__( 'FedEx moved LTL rating onto its own platform, which needs its own API credentials. Until you add them, your store returns no FedEx Freight rates for the US, Canada or Puerto Rico. Create a project at developer.fedexfreight.com, then enter the key and secret in your FedEx shipping settings.', 'woocommerce-shipping-fedex' )
		);
		$note->set_type( Note::E_WC_ADMIN_NOTE_WARNING );
		$note->set_name( self::NOTE_NAME );
		$note->set_source( 'woocommerce-shipping-fedex' );
		$note->add_action(
			'fedex-freight-credentials',
			__( 'Add FedEx Freight credentials', 'woocommerce-shipping-fedex' ),
			WC_Shipping_Fedex_Init::get_freight_settings_url(),
			Note::E_WC_ADMIN_NOTE_UNACTIONED
		);

		return $note;
	}
}
