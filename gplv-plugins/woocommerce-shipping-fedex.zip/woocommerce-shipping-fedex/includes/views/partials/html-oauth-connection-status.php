<?php
/**
 * Shared markup for an OAuth connection status row.
 *
 * Not loaded through wc_get_template() — it is required by ../html-oauth-status.php and
 * ../html-freight-oauth-status.php, which are the per-connection templates a store can override.
 * A theme copy of this file is never picked up, because nothing loads it through
 * wc_get_template().
 *
 * @var WC_Shipping_Fedex $shipping_method  The FedEx shipping method instance.
 * @var string            $field_key        The field key.
 * @var array             $data             The field data.
 * @var string            $row_id           The table row id.
 * @var string            $connection_label Human-readable connection name (e.g. "FedEx REST API").
 * @var bool              $has_credentials  Whether credentials are configured for this connection.
 * @var bool              $is_authenticated Whether this connection is currently authenticated.
 * @var string            $failure_hint     What to check when this connection cannot authenticate.
 *
 * @package WC_Shipping_Fedex
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $field_key ) || empty( $data ) || ! $shipping_method instanceof WC_Shipping_Fedex ) {
	return;
}
?>
<tr valign="top" id="<?php echo esc_attr( $row_id ); ?>">
	<th scope="row" class="titledesc">
		<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?><?php echo $shipping_method->get_tooltip_html( $data ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></label>
	</th>
	<td class="forminp">
		<div <?php echo $shipping_method->get_custom_attribute_html( $data ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
			<?php if ( $is_authenticated ) : ?>
				<p class="fedex-oauth-status-success">
					<span class="dashicons dashicons-yes-alt fedex-oauth-status-icon"></span>
					<?php esc_html_e( 'Authenticated', 'woocommerce-shipping-fedex' ); ?>
				</p>
				<p class="fedex-oauth-status-description">
					<?php
					printf(
						/* translators: %s: connection name, e.g. "FedEx REST API" */
						esc_html__( 'Your %s connection is working correctly.', 'woocommerce-shipping-fedex' ),
						esc_html( $connection_label )
					);
					?>
				</p>
			<?php elseif ( $has_credentials ) : ?>
				<p class="fedex-oauth-status-error">
					<span class="dashicons dashicons-warning fedex-oauth-status-icon"></span>
					<?php esc_html_e( 'Authentication failed', 'woocommerce-shipping-fedex' ); ?>
				</p>
				<p class="fedex-oauth-status-error-detail">
					<?php
					printf(
						/* translators: %1$s: connection name, e.g. "FedEx REST API". %2$s: what to check next. */
						esc_html__( 'Unable to authenticate with %1$s. %2$s', 'woocommerce-shipping-fedex' ),
						esc_html( $connection_label ),
						esc_html( $failure_hint )
					);
					?>
				</p>
				<p class="fedex-oauth-status-description">
					<?php
					printf(
						/* translators: %s: WooCommerce logs URL */
						esc_html__( 'Check the %s for detailed error information.', 'woocommerce-shipping-fedex' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=wc-status&tab=logs' ) ) . '" target="_blank">' . esc_html__( 'WooCommerce logs', 'woocommerce-shipping-fedex' ) . '</a>'
					);
					?>
				</p>
			<?php else : ?>
				<p class="fedex-oauth-status-error">
					<span class="dashicons dashicons-dismiss fedex-oauth-status-icon"></span>
					<?php esc_html_e( 'Not authenticated', 'woocommerce-shipping-fedex' ); ?>
				</p>
				<p class="fedex-oauth-status-description">
					<?php
					printf(
						/* translators: %s: connection name, e.g. "FedEx REST API" */
						esc_html__( 'Enter your %s key and secret and click "Save changes".', 'woocommerce-shipping-fedex' ),
						esc_html( $connection_label )
					);
					?>
				</p>
			<?php endif; ?>
		</div>
	</td>
</tr>
