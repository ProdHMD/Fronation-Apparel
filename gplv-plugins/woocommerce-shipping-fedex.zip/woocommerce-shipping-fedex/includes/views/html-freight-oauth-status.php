<?php
/**
 * FedEx Freight API OAuth status row.
 *
 * Thin wrapper around the shared markup in partials/html-oauth-connection-status.php. Parcel and
 * freight each get their own template name so a store can override one row without affecting
 * the other.
 *
 * @var WC_Shipping_Fedex $shipping_method  The FedEx shipping method instance.
 * @var string            $field_key        The field key.
 * @var array             $data             The field data.
 * @var string            $row_id           The table row id.
 * @var string            $connection_label Human-readable connection name.
 * @var bool              $has_credentials  Whether credentials are configured for this connection.
 * @var bool              $is_authenticated Whether this connection is currently authenticated.
 *
 * @package WC_Shipping_Fedex
 */

defined( 'ABSPATH' ) || exit;

// Absolute, not __DIR__: wc_get_template() loads a theme's copy of this file when one exists,
// and __DIR__ would then resolve to the theme, where the partial does not exist — a fatal
// inside ob_start(), white-screening the settings page. The partial itself is never
// resolved through wc_get_template(), so a theme copy of it is never picked up.
require WC_SHIPPING_FEDEX_ABSPATH . 'includes/views/partials/html-oauth-connection-status.php';
