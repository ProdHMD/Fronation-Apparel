<?php
/**
 * Main plugin class file.
 *
 * @package WC_Shipping_Fedex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/trait-util.php';
require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-logger.php';

use WooCommerce\FedEx\Util;
use WooCommerce\FedEx\Logger;

/**
 * Main plugin class.
 */
class WC_Shipping_Fedex_Init {

	use Util;

	/**
	 * Plugin's version.
	 *
	 * @var string
	 * @since 3.4.0
	 */
	public $version;

	/**
	 * Class instance.
	 *
	 * @var object
	 */
	private static $instance;

	/**
	 * WC_Admin_Notices name for the freight credentials notice.
	 *
	 * Public surface: this composes the dismissal hook
	 * `woocommerce_hide_fedex_freight_credentials_notice` and the storage option
	 * `woocommerce_admin_notice_fedex_freight_credentials`. Renaming it strands both.
	 *
	 * @var string
	 * @since 4.8.1
	 */
	const FREIGHT_NOTICE_NAME = 'fedex_freight_credentials';

	/**
	 * Option recording that the freight credentials signals are currently out.
	 *
	 * Lets the evaluator touch the Notes API only on transitions rather than on every admin
	 * page load, since each note call costs a database query. It is also what the teardown keys
	 * off, so it is written whenever the signals go out — see FREIGHT_SIGNALS_STATE_NOTICE_ONLY
	 * for the case where only one of the two made it.
	 *
	 * @var string
	 * @since 4.8.1
	 */
	const FREIGHT_SIGNALS_ACTIVE_OPTION = 'woocommerce_fedex_freight_signals_active';

	/**
	 * FREIGHT_SIGNALS_ACTIVE_OPTION value meaning both signals are in place.
	 *
	 * @var string
	 * @since 4.8.1
	 */
	const FREIGHT_SIGNALS_STATE_ACTIVE = 'yes';

	/**
	 * FREIGHT_SIGNALS_ACTIVE_OPTION value meaning the notice is out but the inbox note is not.
	 *
	 * The Notes API can be unavailable at the moment the signals go out. Recording that separately
	 * keeps the teardown working — it only needs to know the signals are out at all — while still
	 * letting the next admin_init retry the note.
	 *
	 * @var string
	 * @since 4.8.1
	 */
	const FREIGHT_SIGNALS_STATE_NOTICE_ONLY = 'notice-only';

	/**
	 * The 4.8.0 dismissal flag, migrated to FREIGHT_NOTICE_DISMISSED_AT_OPTION and then deleted.
	 *
	 * @var string
	 * @since 4.8.1
	 */
	const FREIGHT_LEGACY_DISMISSED_OPTION = 'woocommerce_fedex_dismissed_freight_credentials_notice';

	/**
	 * Option holding the timestamp of the last freight notice dismissal.
	 *
	 * @var string
	 * @since 4.8.1
	 */
	const FREIGHT_NOTICE_DISMISSED_AT_OPTION = 'woocommerce_fedex_freight_credentials_notice_dismissed_at';

	/**
	 * Get the class instance.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Initialize the plugin's public actions.
	 */
	public function __construct() {
		$this->version  = WC_SHIPPING_FEDEX_VERSION;
		$fedex_settings = get_option( 'woocommerce_fedex_settings', array() );

		if ( ! class_exists( 'WC_Shipping_Method' ) ) {
			add_action( 'admin_notices', array( $this, 'wc_deactivated' ) );
			return;
		}

		add_action( 'admin_init', array( $this, 'maybe_install' ), 5 );
		add_action( 'init', array( $this, 'load_textdomain' ) );
		add_action( 'before_woocommerce_init', array( $this, 'declare_hpos_compatibility' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( WC_SHIPPING_FEDEX_FILE ), array( $this, 'plugin_links' ) );
		add_action( 'woocommerce_shipping_init', array( $this, 'includes' ) );
		add_filter( 'woocommerce_shipping_methods', array( $this, 'add_method' ) );
		add_action( 'admin_notices', array( $this, 'environment_check' ) );
		add_action( 'admin_notices', array( $this, 'upgrade_notice' ) );
		add_action( 'wp_ajax_fedex_dismiss_upgrade_notice', array( $this, 'dismiss_upgrade_notice' ) );
		add_action( 'admin_init', array( $this, 'maybe_migrate_soap' ), 6 );
		add_action( 'admin_notices', array( $this, 'soap_retired_notice' ) );
		add_action( 'wp_ajax_fedex_dismiss_soap_retired_notice', array( $this, 'dismiss_soap_retired_notice' ) );
		// Priority 30: WC_Admin_Notices::hide_notices() runs at 20, so a dismissal made in this
		// request is recorded before we decide whether to re-add the notice.
		add_action( 'admin_init', array( $this, 'sync_freight_credentials_signals' ), 30 );
		add_action( 'woocommerce_hide_' . self::FREIGHT_NOTICE_NAME . '_notice', array( $this, 'record_freight_notice_dismissal' ) );
		add_action( 'wp_ajax_fedex_dismiss_freight_credentials_notice', array( $this, 'dismiss_freight_credentials_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		// Registered here (rather than at the top of the main plugin file) because it must run
		// after WC_SHIPPING_FEDEX_FILE is defined and only while WooCommerce is present; this
		// constructor already returns early above when WC_Shipping_Method is missing.
		register_deactivation_hook( WC_SHIPPING_FEDEX_FILE, array( $this, 'deactivate' ) );

		$this->init_abilities();

		if ( isset( $fedex_settings['freight_enabled'] ) && 'yes' === $fedex_settings['freight_enabled'] ) {
			// Make the city field show in the calculator (for freight).
			add_filter( 'woocommerce_shipping_calculator_enable_city', '__return_true' );

			// Add freight class option for shipping classes (for freight).
			if ( is_admin() ) {
				include WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-fedex-freight-mapping.php';
			}
		}

		if ( is_admin() ) {
			include_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-shipping-fedex-admin.php';
		}
	}

	/**
	 * Initialize WordPress Abilities API definitions.
	 *
	 * @return void
	 */
	private function init_abilities() {
		if ( ! interface_exists( '\Automattic\WooCommerce\Abilities\AbilityDefinition' ) ) {
			return;
		}

		require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/abilities/class-wc-shipping-fedex-abilities.php';
		WC_Shipping_Fedex_Abilities::init();
	}

	/**
	 * Load the freight credentials inbox note class.
	 *
	 * WC Admin can be disabled, in which case the Notes API is absent and the admin notice is
	 * the only signal. There is no autoloader for plugin classes, so this require is the only
	 * thing that makes the class exist.
	 *
	 * @return bool Whether the note class is available.
	 *
	 * @since 4.8.1
	 */
	private function load_freight_credentials_note() {
		if ( ! trait_exists( '\Automattic\WooCommerce\Admin\Notes\NoteTraits' ) ) {
			return false;
		}

		if ( ! class_exists( 'WC_Fedex_Note_Freight_Credentials' ) ) {
			require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/notes/class-wc-fedex-note-freight-credentials.php';
		}

		return true;
	}

	/**
	 * URL of the plugin-wide FedEx settings screen.
	 *
	 * The section=fedex query arg is required: the freight credential fields live on the
	 * plugin-wide FedEx screen, not the shipping zones list, and both freight signals exist to
	 * send merchants there.
	 *
	 * @return string
	 *
	 * @since 4.8.1
	 */
	public static function get_freight_settings_url(): string {
		return add_query_arg(
			array(
				'page'    => 'wc-settings',
				'tab'     => 'shipping',
				'section' => 'fedex',
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Environment check function.
	 */
	public function environment_check() {

		$messages = array();

		/**
		 * Allow third party to hide the check store currency debug text.
		 *
		 * @param boolean $check_flag Flag for hide or display the debug text.
		 *
		 * @since 3.4.30
		 */
		if ( apply_filters( 'woocommerce_shipping_fedex_check_store_currency', true ) && ! in_array( get_woocommerce_currency(), array( 'USD', 'CAD' ), true ) ) {
			$messages[] = esc_html__( 'WooCommerce currency is set to US Dollars or CA Dollars', 'woocommerce-shipping-fedex' );
		}

		// Country check.
		if ( ! in_array( $this->get_base_country(), array( 'US', 'CA' ), true ) ) {
			$messages[] = esc_html__( 'Base country/region is set to United States or Canada', 'woocommerce-shipping-fedex' );
		}

		if ( ! empty( $messages ) ) {
			// translators: %s is messages.
			$prefix    = __( 'FedEx requires that %s', 'woocommerce-shipping-fedex' );
			$separator = __( ' and ', 'woocommerce-shipping-fedex' );

			echo '<div class="error">
				<p>' . esc_html( sprintf( $prefix, implode( $separator, $messages ) ) ) . '</p>
			</div>';
		}
	}

	/**
	 * Enqueue admin scripts.
	 *
	 * @return void
	 * @version 3.4.0
	 * @since   3.4.0
	 */
	public function enqueue_admin_scripts() {

		$screen    = get_current_screen();
		$screen_id = ( $screen instanceof WP_Screen && ! empty( $screen->id ) ) ? $screen->id : '';

		if ( 'woocommerce_page_wc-settings' !== $screen_id ) {
			return;
		}

		// Register scripts.
		wp_register_script( 'fedex-admin-instance-js', plugin_dir_url( WC_SHIPPING_FEDEX_FILE ) . 'assets/js/admin-instance.js', array( 'jquery' ), WC_SHIPPING_FEDEX_VERSION, true );
		wp_enqueue_style( 'fedex-admin', plugin_dir_url( WC_SHIPPING_FEDEX_FILE ) . 'assets/css/admin.css', array(), WC_SHIPPING_FEDEX_VERSION );

		// Enqueue scripts.
		wp_enqueue_script( 'jquery-ui-sortable' );

		if ( isset( $_GET['instance_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended --- We are just checking if the instance_id parameter is set.
			wp_enqueue_script( 'fedex-admin-instance-js' );
		}
	}

	/**
	 * Load includes.
	 *
	 * @return void
	 * @version 3.4.0
	 * @since   3.4.0
	 */
	public function includes() {
		include_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-fedex-privacy.php';
		include_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-shipping-fedex.php';
	}

	/**
	 * Add Fedex shipping method to WC.
	 *
	 * @param mixed $methods Shipping methods.
	 *
	 * @return array
	 */
	public function add_method( $methods ) {
		$methods['fedex'] = 'WC_Shipping_Fedex';

		return $methods;
	}

	/**
	 * Localisation.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'woocommerce-shipping-fedex', false, dirname( plugin_basename( WC_SHIPPING_FEDEX_FILE ) ) . '/languages/' );
	}

	/**
	 * Declare High-Performance Order Storage (HPOS) compatibility
	 *
	 * @see https://github.com/woocommerce/woocommerce/wiki/High-Performance-Order-Storage-Upgrade-Recipe-Book#declaring-extension-incompatibility
	 *
	 * @return void
	 */
	public function declare_hpos_compatibility() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', 'woocommerce-shipping-fedex/woocommerce-shipping-fedex.php' );
		}
	}

	/**
	 * Plugin page links.
	 *
	 * @param array $links Plugin action links.
	 *
	 * @return array Plugin action links.
	 * @version 3.4.9
	 */
	public function plugin_links( $links ) {
		$plugin_links = array(
			'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=shipping&section=fedex' ) . '">' . __( 'Settings', 'woocommerce-shipping-fedex' ) . '</a>',
			'<a href="https://support.woocommerce.com/">' . __( 'Support', 'woocommerce-shipping-fedex' ) . '</a>',
			'<a href="https://docs.woocommerce.com/document/fedex/">' . __( 'Docs', 'woocommerce-shipping-fedex' ) . '</a>',
		);

		return array_merge( $plugin_links, $links );
	}

	/**
	 * WooCommerce not installed notice.
	 */
	public function wc_deactivated() {
		/* translators: %s: WooCommerce link */
		echo '<div class="error"><p>' . sprintf( esc_html__( 'WooCommerce FedEx Shipping requires %s to be installed and active.', 'woocommerce-shipping-fedex' ), '<a href="https://woocommerce.com" target="_blank">WooCommerce</a>' ) . '</p></div>';
	}

	/**
	 * See if we need to install any upgrades
	 * and call the install.
	 *
	 * @version 3.4.0
	 * @since   3.4.0
	 */
	public function maybe_install() {
		// Only need to do this for versions less than 3.4.0 to migrate
		// settings to shipping zone instance.
		if ( ! defined( 'DOING_AJAX' ) && ! defined( 'IFRAME_REQUEST' ) && version_compare( get_option( 'wc_fedex_version' ), '3.4.0', '<' ) ) {

			$this->install();
		}
	}

	/**
	 * Update/migration script.
	 *
	 * @since   3.4.0
	 * @version 3.4.0
	 */
	public function install() {
		// Get all saved settings and cache it.
		$fedex_settings = get_option( 'woocommerce_fedex_settings', false );

		// Settings exists.
		if ( $fedex_settings ) {
			global $wpdb;

			// Unset un-needed settings.
			unset( $fedex_settings['enabled'] );
			unset( $fedex_settings['availability'] );
			unset( $fedex_settings['countries'] );

			// Add it to the "rest of the world" zone when no fedex.
			if ( ! $this->is_zone_has_fedex( 0 ) ) {
				$wpdb->query( $wpdb->prepare( "INSERT INTO {$wpdb->prefix}woocommerce_shipping_zone_methods ( zone_id, method_id, method_order, is_enabled ) VALUES ( %d, %s, %d, %d )", 0, 'fedex', 1, 1 ) );
				// Add settings to the newly created instance to options table.
				$instance = $wpdb->insert_id;
				add_option( 'woocommerce_fedex_' . $instance . '_settings', $fedex_settings );
			}

			update_option( 'woocommerce_fedex_show_upgrade_notice', 'yes' );
		}

		update_option( 'wc_fedex_version', $this->version );
	}

	/**
	 * Show the user a notice for plugin updates.
	 *
	 * @since 3.4.0
	 */
	public function upgrade_notice() {
		$show_notice = get_option( 'woocommerce_fedex_show_upgrade_notice' );

		if ( 'yes' !== $show_notice ) {
			return;
		}

		$query_args      = array(
			'page' => 'wc-settings',
			'tab'  => 'shipping',
		);
		$zones_admin_url = add_query_arg( $query_args, get_admin_url() . 'admin.php' );
		?>
		<div class="notice notice-success is-dismissible wc-fedex-notice">
			<p>
				<?php
				/* translators: %1$s: Shipping zones link start, %2$s: Link end */
				printf( esc_html__( 'FedEx now supports shipping zones. The zone settings were added to a new FedEx method on the "Rest of the World" Zone. See the zones %1$shere%2$s ', 'woocommerce-shipping-fedex' ), '<a href="' . esc_url( $zones_admin_url ) . '">', '</a>' );
				?>
			</p>
		</div>

		<script type="application/javascript">
			// jQuery.post over ajaxurl rather than wp.ajax: wp-util is not enqueued on every admin
			// screen, and enqueuing it from admin_notices lands in the footer, after this runs.
			jQuery( '.notice.wc-fedex-notice' ).on( 'click', '.notice-dismiss', function() {
				jQuery.post( ajaxurl, { action: 'fedex_dismiss_upgrade_notice' } );
			} );
		</script>
		<?php
	}

	/**
	 * Turn of the dismissible upgrade notice.
	 *
	 * @since 3.4.0
	 */
	public function dismiss_upgrade_notice() {
		update_option( 'woocommerce_fedex_show_upgrade_notice', 'no' );
	}

	/**
	 * One-time migration: FedEx retired the SOAP (Web Services) API on 2026-06-01.
	 * Force any store still on `api_type = soap` onto REST and flag a notice.
	 *
	 * @return void
	 */
	public function maybe_migrate_soap() {
		if ( wp_doing_ajax() || ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			return;
		}

		$fedex_settings = get_option( 'woocommerce_fedex_settings', array() );

		if ( ! is_array( $fedex_settings ) ) {
			return;
		}

		$api_type = isset( $fedex_settings['api_type'] ) ? $fedex_settings['api_type'] : '';

		// Stores set up before the REST API was introduced never persisted `api_type`.
		// For those, a stored Web Services key is what marked them as running on SOAP.
		$is_soap = 'soap' === $api_type || ( '' === $api_type && ! empty( $fedex_settings['api_key'] ) );

		if ( ! $is_soap ) {
			return;
		}

		$fedex_settings['api_type'] = 'rest';
		update_option( 'woocommerce_fedex_settings', $fedex_settings );
		update_option( 'woocommerce_fedex_show_soap_retired_notice', 'yes' );
	}

	/**
	 * Show the one-time notice after a SOAP store is migrated to REST.
	 *
	 * @return void
	 */
	public function soap_retired_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			return;
		}

		if ( 'yes' !== get_option( 'woocommerce_fedex_show_soap_retired_notice' ) ) {
			return;
		}

		$settings_url = add_query_arg(
			array(
				'page'    => 'wc-settings',
				'tab'     => 'shipping',
				'section' => 'fedex',
			),
			get_admin_url() . 'admin.php'
		);
		?>
		<div class="notice notice-error is-dismissible wc-fedex-soap-retired-notice">
			<p>
				<?php
				/* translators: %1$s: FedEx settings link start, %2$s: link end */
				printf( esc_html__( 'FedEx retired the SOAP (Web Services) API on June 1, 2026. Your store has been switched to the REST API — please enter your REST API Key & Secret in the %1$sFedEx settings%2$s to continue receiving rates.', 'woocommerce-shipping-fedex' ), '<a href="' . esc_url( $settings_url ) . '">', '</a>' );
				?>
			</p>
		</div>

		<script type="application/javascript">
			// jQuery.post over ajaxurl rather than wp.ajax: wp-util is not enqueued on every admin
			// screen, and enqueuing it from admin_notices lands in the footer, after this runs.
			jQuery( '.notice.wc-fedex-soap-retired-notice' ).on( 'click', '.notice-dismiss', function() {
				jQuery.post( ajaxurl, {
					action: 'fedex_dismiss_soap_retired_notice',
					_ajax_nonce: '<?php echo esc_js( wp_create_nonce( 'fedex_dismiss_soap_retired_notice' ) ); ?>'
				} );
			} );
		</script>
		<?php
	}

	/**
	 * Dismiss the SOAP-retired notice.
	 *
	 * @return void
	 */
	public function dismiss_soap_retired_notice() {
		check_ajax_referer( 'fedex_dismiss_soap_retired_notice' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			wp_send_json_error( null, 403 );
		}

		update_option( 'woocommerce_fedex_show_soap_retired_notice', 'no' );

		wp_send_json_success();
	}

	/**
	 * Whether freight is enabled but the FedEx Freight credentials are missing.
	 *
	 * Freight is configured on the plugin-wide FedEx settings screen, not per shipping zone —
	 * its fields live in `form_fields`, not `instance_form_fields`, so they are stored in
	 * `woocommerce_fedex_settings` and read from there by `WC_Shipping_Method::get_option()`.
	 *
	 * @return bool
	 *
	 * @since 4.8.0
	 */
	private function has_freight_without_credentials() {
		$settings = get_option( 'woocommerce_fedex_settings', array() );

		if ( ! is_array( $settings ) || ! isset( $settings['freight_enabled'] ) || 'yes' !== $settings['freight_enabled'] ) {
			return false;
		}

		return empty( $settings['freight_client_id'] ) || empty( $settings['freight_client_secret'] );
	}

	/**
	 * Names of the shipping zones where a FedEx instance has a freight service enabled.
	 *
	 * The rate path only asks the freight platform for rates when a freight service is enabled
	 * on the instance, so the credentials signals must stay quiet for stores that never request
	 * one.
	 *
	 * Every code in data-freight-services.php counts, including the INTERNATIONAL_ ones. The
	 * platform is chosen by destination, not by service: calculate_shipping() sends US, CA and
	 * PR to the LTL platform and everything else to the parcel endpoint, so a store offering
	 * only INTERNATIONAL_PRIORITY_FREIGHT still needs freight credentials the moment it quotes
	 * a US address. Narrowing this list by service code would leave that store unwarned while
	 * its freight requests were skipped.
	 *
	 * The list is therefore "zones with a freight service enabled", not "zones that are broken":
	 * a zone whose locations can never match US, CA or PR routes to the parcel endpoint as an
	 * 'international_freight' request and is unaffected, but it is still listed here. Zone
	 * locations are not consulted on purpose — over-listing costs a merchant nothing, whereas any
	 * hole in that logic would silently leave a genuinely broken store unwarned, which is the
	 * failure this whole signal exists to prevent. The message is worded to match: it names where
	 * freight is enabled, and states the lost destinations separately.
	 *
	 * Reads through the shipping-zone data store rather than WC_Shipping_Zones::get_zones().
	 * That helper resolves every method in every zone into an object, and
	 * WC_Shipping_Zone::get_shipping_methods() then calls get_admin_options_html() on each one
	 * declaring 'instance-settings-modal' — core's flat rate, free shipping and local pickup all
	 * do — so it would build and discard their entire settings markup on every admin screen. The
	 * 'json' context does not help: that markup is built before the context is consulted.
	 *
	 * WC_Data_Store::load( 'shipping-zone' ) exposes the two reads underneath that helper —
	 * get_zones() and get_methods(), both on WC_Shipping_Zone_Data_Store_Interface — which return
	 * raw rows and instantiate nothing. The cost is one query per zone rather than one overall,
	 * paid only on stores that already have freight enabled with no credentials.
	 *
	 * @return array List of zone names. Empty when no zone offers a freight service.
	 *
	 * @since 4.8.0
	 */
	private function get_freight_enabled_zone_names() {
		try {
			$data_store = WC_Data_Store::load( 'shipping-zone' );
		} catch ( Throwable $e ) {
			Logger::debug( 'Could not load the shipping zone data store: ' . $e->getMessage() );

			return array();
		}

		// WC_Data_Store forwards these two through __call() and returns null in silence when the
		// underlying store does not implement them, which a third party swapping the store through
		// the 'woocommerce_data_stores' filter can cause. Check before relying on either.
		if ( ! $data_store->has_callable( 'get_zones' ) || ! $data_store->has_callable( 'get_methods' ) ) {
			Logger::debug( 'The shipping zone data store does not expose get_zones() or get_methods().' );

			return array();
		}

		$zones            = $data_store->get_zones(); // @phpstan-ignore method.notFound (Guarded by has_callable() and called via __call() on the underlying shipping zone data store instance.)
		$zone_names_by_id = array();

		// get_zones() is already ordered by zone_order then zone_id.
		foreach ( is_array( $zones ) ? $zones : array() as $zone ) {
			$zone_names_by_id[ absint( $zone->zone_id ) ] = $zone->zone_name;
		}

		// Zone 0 is the catch-all and has no row of its own. It goes last so that, once the
		// display list is capped, the merchant's own zone names are what survives.
		$zone_names_by_id[0] = __( 'Locations not covered by your other zones', 'woocommerce-shipping-fedex' );

		$freight_services = include WC_SHIPPING_FEDEX_ABSPATH . 'includes/data/data-freight-services.php';
		$zone_names       = array();

		foreach ( $zone_names_by_id as $zone_id => $zone_name ) {
			try {
				$methods = $data_store->get_methods( $zone_id, true ); // @phpstan-ignore method.notFound (Guarded by has_callable() and called via __call() on the underlying shipping zone data store instance.)
			} catch ( Throwable $e ) {
				Logger::debug( 'Could not read the shipping methods for zone ' . $zone_id . ': ' . $e->getMessage() );

				continue;
			}

			foreach ( is_array( $methods ) ? $methods : array() as $method ) {
				if ( 'fedex' !== $method->method_id
					|| ! $this->instance_has_freight_service( $method->instance_id, $freight_services ) ) {
					continue;
				}

				$zone_names[] = $zone_name;

				// One entry per zone, however many FedEx instances it holds.
				break;
			}
		}

		return $zone_names;
	}

	/**
	 * Whether a FedEx method instance offers at least one freight service.
	 *
	 * @param int   $instance_id      Shipping method instance ID.
	 * @param array $freight_services Service codes from data-freight-services.php.
	 *
	 * @return bool
	 *
	 * @since 4.8.1
	 */
	private function instance_has_freight_service( $instance_id, array $freight_services ) {
		$settings = get_option( 'woocommerce_fedex_' . absint( $instance_id ) . '_settings' );

		if ( ! is_array( $settings ) || empty( $settings['services'] ) || ! is_array( $settings['services'] ) ) {
			return false;
		}

		foreach ( $freight_services as $service ) {
			if ( ! empty( $settings['services'][ $service ]['enabled'] ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Format zone names for display in the credentials message.
	 *
	 * Capped so a store with a dozen freight-enabled zones does not get an unreadable banner.
	 *
	 * @param array $zone_names Zone names from get_freight_enabled_zone_names().
	 *
	 * @return string
	 *
	 * @since 4.8.1
	 */
	private function format_freight_zone_names( array $zone_names ) {
		$shown = array_slice( $zone_names, 0, 3 );
		$more  = count( $zone_names ) - count( $shown );
		$list  = implode( ', ', $shown );

		if ( $more < 1 ) {
			return $list;
		}

		return sprintf(
			/* translators: %1$s: comma-separated list of shipping zone names, %2$d: number of further zones. */
			_n( '%1$s and %2$d more', '%1$s and %2$d more', $more, 'woocommerce-shipping-fedex' ),
			$list,
			$more
		);
	}

	/**
	 * Keep the freight credentials signals in step with the store's configuration.
	 *
	 * Runs on admin_init, which is after WooCommerce saves settings on wp_loaded
	 * (WC_Admin_Menus::save_settings()). The first evaluation after a save therefore already
	 * sees the new credentials, which is what clears both signals without a save hook.
	 *
	 * @return void
	 *
	 * @since 4.8.1
	 */
	public function sync_freight_credentials_signals() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			return;
		}

		if ( ! class_exists( 'WC_Admin_Notices' ) ) {
			return;
		}

		$zone_names = $this->has_freight_without_credentials() ? $this->get_freight_enabled_zone_names() : array();
		$affected   = ! empty( $zone_names );

		$this->migrate_legacy_freight_notice_dismissal( $affected );

		if ( ! $affected ) {
			$this->clear_freight_credentials_signals();

			return;
		}

		// STATE_NOTICE_ONLY rather than STATE_ACTIVE records that the notice is out but the inbox
		// note is not, so the next admin_init retries the note. What must not happen is leaving the
		// state unset because the note failed: the teardown below keys off this option, so an unset
		// state strands the banner on a store whose credentials are fine.
		if ( self::FREIGHT_SIGNALS_STATE_ACTIVE !== get_option( self::FREIGHT_SIGNALS_ACTIVE_OPTION ) ) {
			update_option(
				self::FREIGHT_SIGNALS_ACTIVE_OPTION,
				$this->add_freight_credentials_note() ? self::FREIGHT_SIGNALS_STATE_ACTIVE : self::FREIGHT_SIGNALS_STATE_NOTICE_ONLY
			);
		}

		$this->maybe_add_freight_credentials_notice( $zone_names );
	}

	/**
	 * Remove both freight signals and the state that drives them.
	 *
	 * Keyed on FREIGHT_SIGNALS_ACTIVE_OPTION being set at all, not on it recording that the inbox
	 * note was placed. The notice is added whenever the store is affected, while the note is
	 * best-effort — add_freight_credentials_note() returns false whenever the Notes API is
	 * unavailable — so a teardown gated on the note having succeeded left the banner permanently
	 * out, telling a merchant with working credentials that their freight rates had stopped.
	 *
	 * The notice is checked independently of the option rather than trusted to follow it, so a
	 * banner that is out with no matching state — a hand-edited option, a half-applied upgrade —
	 * still gets cleared instead of stranding. has_notice() reads WC_Admin_Notices' in-memory
	 * cache, so the extra check is free.
	 *
	 * Every call below is a no-op when the corresponding state is already absent, and the guard
	 * means an unaffected store pays one cached option read per admin request.
	 *
	 * @return void
	 *
	 * @since 4.8.1
	 */
	private function clear_freight_credentials_signals() {
		if ( ! WC_Admin_Notices::has_notice( self::FREIGHT_NOTICE_NAME )
			&& ! get_option( self::FREIGHT_SIGNALS_ACTIVE_OPTION ) ) {
			return;
		}

		WC_Admin_Notices::remove_notice( self::FREIGHT_NOTICE_NAME );
		$this->delete_freight_credentials_note();
		delete_option( self::FREIGHT_SIGNALS_ACTIVE_OPTION );

		// Clear the cooldown too, so a store that loses its credentials again is warned immediately
		// rather than being held quiet by a dismissal from months ago.
		delete_option( self::FREIGHT_NOTICE_DISMISSED_AT_OPTION );
	}

	/**
	 * Add the credentials notice unless it is inside its dismissal cooldown.
	 *
	 * @param array $zone_names Affected zone names.
	 *
	 * @return void
	 *
	 * @since 4.8.1
	 */
	private function maybe_add_freight_credentials_notice( array $zone_names ) {
		$dismissed_at = absint( get_option( self::FREIGHT_NOTICE_DISMISSED_AT_OPTION ) );

		if ( $dismissed_at > 0 ) {
			/**
			 * Filter how long the freight credentials notice stays dismissed.
			 *
			 * The notice comes back after this period while the credentials are still missing,
			 * so the merchant is not left permanently unwarned by a single dismissal.
			 *
			 * @param int $cooldown Seconds. Default 30 days.
			 *
			 * @since 4.8.1
			 */
			$cooldown = absint( apply_filters( 'woocommerce_shipping_fedex_freight_notice_cooldown', 30 * DAY_IN_SECONDS ) );

			if ( time() - $dismissed_at < $cooldown ) {
				return;
			}

			delete_option( self::FREIGHT_NOTICE_DISMISSED_AT_OPTION );
		}

		// add_custom_notice() runs the HTML through wp_kses_post() before storing it, so compare
		// the filtered form — an unfiltered comparison would never match. The comparison also lets
		// the stored copy refresh when the zone set changes, since update_option() already
		// short-circuits on an unchanged value.
		$html = wp_kses_post( $this->get_freight_credentials_notice_html( $zone_names ) );

		if ( get_option( 'woocommerce_admin_notice_' . self::FREIGHT_NOTICE_NAME ) === $html
			&& in_array( self::FREIGHT_NOTICE_NAME, WC_Admin_Notices::get_notices(), true ) ) {
			return;
		}

		WC_Admin_Notices::add_custom_notice( self::FREIGHT_NOTICE_NAME, $html );
	}

	/**
	 * Build the credentials notice content.
	 *
	 * WooCommerce wraps custom notices in `<div id="message" class="updated woocommerce-message">`
	 * — a success style, with no type parameter and no per-notice hook for CSS. The bold lead-in
	 * and the warning dashicon are what carry the urgency the green chrome does not.
	 *
	 * @param array $zone_names Affected zone names.
	 *
	 * @return string
	 *
	 * @since 4.8.1
	 */
	private function get_freight_credentials_notice_html( array $zone_names ) {
		$message = sprintf(
			/* translators: %1$s: FedEx Freight developer portal link start, %2$s: link end, %3$s: FedEx settings link start, %4$s: link end, %5$s: comma-separated list of shipping zone names that have a freight service enabled. */
			esc_html__( 'FedEx moved LTL rating onto its own platform, which needs separate API credentials. Until you add them, no FedEx Freight rates are returned for deliveries to the US, Canada or Puerto Rico. You have freight services enabled in these shipping zones: %5$s. Create a project at %1$sdeveloper.fedexfreight.com%2$s, then enter the FedEx Freight API key and secret in your %3$sFedEx shipping settings%4$s.', 'woocommerce-shipping-fedex' ),
			'<a href="https://developer.fedexfreight.com" target="_blank" rel="noopener noreferrer">',
			'<span class="screen-reader-text"> ' . esc_html__( '(opens in a new tab)', 'woocommerce-shipping-fedex' ) . '</span></a>',
			'<a href="' . esc_url( self::get_freight_settings_url() ) . '">',
			'</a>',
			'<strong>' . esc_html( $this->format_freight_zone_names( $zone_names ) ) . '</strong>'
		);

		return '<p><span class="dashicons dashicons-warning" aria-hidden="true"></span> <strong>'
			. esc_html__( 'FedEx Freight rates have stopped.', 'woocommerce-shipping-fedex' )
			. '</strong> ' . $message . '</p>';
	}

	/**
	 * Add the freight credentials inbox note, if WC Admin is available.
	 *
	 * The caller only records the freight signals as active when this returns true. If the Notes
	 * API is unavailable or the add call throws, the signal is left inactive so the next
	 * admin_init retries — otherwise a one-off failure (WC Admin disabled at that moment, a
	 * partial WC upgrade, a transient DB error) would permanently lose the inbox note with no
	 * further retry, since the transition only happens once.
	 *
	 * @return bool True when the note was added or already exists. False when the Notes API is
	 *              unavailable or the add call threw.
	 *
	 * @since 4.8.1
	 */
	private function add_freight_credentials_note() {
		if ( ! $this->load_freight_credentials_note() ) {
			return false;
		}

		try {
			// NoteTraits::possibly_add_note() returns void, so a completed call without an
			// exception is treated as success — whether it added the note or the note already
			// existed is not distinguishable, and both count as "the note is in place".
			WC_Fedex_Note_Freight_Credentials::possibly_add_note();
		} catch ( Throwable $e ) {
			Logger::debug( 'Could not add the freight credentials note: ' . $e->getMessage() );

			return false;
		}

		return true;
	}

	/**
	 * Delete the freight credentials inbox note.
	 *
	 * Deleted rather than actioned on purpose: NoteTraits::possibly_add_note() refuses to re-add
	 * a note whose name still exists, so removing the row is what lets the note come back if the
	 * credentials are ever cleared again.
	 *
	 * @return void
	 *
	 * @since 4.8.1
	 */
	private function delete_freight_credentials_note() {
		if ( ! $this->load_freight_credentials_note() ) {
			return;
		}

		try {
			WC_Fedex_Note_Freight_Credentials::possibly_delete_note();
		} catch ( Throwable $e ) {
			Logger::debug( 'Could not delete the freight credentials note: ' . $e->getMessage() );
		}
	}

	/**
	 * Clear this branch's freight credentials signals on plugin deactivation.
	 *
	 * Under 4.8.0 the freight warning was a plain admin_notices callback, so deactivating the
	 * plugin removed it instantly. The WC_Admin_Notices custom notice, the WC Admin inbox note,
	 * and the two flag options this branch introduced all outlive deactivation unless cleared
	 * here — left alone, a merchant who deactivates or deletes the plugin keeps seeing a FedEx
	 * warning whose action button points at a settings section that no longer exists.
	 *
	 * @return void
	 *
	 * @since 4.8.1
	 */
	public function deactivate() {
		if ( class_exists( 'WC_Admin_Notices' ) ) {
			// The true flag forces an immediate store_notices(): deactivation may not reach the
			// shutdown hook WC_Admin_Notices normally relies on to persist a removal.
			WC_Admin_Notices::remove_notice( self::FREIGHT_NOTICE_NAME, true );
		}

		$this->delete_freight_credentials_note();

		delete_option( self::FREIGHT_SIGNALS_ACTIVE_OPTION );
		delete_option( self::FREIGHT_NOTICE_DISMISSED_AT_OPTION );

		// A store deactivating before its first 4.8.1 admin request never ran the migration, so
		// the 4.8.0 flag would otherwise be left behind with nothing left to read it.
		delete_option( self::FREIGHT_LEGACY_DISMISSED_OPTION );
	}

	/**
	 * Record when the merchant dismissed the freight credentials notice.
	 *
	 * The timestamp starts the cooldown after which the notice comes back, so a single dismissal
	 * cannot leave a store permanently unwarned while its LTL rates are still failing.
	 *
	 * @return void
	 *
	 * @since 4.8.1
	 */
	public function record_freight_notice_dismissal() {
		update_option( self::FREIGHT_NOTICE_DISMISSED_AT_OPTION, time(), false );
	}

	/**
	 * Carry the 4.8.0 dismissal flag over to the cooldown.
	 *
	 * Runs lazily from the evaluator rather than from an upgrade routine. install() is
	 * unreachable on live installs — maybe_install() gates it on wc_fedex_version < 3.4.0 — so
	 * a migration appended there would look correct in review and on a fresh wp-env while
	 * running on zero real sites.
	 *
	 * Seeded to now rather than to the original dismissal time, which was never recorded: a
	 * merchant who already dismissed the 4.8.0 notice gets a fresh quiet window instead of a
	 * banner the moment they upgrade.
	 *
	 * Only seeded on a store the signals actually apply to. A 4.8.0 dismissal on a store whose
	 * freight credentials are fine says nothing about the future, and turning it into a cooldown
	 * there would silence the banner for 30 days if that store later lost its credentials — the
	 * exact failure this branch exists to remove. The flag is still deleted either way, so the
	 * migration stays one-shot.
	 *
	 * @param bool $is_affected Whether the store currently needs the freight signals.
	 *
	 * @return void
	 *
	 * @since 4.8.1
	 */
	private function migrate_legacy_freight_notice_dismissal( $is_affected ) {
		if ( 'yes' !== get_option( self::FREIGHT_LEGACY_DISMISSED_OPTION ) ) {
			return;
		}

		if ( $is_affected && ! get_option( self::FREIGHT_NOTICE_DISMISSED_AT_OPTION ) ) {
			update_option( self::FREIGHT_NOTICE_DISMISSED_AT_OPTION, time(), false );
		}

		delete_option( self::FREIGHT_LEGACY_DISMISSED_OPTION );
	}

	/**
	 * Dismiss the freight credentials notice.
	 *
	 * @deprecated 4.8.1 The notice is a WC_Admin_Notices custom notice, dismissed through
	 *                   WooCommerce's own handler. Kept for one release so a stale admin page
	 *                   whose 4.8.0 inline script still fires does not error. Remove in 4.9.0.
	 *
	 * @return void
	 *
	 * @since 4.8.0
	 */
	public function dismiss_freight_credentials_notice() {
		check_ajax_referer( 'fedex_dismiss_freight_credentials_notice' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			wp_send_json_error( null, 403 );
		}

		$this->record_freight_notice_dismissal();

		if ( class_exists( 'WC_Admin_Notices' ) ) {
			WC_Admin_Notices::remove_notice( self::FREIGHT_NOTICE_NAME, true );
		}

		wp_send_json_success();
	}
}
