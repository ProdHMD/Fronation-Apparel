<?php
/**
 * Main plugin class file.
 *
 * @package WC_Shipping_Fedex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/trait-util.php';
require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-logger.php';

use WooCommerce\FedEx\Util;

/**
 * Main plugin class.
 */
class WC_Shipping_Fedex_Init {

	use Util;

	/**
	 * Plugin's version.
	 *
	 * @var string
	 * @since 3.4.0
	 */
	public $version;

	/**
	 * Class instance.
	 *
	 * @var object
	 */
	private static $instance;

	/**
	 * Get the class instance.
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Initialize the plugin's public actions.
	 */
	public function __construct() {
		$this->version  = WC_SHIPPING_FEDEX_VERSION;
		$fedex_settings = get_option( 'woocommerce_fedex_settings', array() );

		if ( ! class_exists( 'WC_Shipping_Method' ) ) {
			add_action( 'admin_notices', array( $this, 'wc_deactivated' ) );
			return;
		}

		add_action( 'admin_init', array( $this, 'maybe_install' ), 5 );
		add_action( 'init', array( $this, 'load_textdomain' ) );
		add_action( 'before_woocommerce_init', array( $this, 'declare_hpos_compatibility' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( WC_SHIPPING_FEDEX_FILE ), array( $this, 'plugin_links' ) );
		add_action( 'woocommerce_shipping_init', array( $this, 'includes' ) );
		add_filter( 'woocommerce_shipping_methods', array( $this, 'add_method' ) );
		add_action( 'admin_notices', array( $this, 'environment_check' ) );
		add_action( 'admin_notices', array( $this, 'upgrade_notice' ) );
		add_action( 'wp_ajax_fedex_dismiss_upgrade_notice', array( $this, 'dismiss_upgrade_notice' ) );
		add_action( 'admin_init', array( $this, 'maybe_migrate_soap' ), 6 );
		add_action( 'admin_notices', array( $this, 'soap_retired_notice' ) );
		add_action( 'wp_ajax_fedex_dismiss_soap_retired_notice', array( $this, 'dismiss_soap_retired_notice' ) );
		add_action( 'admin_notices', array( $this, 'freight_credentials_notice' ) );
		add_action( 'wp_ajax_fedex_dismiss_freight_credentials_notice', array( $this, 'dismiss_freight_credentials_notice' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		$this->init_abilities();

		if ( isset( $fedex_settings['freight_enabled'] ) && 'yes' === $fedex_settings['freight_enabled'] ) {
			// Make the city field show in the calculator (for freight).
			add_filter( 'woocommerce_shipping_calculator_enable_city', '__return_true' );

			// Add freight class option for shipping classes (for freight).
			if ( is_admin() ) {
				include WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-fedex-freight-mapping.php';
			}
		}

		if ( is_admin() ) {
			include_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-shipping-fedex-admin.php';
		}
	}

	/**
	 * Initialize WordPress Abilities API definitions.
	 *
	 * @return void
	 */
	private function init_abilities() {
		if ( ! interface_exists( '\Automattic\WooCommerce\Abilities\AbilityDefinition' ) ) {
			return;
		}

		require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/abilities/class-wc-shipping-fedex-abilities.php';
		WC_Shipping_Fedex_Abilities::init();
	}

	/**
	 * Environment check function.
	 */
	public function environment_check() {

		$messages = array();

		/**
		 * Allow third party to hide the check store currency debug text.
		 *
		 * @param boolean $check_flag Flag for hide or display the debug text.
		 *
		 * @since 3.4.30
		 */
		if ( apply_filters( 'woocommerce_shipping_fedex_check_store_currency', true ) && ! in_array( get_woocommerce_currency(), array( 'USD', 'CAD' ), true ) ) {
			$messages[] = esc_html__( 'WooCommerce currency is set to US Dollars or CA Dollars', 'woocommerce-shipping-fedex' );
		}

		// Country check.
		if ( ! in_array( $this->get_base_country(), array( 'US', 'CA' ), true ) ) {
			$messages[] = esc_html__( 'Base country/region is set to United States or Canada', 'woocommerce-shipping-fedex' );
		}

		if ( ! empty( $messages ) ) {
			// translators: %s is messages.
			$prefix    = __( 'FedEx requires that %s', 'woocommerce-shipping-fedex' );
			$separator = __( ' and ', 'woocommerce-shipping-fedex' );

			echo '<div class="error">
				<p>' . esc_html( sprintf( $prefix, implode( $separator, $messages ) ) ) . '</p>
			</div>';
		}
	}

	/**
	 * Enqueue admin scripts.
	 *
	 * @return void
	 * @version 3.4.0
	 * @since   3.4.0
	 */
	public function enqueue_admin_scripts() {

		$screen    = get_current_screen();
		$screen_id = ( $screen instanceof WP_Screen && ! empty( $screen->id ) ) ? $screen->id : '';

		if ( 'woocommerce_page_wc-settings' !== $screen_id ) {
			return;
		}

		// Register scripts.
		wp_register_script( 'fedex-admin-instance-js', plugin_dir_url( WC_SHIPPING_FEDEX_FILE ) . 'assets/js/admin-instance.js', array( 'jquery' ), WC_SHIPPING_FEDEX_VERSION, true );
		wp_enqueue_style( 'fedex-admin', plugin_dir_url( WC_SHIPPING_FEDEX_FILE ) . 'assets/css/admin.css', array(), WC_SHIPPING_FEDEX_VERSION );

		// Enqueue scripts.
		wp_enqueue_script( 'jquery-ui-sortable' );

		if ( isset( $_GET['instance_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended --- We are just checking if the instance_id parameter is set.
			wp_enqueue_script( 'fedex-admin-instance-js' );
		}
	}

	/**
	 * Load includes.
	 *
	 * @return void
	 * @version 3.4.0
	 * @since   3.4.0
	 */
	public function includes() {
		include_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-fedex-privacy.php';
		include_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/class-wc-shipping-fedex.php';
	}

	/**
	 * Add Fedex shipping method to WC.
	 *
	 * @param mixed $methods Shipping methods.
	 *
	 * @return array
	 */
	public function add_method( $methods ) {
		$methods['fedex'] = 'WC_Shipping_Fedex';

		return $methods;
	}

	/**
	 * Localisation.
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'woocommerce-shipping-fedex', false, dirname( plugin_basename( WC_SHIPPING_FEDEX_FILE ) ) . '/languages/' );
	}

	/**
	 * Declare High-Performance Order Storage (HPOS) compatibility
	 *
	 * @see https://github.com/woocommerce/woocommerce/wiki/High-Performance-Order-Storage-Upgrade-Recipe-Book#declaring-extension-incompatibility
	 *
	 * @return void
	 */
	public function declare_hpos_compatibility() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', 'woocommerce-shipping-fedex/woocommerce-shipping-fedex.php' );
		}
	}

	/**
	 * Plugin page links.
	 *
	 * @param array $links Plugin action links.
	 *
	 * @return array Plugin action links.
	 * @version 3.4.9
	 */
	public function plugin_links( $links ) {
		$plugin_links = array(
			'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=shipping&section=fedex' ) . '">' . __( 'Settings', 'woocommerce-shipping-fedex' ) . '</a>',
			'<a href="https://support.woocommerce.com/">' . __( 'Support', 'woocommerce-shipping-fedex' ) . '</a>',
			'<a href="https://docs.woocommerce.com/document/fedex/">' . __( 'Docs', 'woocommerce-shipping-fedex' ) . '</a>',
		);

		return array_merge( $plugin_links, $links );
	}

	/**
	 * WooCommerce not installed notice.
	 */
	public function wc_deactivated() {
		/* translators: %s: WooCommerce link */
		echo '<div class="error"><p>' . sprintf( esc_html__( 'WooCommerce FedEx Shipping requires %s to be installed and active.', 'woocommerce-shipping-fedex' ), '<a href="https://woocommerce.com" target="_blank">WooCommerce</a>' ) . '</p></div>';
	}

	/**
	 * See if we need to install any upgrades
	 * and call the install.
	 *
	 * @version 3.4.0
	 * @since   3.4.0
	 */
	public function maybe_install() {
		// Only need to do this for versions less than 3.4.0 to migrate
		// settings to shipping zone instance.
		if ( ! defined( 'DOING_AJAX' ) && ! defined( 'IFRAME_REQUEST' ) && version_compare( get_option( 'wc_fedex_version' ), '3.4.0', '<' ) ) {

			$this->install();
		}
	}

	/**
	 * Update/migration script.
	 *
	 * @since   3.4.0
	 * @version 3.4.0
	 */
	public function install() {
		// Get all saved settings and cache it.
		$fedex_settings = get_option( 'woocommerce_fedex_settings', false );

		// Settings exists.
		if ( $fedex_settings ) {
			global $wpdb;

			// Unset un-needed settings.
			unset( $fedex_settings['enabled'] );
			unset( $fedex_settings['availability'] );
			unset( $fedex_settings['countries'] );

			// Add it to the "rest of the world" zone when no fedex.
			if ( ! $this->is_zone_has_fedex( 0 ) ) {
				$wpdb->query( $wpdb->prepare( "INSERT INTO {$wpdb->prefix}woocommerce_shipping_zone_methods ( zone_id, method_id, method_order, is_enabled ) VALUES ( %d, %s, %d, %d )", 0, 'fedex', 1, 1 ) );
				// Add settings to the newly created instance to options table.
				$instance = $wpdb->insert_id;
				add_option( 'woocommerce_fedex_' . $instance . '_settings', $fedex_settings );
			}

			update_option( 'woocommerce_fedex_show_upgrade_notice', 'yes' );
		}

		update_option( 'wc_fedex_version', $this->version );
	}

	/**
	 * Show the user a notice for plugin updates.
	 *
	 * @since 3.4.0
	 */
	public function upgrade_notice() {
		$show_notice = get_option( 'woocommerce_fedex_show_upgrade_notice' );

		if ( 'yes' !== $show_notice ) {
			return;
		}

		$query_args      = array(
			'page' => 'wc-settings',
			'tab'  => 'shipping',
		);
		$zones_admin_url = add_query_arg( $query_args, get_admin_url() . 'admin.php' );
		?>
		<div class="notice notice-success is-dismissible wc-fedex-notice">
			<p>
				<?php
				/* translators: %1$s: Shipping zones link start, %2$s: Link end */
				printf( esc_html__( 'FedEx now supports shipping zones. The zone settings were added to a new FedEx method on the "Rest of the World" Zone. See the zones %1$shere%2$s ', 'woocommerce-shipping-fedex' ), '<a href="' . esc_url( $zones_admin_url ) . '">', '</a>' );
				?>
			</p>
		</div>

		<script type="application/javascript">
			// jQuery.post over ajaxurl rather than wp.ajax: wp-util is not enqueued on every admin
			// screen, and enqueuing it from admin_notices lands in the footer, after this runs.
			jQuery( '.notice.wc-fedex-notice' ).on( 'click', '.notice-dismiss', function() {
				jQuery.post( ajaxurl, { action: 'fedex_dismiss_upgrade_notice' } );
			} );
		</script>
		<?php
	}

	/**
	 * Turn of the dismissible upgrade notice.
	 *
	 * @since 3.4.0
	 */
	public function dismiss_upgrade_notice() {
		update_option( 'woocommerce_fedex_show_upgrade_notice', 'no' );
	}

	/**
	 * One-time migration: FedEx retired the SOAP (Web Services) API on 2026-06-01.
	 * Force any store still on `api_type = soap` onto REST and flag a notice.
	 *
	 * @return void
	 */
	public function maybe_migrate_soap() {
		if ( wp_doing_ajax() || ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			return;
		}

		$fedex_settings = get_option( 'woocommerce_fedex_settings', array() );

		if ( ! is_array( $fedex_settings ) ) {
			return;
		}

		$api_type = isset( $fedex_settings['api_type'] ) ? $fedex_settings['api_type'] : '';

		// Stores set up before the REST API was introduced never persisted `api_type`.
		// For those, a stored Web Services key is what marked them as running on SOAP.
		$is_soap = 'soap' === $api_type || ( '' === $api_type && ! empty( $fedex_settings['api_key'] ) );

		if ( ! $is_soap ) {
			return;
		}

		$fedex_settings['api_type'] = 'rest';
		update_option( 'woocommerce_fedex_settings', $fedex_settings );
		update_option( 'woocommerce_fedex_show_soap_retired_notice', 'yes' );
	}

	/**
	 * Show the one-time notice after a SOAP store is migrated to REST.
	 *
	 * @return void
	 */
	public function soap_retired_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			return;
		}

		if ( 'yes' !== get_option( 'woocommerce_fedex_show_soap_retired_notice' ) ) {
			return;
		}

		$settings_url = add_query_arg(
			array(
				'page'    => 'wc-settings',
				'tab'     => 'shipping',
				'section' => 'fedex',
			),
			get_admin_url() . 'admin.php'
		);
		?>
		<div class="notice notice-error is-dismissible wc-fedex-soap-retired-notice">
			<p>
				<?php
				/* translators: %1$s: FedEx settings link start, %2$s: link end */
				printf( esc_html__( 'FedEx retired the SOAP (Web Services) API on June 1, 2026. Your store has been switched to the REST API — please enter your REST API Key & Secret in the %1$sFedEx settings%2$s to continue receiving rates.', 'woocommerce-shipping-fedex' ), '<a href="' . esc_url( $settings_url ) . '">', '</a>' );
				?>
			</p>
		</div>

		<script type="application/javascript">
			// jQuery.post over ajaxurl rather than wp.ajax: wp-util is not enqueued on every admin
			// screen, and enqueuing it from admin_notices lands in the footer, after this runs.
			jQuery( '.notice.wc-fedex-soap-retired-notice' ).on( 'click', '.notice-dismiss', function() {
				jQuery.post( ajaxurl, {
					action: 'fedex_dismiss_soap_retired_notice',
					_ajax_nonce: '<?php echo esc_js( wp_create_nonce( 'fedex_dismiss_soap_retired_notice' ) ); ?>'
				} );
			} );
		</script>
		<?php
	}

	/**
	 * Dismiss the SOAP-retired notice.
	 *
	 * @return void
	 */
	public function dismiss_soap_retired_notice() {
		check_ajax_referer( 'fedex_dismiss_soap_retired_notice' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			wp_send_json_error( null, 403 );
		}

		update_option( 'woocommerce_fedex_show_soap_retired_notice', 'no' );

		wp_send_json_success();
	}

	/**
	 * Whether freight is enabled but the FedEx Freight credentials are missing.
	 *
	 * Freight is configured on the plugin-wide FedEx settings screen, not per shipping zone —
	 * its fields live in `form_fields`, not `instance_form_fields`, so they are stored in
	 * `woocommerce_fedex_settings` and read from there by `WC_Shipping_Method::get_option()`.
	 *
	 * @return bool
	 *
	 * @since 4.8.0
	 */
	private function has_freight_without_credentials() {
		$settings = get_option( 'woocommerce_fedex_settings', array() );

		if ( ! is_array( $settings ) || ! isset( $settings['freight_enabled'] ) || 'yes' !== $settings['freight_enabled'] ) {
			return false;
		}

		return empty( $settings['freight_client_id'] ) || empty( $settings['freight_client_secret'] );
	}

	/**
	 * Whether any enabled FedEx method instance has a freight service enabled.
	 *
	 * The rate path only asks the freight platform for rates when a freight service is enabled
	 * on the instance, so the credentials notice must stay quiet for stores that never request
	 * one.
	 *
	 * Every code in data-freight-services.php counts, including the INTERNATIONAL_ ones. The
	 * platform is chosen by destination, not by service: calculate_shipping() sends US, CA and
	 * PR to the LTL platform and everything else to the parcel endpoint, so a store offering
	 * only INTERNATIONAL_PRIORITY_FREIGHT still needs freight credentials the moment it quotes
	 * a US address. Narrowing this list by service code would leave that store unwarned while
	 * its freight requests were skipped. The notice text names the destinations instead.
	 *
	 * Reads the zone-methods table and the instance options directly rather than through
	 * WC_Shipping_Zones::get_zones(). That helper resolves every method in every zone with
	 * context 'admin', which makes WC_Shipping_Zone::get_shipping_methods() call
	 * get_admin_options_html() on each method declaring 'instance-settings-modal' — core's
	 * flat rate, free shipping and local pickup all do — so answering one boolean would build
	 * and discard their entire settings markup on every admin screen. instance_count() already
	 * reads this table for the same reason.
	 *
	 * @return bool
	 *
	 * @since 4.8.0
	 */
	private function freight_service_enabled_anywhere() {
		global $wpdb;

		$instance_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT instance_id FROM {$wpdb->prefix}woocommerce_shipping_zone_methods WHERE method_id = %s AND is_enabled = 1",
				'fedex'
			)
		);

		if ( empty( $instance_ids ) ) {
			return false;
		}

		$freight_services = include WC_SHIPPING_FEDEX_ABSPATH . 'includes/data/data-freight-services.php';

		foreach ( $instance_ids as $instance_id ) {
			$settings = get_option( 'woocommerce_fedex_' . absint( $instance_id ) . '_settings' );

			if ( ! is_array( $settings ) || empty( $settings['services'] ) || ! is_array( $settings['services'] ) ) {
				continue;
			}

			foreach ( $freight_services as $service ) {
				if ( ! empty( $settings['services'][ $service ]['enabled'] ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Tell stores that rated LTL before the spinoff that freight now needs its own credentials.
	 *
	 * Without them no freight rates are returned at all, and the only other signal is the
	 * status row on the settings screen — which the merchant has no reason to go and look at.
	 *
	 * @return void
	 *
	 * @since 4.8.0
	 */
	public function freight_credentials_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			return;
		}

		if ( 'yes' === get_option( 'woocommerce_fedex_dismissed_freight_credentials_notice' ) ) {
			return;
		}

		if ( ! $this->has_freight_without_credentials() ) {
			return;
		}

		if ( ! $this->freight_service_enabled_anywhere() ) {
			return;
		}

		// section=fedex is required: the freight credential fields live on the plugin-wide FedEx
		// screen, not the shipping zones list, and this notice exists to send merchants there.
		$settings_url = add_query_arg(
			array(
				'page'    => 'wc-settings',
				'tab'     => 'shipping',
				'section' => 'fedex',
			),
			admin_url( 'admin.php' )
		);
		?>
		<div class="notice notice-error is-dismissible wc-fedex-freight-credentials-notice">
			<p>
				<?php
				/* translators: %1$s: FedEx Freight developer portal link start, %2$s: link end, %3$s: Shipping settings link start, %4$s: link end */
				printf( esc_html__( 'FedEx Freight moved LTL rating onto its own platform, which needs separate API credentials. Create a project at %1$sdeveloper.fedexfreight.com%2$s, then enter the FedEx Freight API key & secret in your %3$sFedEx shipping settings%4$s to keep receiving freight rates to the US, Canada and Puerto Rico.', 'woocommerce-shipping-fedex' ), '<a href="https://developer.fedexfreight.com" target="_blank" rel="noopener noreferrer">', '<span class="screen-reader-text"> ' . esc_html__( '(opens in a new tab)', 'woocommerce-shipping-fedex' ) . '</span></a>', '<a href="' . esc_url( $settings_url ) . '">', '</a>' );
				?>
			</p>
		</div>

		<script type="application/javascript">
			// jQuery.post over ajaxurl rather than wp.ajax: wp-util is not enqueued on every admin
			// screen, and enqueuing it from admin_notices lands in the footer, after this runs.
			jQuery( '.notice.wc-fedex-freight-credentials-notice' ).on( 'click', '.notice-dismiss', function() {
				jQuery.post( ajaxurl, {
					action: 'fedex_dismiss_freight_credentials_notice',
					_ajax_nonce: '<?php echo esc_js( wp_create_nonce( 'fedex_dismiss_freight_credentials_notice' ) ); ?>'
				} );
			} );
		</script>
		<?php
	}

	/**
	 * Dismiss the freight credentials notice.
	 *
	 * @return void
	 *
	 * @since 4.8.0
	 */
	public function dismiss_freight_credentials_notice() {
		check_ajax_referer( 'fedex_dismiss_freight_credentials_notice' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) { // phpcs:ignore WordPress.WP.Capabilities.Unknown -- WooCommerce registers this capability.
			wp_send_json_error( null, 403 );
		}

		update_option( 'woocommerce_fedex_dismissed_freight_credentials_notice', 'yes' );

		wp_send_json_success();
	}
}
