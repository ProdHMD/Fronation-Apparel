<?php
/**
 * FedEx Abstract API class file.
 *
 * @package WC_Shipping_Fedex
 */

namespace WooCommerce\FedEx;

defined( 'ABSPATH' ) || exit;

use WC_Shipping_Fedex;

/**
 * FedEx Abstract API class.
 */
abstract class Abstract_FedEx_API {

	/**
	 * Endpoint for the API.
	 *
	 * @var string
	 */
	protected $endpoint;

	/**
	 * FedEx Shipping Method Class.
	 *
	 * @var WC_Shipping_Fedex
	 */
	protected $shipping_method;

	/**
	 * Get the common API request parameters.
	 *
	 * @param string $request_type Request type.
	 *
	 * @return array
	 */
	abstract public function get_fedex_api_request( $request_type );

	/**
	 * Prepare request elements.
	 *
	 * @param array  $request API request.
	 * @param string $request_type The request type.
	 * @param string $parent_key   The parent key.
	 *
	 * @return array
	 */
	public function prepare_request( $request, $request_type = '', $parent_key = '' ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed --- $request_type and $parent_key are used in the REST API child class.
		return $request;
	}

	/**
	 * Get result.
	 *
	 * @param array  $request API request.
	 * @param string $request_type Request type.
	 *
	 * @return array
	 */
	abstract public function get_result( $request, $request_type );

	/**
	 * Whether the last get_result() call returned a 200 that contained no rates.
	 *
	 * Lets the caller tell "the carrier has nothing for this request" apart from a transport or
	 * authorization failure, so only the former is worth remembering. Implementations that
	 * cannot tell the two apart leave this false, and nothing is cached.
	 *
	 * @return bool
	 *
	 * @since 4.8.0
	 */
	public function response_had_no_rates() {
		return false;
	}

	/**
	 * Check if Destination Address is Residential.
	 *
	 * @param array $request API request.
	 *
	 * @return bool
	 */
	abstract public function residential_address_validation( $request );

	/**
	 * Process API response.
	 *
	 * @param array  $request Request data.
	 * @param mixed  $result API response or result.
	 * @param string $request_type Request type.
	 *
	 * @return void
	 */
	abstract public function process_result( $request, $result, $request_type );
}
