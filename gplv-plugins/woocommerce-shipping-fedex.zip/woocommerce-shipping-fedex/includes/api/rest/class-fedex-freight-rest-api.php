<?php
/**
 * FedEx Freight REST API class file.
 *
 * @package WC_Shipping_Fedex
 */

namespace WooCommerce\FedEx;

defined( 'ABSPATH' ) || exit;

require_once WC_SHIPPING_FEDEX_API_DIR . '/rest/class-fedex-rest-api.php';

/**
 * FedEx Freight LTL rate client.
 *
 * The FedEx Freight spinoff moved LTL rating onto its own platform (api.ltl.tech) with
 * separate credentials, host, path and a required x-client-id header. This client owns
 * those freight-platform specifics and reuses the parcel client's request transform
 * (prepare_request) and HTTP transport (wp_remote_post_with_retry).
 *
 * Configuration happens through the parent's overridable seams rather than a replacement
 * constructor, so state the parent gains later is never silently missed here.
 *
 * Constructing this class requests a freight OAuth token, so build it only when a freight
 * rate is actually being requested — see WC_Shipping_Fedex::get_api().
 *
 * @since 4.8.0
 */
class FedEx_Freight_REST_API extends FedEx_REST_API {

	/**
	 * Prefix identifying freight rate activity in the logs.
	 *
	 * @var string
	 *
	 * @since 4.8.0
	 */
	protected $log_prefix = 'FedEx_Freight_REST_API';

	/**
	 * Freight has its own production/sandbox toggle, independent of the parcel environment.
	 *
	 * @return bool
	 *
	 * @since 4.8.0
	 */
	protected function is_production_environment() {
		return $this->shipping_method->is_freight_production();
	}

	/**
	 * The FedEx Freight LTL host, which has its own preprod environment.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_api_base_url() {
		return $this->is_production_environment() ? 'https://api.ltl.tech' : 'https://api-preprod.ltl.tech';
	}

	/**
	 * Freight rates are requested against the FedEx Freight account.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function resolve_account_number() {
		return (string) $this->shipping_method->get_freight_number();
	}

	/**
	 * Freight authenticates against its own OAuth connection on the freight platform.
	 *
	 * @return FedEx_OAuth
	 *
	 * @since 4.8.0
	 */
	protected function resolve_oauth() {
		return $this->shipping_method->get_freight_oauth();
	}

	/**
	 * The freight platform rejects a request without x-client-id, with a 403 Invalid Client.
	 *
	 * Only the extra header is declared here; the token fetch, its failure handling and every
	 * other header stay with the parent, so a header added there reaches freight too.
	 *
	 * @param string $access_token Bearer token for the freight connection.
	 *
	 * @return array
	 *
	 * @since 4.8.0
	 */
	protected function get_request_headers( $access_token ) {
		$headers = parent::get_request_headers( $access_token );

		// Hyphenated, not x-client_id: the underscore spelling was dropped in transport and the
		// gateway answered 403 Invalid Client.
		$headers['x-client-id'] = $this->shipping_method->get_freight_client_id();

		return $headers;
	}

	/**
	 * The LTL API's rateRequestType enum has no PREFERRED value, so only the store's configured
	 * rate type is asked for.
	 *
	 * Everything else the parent builds already resolves correctly for freight: the account is
	 * the freight account via resolve_account_number(), and PickupType and carrierCodes are
	 * gated on a request type of 'freight' never matching them.
	 *
	 * @return array
	 *
	 * @since 4.8.0
	 */
	protected function get_rate_request_types() {
		return array( $this->request_type );
	}

	/**
	 * The freight platform throttles at 1400 transactions per 10 seconds with a 429.
	 *
	 * Retried like 503 is elsewhere; without it a throttled burst silently drops freight from
	 * the calculation. The wait follows the platform's Retry-After when it sends one, capped by
	 * the transport's retry budget so a throttle cannot stall a checkout.
	 *
	 * @return int[]
	 *
	 * @since 4.8.0
	 */
	protected function get_retryable_rate_codes() {
		return array( 429, 503 );
	}

	/**
	 * Name the platform-specific causes the raw freight status lines leave out.
	 *
	 * A 403 is the shape the spinoff produced: OAuth can succeed while every rate request is
	 * refused, so the log must say what to check instead of echoing the raw status line.
	 *
	 * @param int $code HTTP status code.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_failure_hint( $code ) {
		if ( 403 === $code ) {
			return $this->log_prefix . ': the FedEx Freight platform refused the request. Check that the developer.fedexfreight.com project has LTL Rates access and that the freight account number matches the account the credentials were issued for.';
		}

		if ( 429 === $code ) {
			return $this->log_prefix . ': the FedEx Freight platform throttled the request (limit 1400 transactions per 10 seconds); retries allowed: ' . $this->transport_max_retries . '.';
		}

		return '';
	}

	/**
	 * Rate endpoint path — the FedEx Freight LTL Get Rate Quote path.
	 *
	 * @param string $request_type Request type.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_rate_endpoint( $request_type ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter --- Signature matches the parent; freight uses a single fixed path.
		return $this->is_production_environment()
			? '/fxf-external-rate-auth0/fxfgw/rate/getRateQuote'
			: '/fxf-external-rate-auth0/fxfgw-preprod/rate/getRateQuote';
	}

	/**
	 * The freight payload can nest `output` one level deeper than the parcel Rate API.
	 *
	 * The live LTL API returns `output.rateReplyDetails`, the published example
	 * `output.output.rateReplyDetails`. Only the location differs here — dropping unpriced
	 * entries is the base class's job, and applies to every request type.
	 *
	 * @param object $response_body Decoded response body.
	 *
	 * @return mixed The raw rate reply details, or null when absent.
	 *
	 * @since 4.8.0
	 */
	protected function locate_rate_reply_details( $response_body ) {
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase --- FedEx API camelCase.
		if ( ! empty( $response_body->output->output->rateReplyDetails ) ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase --- FedEx API camelCase.
			return $response_body->output->output->rateReplyDetails;
		}

		return parent::locate_rate_reply_details( $response_body );
	}
}
