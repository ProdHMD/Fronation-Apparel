<?php
/**
 * FedEx REST API class file.
 *
 * @package WC_Shipping_Fedex
 */

namespace WooCommerce\FedEx;

defined( 'ABSPATH' ) || exit;

require_once WC_SHIPPING_FEDEX_API_DIR . '/abstract/class-abstract-fedex-api.php';
require_once WC_SHIPPING_FEDEX_ABSPATH . 'includes/data/data-carrier-codes.php';

use WC_Shipping_Fedex;

/**
 * FedEx REST API class.
 */
class FedEx_REST_API extends Abstract_FedEx_API {

	/**
	 * Endpoint for the FedEx Rating API.
	 *
	 * @var string
	 */
	protected $api_url = '';

	/**
	 * OAuth value.
	 *
	 * @var \WooCommerce\FedEx\FedEx_OAuth
	 */
	protected $oauth;

	/**
	 * FedEx Account Number
	 *
	 * @var string
	 */
	protected $account_number;

	/**
	 * API Mode Production or Test
	 *
	 * @var string
	 */
	protected $api_mode;

	/**
	 * Request type
	 *
	 * @var string
	 */
	protected $request_type;

	/**
	 * Is Recipient Address Residential.
	 *
	 * @var bool
	 */
	protected $residential;

	/**
	 * Request headers.
	 *
	 * @var array
	 */
	protected $headers;

	/**
	 * Max transport retries for wp_remote_post_with_retry().
	 *
	 * @var int
	 */
	protected $transport_max_retries;

	/**
	 * Delay in milliseconds between transport retries.
	 *
	 * @var int
	 */
	protected $transport_retry_delay_ms;

	/**
	 * Longest Retry-After this client will wait out before giving up on a retry.
	 *
	 * A rate request runs while a shopper waits, so a throttle window measured in seconds is
	 * better answered with "no rates this time" than with a blocked checkout.
	 *
	 * @var int
	 *
	 * @since 4.8.0
	 */
	const MAX_RETRY_AFTER_MS = 2000;

	/**
	 * Prefix identifying this client in log messages. Subclasses override it so freight and
	 * parcel rate activity can be told apart in the WooCommerce logs.
	 *
	 * @var string
	 *
	 * @since 4.8.0
	 */
	protected $log_prefix = 'FedEx_REST_API';

	/**
	 * Whether the last get_result() call received a 200 that carried no rates.
	 *
	 * Lets the caller tell "FedEx has nothing for this request" apart from a transport or
	 * authorization failure, so only the former is worth remembering.
	 *
	 * @var bool
	 *
	 * @since 4.8.0
	 */
	protected $response_had_no_rates = false;

	/**
	 * FedEx_REST_API constructor.
	 *
	 * Subclasses configure themselves by overriding is_production_environment(),
	 * get_api_base_url(), resolve_account_number() and resolve_oauth() rather than replacing
	 * this initialization, so state added here is never missed by a child client.
	 *
	 * @param WC_Shipping_Fedex $fedex_shipping_method The FedEx shipping method object.
	 */
	public function __construct( $fedex_shipping_method ) {
		$this->shipping_method = $fedex_shipping_method;
		$this->api_mode        = $this->is_production_environment() ? 'production' : 'test';
		$this->account_number  = $this->resolve_account_number();
		$this->request_type    = $fedex_shipping_method->get_request_type();
		$this->oauth           = $this->resolve_oauth();
		$this->residential     = $fedex_shipping_method->is_residential();
		$this->api_url         = $this->get_api_base_url();

		// Resolved once at construction; runtime add_filter() after this point has no effect.
		$this->init_transport_retry_settings();

		$this->set_headers();
	}

	/**
	 * Whether this client talks to the production environment.
	 *
	 * Overridden by the FedEx Freight rate client, which has its own environment toggle.
	 *
	 * @return bool
	 *
	 * @since 4.8.0
	 */
	protected function is_production_environment() {
		return $this->shipping_method->is_production();
	}

	/**
	 * Host this client sends its requests to.
	 *
	 * Overridden by the FedEx Freight rate client, which runs on a separate platform.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_api_base_url() {
		return $this->is_production_environment() ? 'https://apis.fedex.com' : 'https://apis-sandbox.fedex.com';
	}

	/**
	 * Account number rates are requested against.
	 *
	 * Overridden by the FedEx Freight rate client, which bills to the freight account.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function resolve_account_number() {
		return $this->shipping_method->get_account_number();
	}

	/**
	 * OAuth connection this client authenticates with.
	 *
	 * Overridden by the FedEx Freight rate client, which has its own credentials.
	 *
	 * @return FedEx_OAuth
	 *
	 * @since 4.8.0
	 */
	protected function resolve_oauth() {
		return $this->shipping_method->get_oauth();
	}

	/**
	 * Resolve the HTTP transport retry settings from filters.
	 *
	 * Shared by the parcel and freight rate clients so both honour the same filters.
	 *
	 * @return void
	 *
	 * @since 4.8.0
	 */
	protected function init_transport_retry_settings() {
		/**
		 * Filters the maximum number of retries for API requests on transport failure.
		 *
		 * @since 4.6.0
		 *
		 * @param int $max_retries The maximum number of retries. Default 1.
		 */
		$this->transport_max_retries = min( 3, max( 0, (int) apply_filters( 'woocommerce_shipping_fedex_api_retry_count', 1 ) ) );
		/**
		 * Filters the delay in milliseconds between retry attempts.
		 *
		 * @since 4.6.0
		 *
		 * @param int $delay_ms The delay in milliseconds. Default 500.
		 */
		$this->transport_retry_delay_ms = min( 2000, max( 0, (int) apply_filters( 'woocommerce_shipping_fedex_api_retry_delay_ms', 500 ) ) );
	}

	/**
	 * Log context tagged with this client's own environment.
	 *
	 * Logger::log() otherwise derives the log file from the shipping method's api_mode — the
	 * parcel environment — which files freight entries under the parcel log whenever the two
	 * environments differ. Identical to the default for the parcel client.
	 *
	 * @param array $context Existing log context.
	 *
	 * @return array
	 *
	 * @since 4.8.0
	 */
	protected function log_context( $context = array() ) {
		if ( ! isset( $context['source'] ) ) {
			$context['source'] = 'plugin-woocommerce-shipping-fedex-' . $this->shipping_method->api_type . '-' . $this->api_mode;
		}

		return $context;
	}

	/**
	 * Set request headers.
	 *
	 * @param bool $force_refresh Force refresh access token.
	 *
	 * @return bool True if headers were set successfully, false if authentication failed.
	 *
	 * @since 4.8.0 Widened to protected for symmetry with the other subclass seams.
	 */
	protected function set_headers( $force_refresh = false ) {
		$access_token = $this->oauth->get_access_token( $force_refresh );

		// If we don't have a valid access token, don't set headers.
		if ( false === $access_token || empty( $access_token ) ) {
			Logger::debug( $this->log_prefix . '::set_headers: Cannot set headers - no valid access token available.', $this->log_context() );
			return false;
		}

		$this->headers = $this->get_request_headers( $access_token );

		return true;
	}

	/**
	 * Headers sent with every request from this client.
	 *
	 * The seam subclasses override, so a header added here reaches every client rather than
	 * only the parcel one. Overridden by the FedEx Freight rate client, whose platform also
	 * requires x-client-id.
	 *
	 * @param string $access_token Bearer token for this client's connection.
	 *
	 * @return array
	 *
	 * @since 4.8.0
	 */
	protected function get_request_headers( $access_token ) {
		return array(
			'Authorization' => 'Bearer ' . $access_token,
			'X-locale'      => 'en_US',
			'Content-Type'  => 'application/json',
		);
	}

	/**
	 * Rate request types asked for in the rate request.
	 *
	 * PREFERRED asks FedEx to convert into the store currency; the preferred currency is not
	 * returned when the requested one is already present in the response. Overridden by the
	 * FedEx Freight rate client, whose LTL rateRequestType enum has no PREFERRED value.
	 *
	 * @return array
	 *
	 * @since 4.8.0
	 */
	protected function get_rate_request_types() {
		return array( $this->request_type, 'PREFERRED' );
	}

	/**
	 * Get the common API request parameters.
	 *
	 * @param string $request_type Request type.
	 *
	 * @return array
	 */
	public function get_fedex_api_request( $request_type ) {
		$request = array();

		$request['AccountNumber'] = $this->account_number;

		$request['rateRequestControlParameters'] = array(
			'returnTransitTimes'          => false,
			'servicesNeededOnRateFailure' => true,
			'rateSortOrder'               => 'SERVICENAMETRADITIONAL',
		);

		$request['RequestedShipment']['RateRequestType'] = $this->get_rate_request_types();

		if ( 'freight' !== $request_type ) {
			$request['RequestedShipment']['PickupType'] = 'DROPOFF_AT_FEDEX_LOCATION';
		}

		// The international freight request hits the same endpoint as the default one, so it asks
		// for the same carriers. Identical requests share a transient, which means no second API
		// call is made unless the two differ in how their packages are grouped.
		if ( in_array( $request_type, array( 'default', 'international_freight' ), true ) ) {
			$request['carrierCodes'] = array( CARRIER_CODE_EXPRESS );
			if ( $this->shipping_method->is_ground_service_enabled() ) {
				$request['carrierCodes'][] = CARRIER_CODE_GROUND;
			}
		}

		if ( 'ground' === $request_type ) {
			$request['carrierCodes'] = array( CARRIER_CODE_GROUND );
		}

		if ( 'smartpost' === $request_type ) {
			$request['carrierCodes'] = array( CARRIER_CODE_SMARTPOST );
		}

		return $request;
	}

	/**
	 * Get the recipient country code from a prepared rate request.
	 *
	 * @param array $request Prepared request.
	 *
	 * @return string Two letter country code, or '?' when the request has no recipient.
	 */
	private function get_request_destination_country( $request ) {
		// Freight requests carry the shipment under a different key than every other type.
		foreach ( array( 'requestedShipment', 'freightRequestedShipment' ) as $shipment_key ) {
			if ( ! empty( $request[ $shipment_key ]['recipient']['address']['countryCode'] ) ) {
				return $request[ $shipment_key ]['recipient']['address']['countryCode'];
			}
		}

		return '?';
	}

	/**
	 * Get result.
	 *
	 * @param array  $request Request.
	 * @param string $request_type Rate service type.
	 * @param bool   $allow_retry Allow retry.
	 *
	 * @return mixed
	 */
	public function get_result( $request, $request_type, $allow_retry = true ) {
		// phpcs:disable WordPress.PHP.DevelopmentFunctions.error_log_print_r --- Its needed for debugging

		$this->response_had_no_rates = false;

		// Check if we have valid headers (valid authentication).
		// This prevents making expensive API calls when we know authentication has failed.
		if ( empty( $this->headers ) || ! isset( $this->headers['Authorization'] ) ) {
			Logger::error( $this->log_prefix . '::get_result: Cannot make API request - no valid authorization headers available. Skipping API call to prevent performance issues.', $this->log_context() );
			return false;
		}

		$args = array(
			'headers' => $this->headers,
			'body'    => wp_json_encode( $request ),
			'timeout' => 10,
		);

		$endpoint = $this->get_rate_endpoint( $request_type );

		// Recorded on failures so a "no rates" report can be traced back to a destination.
		$destination = $this->get_request_destination_country( $request );

		$response = $this->wp_remote_post_with_retry( $this->api_url . $endpoint, $args, $this->get_retryable_rate_codes() );

		if ( $response instanceof \WP_Error ) {
			$code          = '?';
			$message       = 'FedEx Rate API no response';
			$response_body = $response->get_error_messages();
			Logger::error(
				'RESPONSE service: ' . $request_type . ', destination: ' . $destination . ', code: ' . $code . ', message: ' . $message,
				$this->log_context( array( 'response' => $response_body ) )
			);

			return false;

		}

		if ( is_array( $response ) ) {
			$code          = wp_remote_retrieve_response_code( $response );
			$message       = wp_remote_retrieve_response_message( $response );
			$response_body = json_decode( wp_remote_retrieve_body( $response ) );

			if ( 200 !== $code ) {
				Logger::error(
					'RESPONSE service: ' . $request_type . ', destination: ' . $destination . ', code: ' . $code . ', message: ' . $message,
					$this->log_context( array( 'response' => $response_body ) )
				);

				// Debug, not error: the status line above already records the failure
				// unconditionally, and this only explains it. A store with a standing freight 403
				// — the reader this hint is written for — would otherwise add a second
				// error-level line on every rate request forever, since only DEBUG and NOTICE are
				// silenced when debug mode is off. The explanation a merchant needs without
				// reading logs is on the settings screen instead.
				$failure_hint = $this->get_failure_hint( (int) $code );
				if ( '' !== $failure_hint ) {
					Logger::debug( $failure_hint, $this->log_context() );
				}
				$this->shipping_method->notify( '<b>RESPONSE:</b> service: <b>' . ucfirst( $request_type ) . '</b> &#10072; code: <b>' . $code . '</b> &#10072; message: <b>' . $message . '</b> <a href="#" style="float:right;" class="debug_reveal">Show</a><pre style="font-size: 12px; line-height:1.5;" class="debug_info">' . print_r( $response_body, true ) . '</pre>' );

				// JWT token expired. Refresh token and retry.
				if ( true === $allow_retry && 401 === $code ) {
					Logger::debug( $this->log_prefix . '::get_result: Trying to refresh JWT token and retry the request.', $this->log_context() );

					// Update headers with new token.
					$headers_set = $this->set_headers( true );

					// Only retry if we successfully got a new token.
					if ( $headers_set ) {
						return $this->get_result( $request, $request_type, false );
					}

					Logger::error( $this->log_prefix . '::get_result: Cannot retry request - failed to refresh access token.', $this->log_context() );
				}

				return false;
			}
		} else {
			$code          = '?';
			$message       = '?';
			$response_body = $response;
		}
		Logger::debug(
			'RESPONSE service: ' . $request_type . ', code: ' . $code . ', message: ' . $message,
			$this->log_context( array( 'response' => $response_body ) )
		);
		$this->shipping_method->notify( '<b>RESPONSE:</b> service: <b>' . ucfirst( $request_type ) . '</b> &#10072; code: <b>' . $code . '</b> &#10072; message: <b>' . $message . '</b> <a href="#" style="float:right;" class="debug_reveal">Show</a><pre style="font-size: 12px; line-height:1.5;" class="debug_info">' . print_r( $response_body, true ) . '</pre>' );

		// A response carrying no rates is never cached as a success.
		if ( null === $this->get_rate_reply_details( $response_body ) ) {

			// Only a confirmed 200 with a decoded body means FedEx has nothing to quote for this
			// request, which is the one case worth remembering. A body that did not decode, or a
			// response that never reported 200, is a failure: it must retry on the next
			// calculation rather than suppress rates for the marker's lifetime — the same
			// 200-versus-failure distinction the OAuth failure cache already makes.
			if ( 200 === $code && is_object( $response_body ) ) {
				$this->response_had_no_rates = true;

				// Debug, not warning: an ineligible destination is a routine outcome and this was
				// silent before. Warnings are written even when debug mode is off.
				Logger::debug(
					$this->log_prefix . '::get_result: 200 response contained no rate details for destination ' . $destination . '; response not cached.',
					$this->log_context()
				);
			}

			return false;
		}

		return $response_body;
	}

	/**
	 * Whether the last get_result() call returned a 200 that contained no rates.
	 *
	 * @return bool
	 *
	 * @since 4.8.0
	 */
	public function response_had_no_rates() {
		return $this->response_had_no_rates;
	}

	/**
	 * HTTP status codes worth one transport-level retry on a rate request.
	 *
	 * The freight client overrides this: its platform throttles bursts with 429.
	 *
	 * @return int[]
	 *
	 * @since 4.8.0
	 */
	protected function get_retryable_rate_codes() {
		return array();
	}

	/**
	 * Platform-specific explanation for a failed rate response, logged after the raw line.
	 *
	 * The freight client overrides this: its raw status lines do not name the cause.
	 *
	 * @param int $code HTTP status code.
	 *
	 * @return string Extra log line, or an empty string for none.
	 *
	 * @since 4.8.0
	 */
	protected function get_failure_hint( $code ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found --- Signature for subclasses.
		return '';
	}

	/**
	 * Rate endpoint path for the given request type.
	 *
	 * Overridden by the FedEx Freight rate client, which uses a different platform path.
	 *
	 * @param string $request_type Request type.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_rate_endpoint( $request_type ) {
		// get_api() sends every 'freight' request to the freight client, which overrides this, so
		// the freight branch is unreachable from the plugin. Kept because get_result() is public
		// and a third party may still call this client directly with the old request type.
		return 'freight' === $request_type ? '/rate/v1/freight/rates/quotes' : '/rate/v1/rates/quotes';
	}

	/**
	 * Extract the rate reply details from a decoded response body.
	 *
	 * Overridden by the FedEx Freight rate client, which also accepts a payload nesting
	 * `output` one level deeper.
	 *
	 * An empty list counts as absent: a 200 carrying no rates must not be cached, or the
	 * caller stores it for a week and suppresses rates for that destination.
	 *
	 * @param object $response_body Decoded response body.
	 *
	 * @return array|null The rate reply details, or null when absent or empty.
	 *
	 * @since 4.8.0
	 */
	protected function get_rate_reply_details( $response_body ) {
		return $this->keep_priced_details( $this->locate_rate_reply_details( $response_body ) );
	}

	/**
	 * Find the rate reply details in a decoded response body, wherever this platform puts them.
	 *
	 * Overridden by the FedEx Freight rate client, which also accepts a payload nesting `output`
	 * one level deeper.
	 *
	 * @param object $response_body Decoded response body.
	 *
	 * @return mixed The raw rate reply details, or null when absent.
	 *
	 * @since 4.8.0
	 */
	protected function locate_rate_reply_details( $response_body ) {
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase --- FedEx API camelCase.
		return empty( $response_body->output->rateReplyDetails ) ? null : $response_body->output->rateReplyDetails;
	}

	/**
	 * Drop reply entries that carry no price, and report nothing left as no rates at all.
	 *
	 * Every request type sets servicesNeededOnRateFailure — see get_fedex_api_request() — so
	 * FedEx can answer with entries for services it could not price, and those carry no
	 * ratedShipmentDetails. Left in, a reply where nothing was priced looks rated and the caller
	 * keeps it for a week while the shopper sees no rates.
	 *
	 * @param mixed $details Raw rate reply details.
	 *
	 * @return array|object|null The priced entries, or null when none remain.
	 *
	 * @since 4.8.0
	 */
	protected function keep_priced_details( $details ) {
		if ( null === $details ) {
			return null;
		}

		// A single entry can arrive unwrapped. Normalised rather than passed through, so the
		// filtering below is never skipped — skipping it is the outcome this method prevents.
		$entries = is_array( $details ) ? $details : array( $details );
		$priced  = array();

		foreach ( $entries as $entry ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase --- FedEx API camelCase.
			if ( isset( $entry->ratedShipmentDetails ) ) {
				$priced[] = $entry;
				continue;
			}

			Logger::debug(
				$this->log_prefix . '::keep_priced_details: entry for service ' . $this->describe_service( $entry ) . ' carries no price and was dropped.',
				$this->log_context()
			);
		}

		return empty( $priced ) ? null : $priced;
	}

	/**
	 * Service name of a reply entry, for a log line.
	 *
	 * FedEx sends a string; anything else is coerced rather than concatenated, because a
	 * stdClass here would raise an Error, and run_package_request() catches only Exception.
	 *
	 * @param object $entry Rate reply entry.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function describe_service( $entry ) {
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase --- FedEx API camelCase.
		$service = isset( $entry->serviceType ) ? $entry->serviceType : null;

		return is_scalar( $service ) ? (string) $service : '?';
	}

	/**
	 * Execute wp_remote_post with retry on transport failure or specified HTTP codes.
	 *
	 * @param string $url             Request URL.
	 * @param array  $args            Request arguments.
	 * @param array  $retryable_codes HTTP status codes that trigger a retry.
	 *
	 * @return array|\WP_Error
	 */
	private function wp_remote_post_with_retry( $url, $args, $retryable_codes = array() ) {
		$max_retries = $this->transport_max_retries;
		$delay_ms    = $this->transport_retry_delay_ms;
		$attempt     = 0;

		do {
			if ( $attempt > 0 ) {
				usleep( $delay_ms * 1000 );
				Logger::debug( $this->log_prefix . ': Transport retry attempt ' . $attempt . ' of ' . $max_retries . '.', $this->log_context() );
			}
			$response = wp_remote_post( $url, $args );
			++$attempt;

			if ( $response instanceof \WP_Error ) {
				$delay_ms = $this->transport_retry_delay_ms;
				continue;
			}
			if ( ! in_array( wp_remote_retrieve_response_code( $response ), $retryable_codes, true ) ) {
				return $response;
			}

			// A throttled endpoint says when to come back, and coming back sooner just spends
			// another transaction against the limit that is already refusing us. Honour the
			// header — but only within the budget, because a shopper is waiting on this request
			// and returning the failure beats blocking checkout for the window FedEx names.
			$retry_after_ms = $this->get_retry_after_ms( $response );

			if ( null !== $retry_after_ms ) {
				if ( $retry_after_ms > self::MAX_RETRY_AFTER_MS ) {
					Logger::debug(
						$this->log_prefix . ': endpoint asked for a ' . round( $retry_after_ms / 1000, 1 ) . 's wait, longer than the ' . round( self::MAX_RETRY_AFTER_MS / 1000, 1 ) . 's retry budget; returning without retrying.',
						$this->log_context()
					);

					return $response;
				}

				$delay_ms = $retry_after_ms;
			}
		} while ( $attempt <= $max_retries );

		return $response;
	}

	/**
	 * How long a response asked us to wait, in milliseconds.
	 *
	 * Retry-After is either a number of seconds or an HTTP date; both forms are accepted.
	 *
	 * @param array $response wp_remote_post() response.
	 *
	 * @return int|null Milliseconds to wait, or null when the header is absent or unusable.
	 *
	 * @since 4.8.0
	 */
	private function get_retry_after_ms( $response ) {
		$retry_after = trim( (string) wp_remote_retrieve_header( $response, 'retry-after' ) );

		if ( '' === $retry_after ) {
			return null;
		}

		if ( is_numeric( $retry_after ) ) {
			return max( 0, (int) round( (float) $retry_after * 1000 ) );
		}

		$when = strtotime( $retry_after );

		if ( false === $when ) {
			return null;
		}

		return max( 0, ( $when - time() ) * 1000 );
	}

	/**
	 * Check if Destination Address is Residential.
	 *
	 * @param array $request API Request value.
	 *
	 * @return bool
	 */
	public function residential_address_validation( $request ) {
		$request_body = $this->prepare_request( $request );

		$args = array(
			'headers' => $this->headers,
			'body'    => wp_json_encode( $request_body ),
			'timeout' => 10,
		);

		$transient_key  = $this->get_address_key( $request_body );
		$classification = $transient_key ? get_transient( $transient_key ) : false;
		// If there's a cached classification, return it.
		if ( false !== $classification ) {
			unset( $request_body['requestTimestamp'] );
			Logger::debug( 'CACHED RESPONSE service: address validation, classification: ' . $classification, array( 'request' => $request_body ) );
			$this->shipping_method->notify( '<b>CACHED RESPONSE:</b> service: <b>Address Validation</b> &#10072; classification: <b>' . $classification . '</b>' );

			return $this->is_residential( $classification );
		}

		$response = $this->wp_remote_post_with_retry( $this->api_url . '/address/v1/addresses/resolve', $args, array( 503 ) );
		if ( $response instanceof \WP_Error ) {
			$code          = '?';
			$message       = 'FedEx Rate API no response';
			$response_body = $response->get_error_messages();
			Logger::error(
				'RESPONSE service: address validation, code: ' . $code . ', message: ' . $message,
				array(
					'request'  => $request_body,
					'response' => $response_body,
				)
			);

			$this->shipping_method->notify( '<b>RESPONSE:</b> service: <b>Address Validation</b> &#10072; code: <b>' . $code . '</b> &#10072; message: <b>' . $message . '</b> <a href="#" style="float:right;" class="debug_reveal">Show</a><pre style="font-size: 12px; line-height:1.5; display: none;" class="debug_info">' . print_r( $response_body, true ) . '</pre>' );

			return $this->residential;
		} elseif ( is_array( $response ) && 200 !== wp_remote_retrieve_response_code( $response ) ) {
			$code          = wp_remote_retrieve_response_code( $response );
			$message       = wp_remote_retrieve_response_message( $response );
			$response_body = json_decode( wp_remote_retrieve_body( $response ) );
			Logger::error(
				'RESPONSE service: address validation, code: ' . $code . ', message: ' . $message,
				array(
					'request'  => $request_body,
					'response' => $response_body,
				)
			);

			$this->shipping_method->notify( '<b>RESPONSE:</b> service: <b>Address Validation</b> &#10072; code: <b>' . $code . '</b> &#10072; message: <b>' . $message . '</b> <a href="#" style="float:right;" class="debug_reveal">Show</a><pre style="font-size: 12px; line-height:1.5; display: none;" class="debug_info">' . print_r( $response_body, true ) . '</pre>' );

			return $this->residential;
		} else {
			$code           = is_array( $response ) ? wp_remote_retrieve_response_code( $response ) : '?';
			$response_body  = is_array( $response ) ? json_decode( wp_remote_retrieve_body( $response ) ) : $response;
			$classification = isset( $response_body->output->resolvedAddresses[0]->classification ) ? strtoupper( $response_body->output->resolvedAddresses[0]->classification ) : '?';

			// Cache address classification result.
			if (
				$response
				&& $transient_key
				&& in_array( $classification, array( 'MIXED', 'UNKNOWN', 'BUSINESS', 'RESIDENTIAL' ), true )
			) {
				$days = 'UNKNOWN' === $classification ? 7 : 90;
				set_transient( $transient_key, $classification, DAY_IN_SECONDS * $days );
			}

			Logger::debug(
				'RESPONSE service: address validation, code: ' . $code . ', classification: ' . $classification,
				array(
					'request'  => $request_body,
					'response' => $response_body,
				)
			);

			$this->shipping_method->notify( '<b>RESPONSE:</b> service: <b>Address Validation</b> &#10072; code: <b>' . $code . '</b> &#10072; classification: <b>' . $classification . '</b> <a href="#" style="float:right;" class="debug_reveal">Show</a><pre style="font-size: 12px; line-height:1.5; display: none;" class="debug_info">' . print_r( $response_body, true ) . '</pre>' );

			return $this->is_residential( $classification );
		}
		// phpcs:enable WordPress.PHP.DevelopmentFunctions.error_log_print_r
	}

	/**
	 * Get residential/business classification from FedEx address validation response.
	 *
	 * @param string $classification The classification returned from FedEx (MIXED, UNKNOWN, BUSINESS, RESIDENTIAL).
	 * @return bool True if residential, false if business or default to zone setting.
	 */
	private function is_residential( string $classification ): bool {
		$classification_data = array(
			'MIXED'       => $this->residential,
			'UNKNOWN'     => $this->residential,
			'BUSINESS'    => false,
			'RESIDENTIAL' => true,
		);

		if ( ! isset( $classification_data[ $classification ] ) ) {
			return $this->residential;
		}

		return $classification_data[ $classification ];
	}

	/**
	 * Generate key from address data.
	 *
	 * @param  array $request Address validation request.
	 *
	 * @return string|false
	 */
	private function get_address_key( $request ) {
		if ( ! isset( $request['addressesToValidate'][0]['address'] ) || ! is_array( $request['addressesToValidate'][0]['address'] ) ) {
			return false;
		}
		$address = $request['addressesToValidate'][0]['address'];
		array_walk_recursive(
			$address,
			function ( &$element ) {
				$element = strtoupper( $element );
			}
		);

		$address_encoded = wp_json_encode( $address );
		return $address_encoded ? 'fedex_address_validation_' . md5( $address_encoded ) : false;
	}

	/**
	 * Prepare request elements.
	 *
	 * Depending on the request type, some elements need to be renamed or removed.
	 * This function will loop through the request array, and modify the keys and values as needed.
	 *
	 * @param array  $request      The request array.
	 * @param string $request_type The request type.
	 * @param string $parent_key   The parent key.
	 *
	 * @return array
	 */
	public function prepare_request( $request, $request_type = '', $parent_key = '' ) {

		if ( ! is_array( $request ) ) {
			return array();
		}

		$updated_request = array();
		foreach ( $request as $key => $value ) {
			$original_key = $key;

			if ( 'AccountNumber' === $key ) {
				$value = array( 'value' => $value );
			}

			if ( 'PackageCount' === $key ) {
				$key = 'totalPackageCount';
			}

			if ( 'freight' === $request_type && 'PackagingType' === $key ) {
				continue;
			}

			if ( 'freight' === $request_type && 'RequestedShipment' === $key ) {
				$key = 'freightRequestedShipment';
			}

			if ( 'freight' === $request_type && 'PhysicalPackaging' === $key ) {
				$key = 'subPackagingType';
			}

			if ( 'freight' === $request_type && 'FedExFreightAccountNumber' === $key ) {
				$key   = 'accountNumber';
				$value = array( 'value' => $value );
			}

			if ( 'freight' === $request_type && 'RequestedPackageLineItems' === $key ) {
				$value = array( $value );
			}

			if ( 'freight' === $request_type && 'LineItems' === $key ) {
				$key   = 'lineItem';
				$value = array( $value );
			}

			if ( 'freight' === $request_type && 'Packaging' === $key ) {
				$key = 'subPackagingType';
			}

			if ( 'freight' === $request_type && 'LineItems' === $parent_key && 'Id' === $key ) {
				$value = (string) $value;
			}

			if ( 'freight' === $request_type && 'AssociatedFreightLineItems' === $key ) {
				$value = array( $value );
			}

			if ( 'SmartPostDetail' === $key ) {
				$key = 'smartPostInfoDetail';
			}

			if ( 'ShipTimestamp' === $key ) {
				$value = wp_date( 'Y-m-d', strtotime( $value ) );
				$key   = 'shipDateStamp';
			}

			if ( 'InsuredValue' === $key ) {
				$key = 'declaredValue';
			}

			if ( 'SpecialServicesRequested' === $key ) {
				$key = 'shipmentSpecialServices';
			}

			// ShippingChargesPayment is LTL-only; strip it for all non-freight types including international_freight.
			if ( ( 'freight' !== $request_type && 'ShippingChargesPayment' === $key ) || 'SequenceNumber' === $key || 'GroupNumber' === $key || 'DropoffType' === $key || '' === $value ) {
				continue;
			}

			$updated_request[ lcfirst( $key ) ] = is_array( $value ) ? $this->prepare_request( $value, $request_type, $original_key ) : $value;
		}

		return $updated_request;
	}

	/**
	 * Process result.
	 *
	 * @param array  $request Request data.
	 * @param object $result API response or result.
	 * @param string $request_type Request type.
	 *
	 * @return void
	 */
	public function process_result( $request, $result, $request_type ) {
		// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase --- FedEx API provides an object with camelCase properties and method
		$rate_reply_details = $this->get_rate_reply_details( $result );
		if ( null === $rate_reply_details ) {
			return;
		}

		$store_currency = get_woocommerce_currency();

		foreach ( $rate_reply_details as $quote ) {

			// Prevent double rates we should already have rate for "FedEx SmartPost®" both rates have same service key "SMART_POST".
			if (
				isset( $quote->serviceType ) && 'SMART_POST' === $quote->serviceType &&
				isset( $quote->serviceName ) && 'FedEx SmartPost®' !== $quote->serviceName ) {
				continue;
			}

			if ( isset( $quote->serviceName ) && 'FedEx International Ground®' === $quote->serviceName ) {
				$quote->serviceType = 'INTERNATIONAL_GROUND';
			}

			// Requests set servicesNeededOnRateFailure, so FedEx can return entries for services
			// it could not rate; those carry no ratedShipmentDetails. Such a quote was already
			// discarded further down by the empty( $details ) check, but only after reading
			// undefined properties — which emits a notice per quote on a debug-enabled store.
			// Checked here so both response shapes are handled up front.
			if ( ! isset( $quote->serviceType ) || ! isset( $quote->ratedShipmentDetails ) ) {
				Logger::debug(
					$this->log_prefix . '::process_result: quote for service ' . $this->describe_service( $quote ) . ' carries no price and was skipped.',
					$this->log_context()
				);
				continue;
			}

			if ( is_array( $quote->ratedShipmentDetails ) ) {
				$details = false;
				foreach ( $quote->ratedShipmentDetails as $i => $d ) {
					// Attempt to return Rate Type set in Shipping Zone settings, ACCOUNT or LIST.
					if (
						strstr( $d->rateType, $this->shipping_method->get_request_type() ) &&
						$d->currency === $store_currency
					) {
						$details = $quote->ratedShipmentDetails[ $i ];
						break;
					}
				}

				// If first attempt don't return Shipment Details due to currency mismatch, look for PREFERRED rate.
				if ( ! $details ) {
					foreach ( $quote->ratedShipmentDetails as $i => $d ) {
						if (
							strstr( $d->rateType, 'PREFERRED_CURRENCY' ) &&
							$d->currency === $store_currency
						) {
							$details = $quote->ratedShipmentDetails[ $i ];
							break;
						}
					}
				}
			} else {
				$details = $quote->ratedShipmentDetails;
			}

			if ( empty( $details ) ) {
				// Entries came back but none matched the requested rate type and the store
				// currency. Freight cannot ask for PREFERRED_CURRENCY (the LTL enum has no such
				// value), so this drop must leave a trace or a currency mismatch is unsupportable.
				Logger::debug(
					$this->log_prefix . '::process_result: quote for service ' . $this->describe_service( $quote ) . ' was dropped: no ratedShipmentDetails entry matched rate type ' . $this->shipping_method->get_request_type() . ' in store currency ' . $store_currency . '.',
					$this->log_context()
				);
				continue;
			}

			$currency  = isset( $details->currency ) ? $details->currency : '';
			$rate_name = strval( $this->shipping_method->get_service( $quote->serviceType ) );

			/**
			 * Allow third party to hide the check store currency debug text.
			 *
			 * @param boolean $flag Flag for hide or display the debug text.
			 * @param string  $currency Store currency.
			 * @param string  $details Rate shipment details.
			 * @param object  $shipping_method Shipping method.
			 *
			 * @since 3.7.0
			 */
			if ( apply_filters( 'woocommerce_shipping_fedex_check_store_currency', true, $currency, $details, $this->shipping_method ) && ( $store_currency !== $currency ) ) {
				/* translators: 1: FedEx service name 2: currency for the rate 3: store's currency */
				$this->shipping_method->notify( sprintf( __( '[FedEx] Rate for %1$s is in %2$s but store currency is %3$s.', 'woocommerce-shipping-fedex' ), $rate_name, $currency, $store_currency ) );
				continue;
			}

			$rate_code = strval( $quote->serviceType );
			$rate_id   = $this->shipping_method->get_rate_id( $rate_code );
			$rate_cost = floatval( $details->totalNetCharge );

			if ( 'smartpost' === $request_type ) {
				$qty       = isset( $request['RequestedShipment']['PackageCount'] ) ? $request['RequestedShipment']['PackageCount'] : 1;
				$rate_cost = $rate_cost * intval( $qty );
			}

			$this->shipping_method->prepare_rate( $rate_code, $rate_id, $rate_name, $rate_cost, $currency, $details, $request_type );
		}
		// phpcs:enable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
	}
}
