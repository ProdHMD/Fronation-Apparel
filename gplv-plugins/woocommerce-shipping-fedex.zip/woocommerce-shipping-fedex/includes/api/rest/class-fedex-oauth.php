<?php
/**
 * FedEx OAuth class file.
 *
 * @package WC_Shipping_Fedex
 */

namespace WooCommerce\FedEx;

defined( 'ABSPATH' ) || exit;

use WC_Shipping_Fedex;

/**
 * Class FedEx_OAuth
 *
 * Handles the OAuth authentication for the FedEx REST API.
 *
 * @package WooCommerce\FedEx
 */
class FedEx_OAuth {

	/**
	 * Duration in seconds to cache authentication failures.
	 * Prevents repeated failed API calls when credentials are incorrect.
	 *
	 * @var int
	 */
	const FAILURE_CACHE_DURATION = 300; // 5 minutes

	/**
	 * WC_Shipping_Fedex method.
	 *
	 * @var WC_Shipping_Fedex
	 */
	protected $shipping_method;

	/**
	 * The client ID used to authenticate with the FedEx OAuth API.
	 *
	 * @var string
	 */
	protected $client_id;
	/**
	 * The client secret used to authenticate with the FedEx OAuth API.
	 *
	 * @var string
	 */
	protected $client_secret;
	/**
	 * The URL for the FedEx OAuth API endpoint.
	 *
	 * @var string
	 */
	protected $endpoint;
	/**
	 * The OAuth scope to request. An empty string means no `scope` parameter is
	 * sent (the FedEx parcel OAuth does not use one; FedEx Freight requires `fxf-api`).
	 *
	 * @var string
	 */
	protected $scope = '';
	/**
	 * The name of the transient used to store the access token.
	 *
	 * @var string
	 */
	protected $access_token_transient_name;

	/**
	 * The name of the transient used to store authentication failures.
	 *
	 * @var string
	 */
	protected $auth_failure_transient_name;
	/**
	 * Prefix identifying this connection in log messages. Subclasses override it so freight
	 * and parcel token activity can be told apart in the WooCommerce logs.
	 *
	 * @var string
	 */
	protected $log_prefix = 'FedEx_OAuth';

	/**
	 * Constructor.
	 *
	 * Subclasses configure themselves by overriding get_endpoint(), get_scope(),
	 * get_environment_key() and get_transient_prefix() rather than replacing this
	 * initialization, so state added here is never missed by a child client.
	 *
	 * @param WC_Shipping_Fedex $fedex_shipping_method The FedEx shipping method object.
	 * @param string|null       $client_id             Client ID. Defaults to the parcel API key from the settings.
	 * @param string|null       $client_secret         Client secret. Defaults to the parcel API secret from the settings.
	 *
	 * @since 4.8.0 Added the $client_id and $client_secret parameters.
	 */
	public function __construct( $fedex_shipping_method, $client_id = null, $client_secret = null ) {
		$this->shipping_method = $fedex_shipping_method;
		$this->client_id       = null === $client_id ? $fedex_shipping_method->get_client_id() : $client_id;
		$this->client_secret   = null === $client_secret ? $fedex_shipping_method->get_client_secret() : $client_secret;

		$this->scope    = $this->get_scope();
		$this->endpoint = $this->get_endpoint();

		$credentials_hash                  = md5( $this->client_id . $this->client_secret . $this->get_environment_key() );
		$this->access_token_transient_name = $this->get_transient_prefix() . '_access_token_' . $credentials_hash;
		$this->auth_failure_transient_name = $this->get_transient_prefix() . '_auth_failure_' . $credentials_hash;
	}

	/**
	 * The OAuth token endpoint for this connection's environment.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_endpoint() {
		return $this->shipping_method->is_production() ? 'https://apis.fedex.com/oauth/token' : 'https://apis-sandbox.fedex.com/oauth/token';
	}

	/**
	 * The OAuth scope to request. An empty string sends no `scope` parameter.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_scope() {
		return '';
	}

	/**
	 * Environment identifier mixed into the transient name, so sandbox and production
	 * tokens for the same credentials never share a cache entry.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_environment_key() {
		return $this->shipping_method->api_mode;
	}

	/**
	 * Transient name prefix for this connection's token and failure caches.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_transient_prefix() {
		return 'woocommerce_fedex_oauth';
	}

	/**
	 * Human-readable name for this connection, used in admin notices.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_connection_label() {
		return __( 'FedEx REST API', 'woocommerce-shipping-fedex' );
	}

	/**
	 * Log context tagged with this connection's own environment.
	 *
	 * Logger::log() otherwise derives the log file from the shipping method's api_mode — the
	 * parcel environment — so freight token activity lands in the parcel log whenever the two
	 * environments differ. Identical to the default for the parcel connection.
	 *
	 * @param array $context Existing log context.
	 *
	 * @return array
	 *
	 * @since 4.8.0
	 */
	protected function log_context( $context = array() ) {
		if ( ! isset( $context['source'] ) ) {
			$context['source'] = 'plugin-woocommerce-shipping-fedex-' . $this->shipping_method->api_type . '-' . $this->get_environment_key();
		}

		return $context;
	}

	/**
	 * Check if we've successfully authenticated.
	 *
	 * @return bool
	 */
	public function is_authenticated() {
		return (bool) $this->get_access_token();
	}

	/**
	 * Clear the cached access token and any cached authentication failures.
	 *
	 * @return void
	 */
	public function clear_access_token() {
		delete_transient( $this->access_token_transient_name );
		$this->clear_failure_cache();
		Logger::debug( $this->log_prefix . '::clear_access_token: Access token and failure cache cleared.', $this->log_context() );
	}

	/**
	 * Validate credentials by attempting to get a token.
	 *
	 * @param string $client_id     The client ID to validate.
	 * @param string $client_secret The client secret to validate.
	 *
	 * @return array Array with 'success' boolean and 'message' string.
	 */
	public function validate_credentials( $client_id, $client_secret ) {
		if ( empty( $client_id ) || empty( $client_secret ) ) {
			return array(
				'success' => false,
				'message' => __( 'Client ID and Client Secret are required.', 'woocommerce-shipping-fedex' ),
			);
		}

		$response = $this->get_access_token_from_fedex( $client_id, $client_secret );

		if ( $response['success'] && ! empty( $response['access_token'] ) ) {
			return array(
				'success' => true,
				'message' => sprintf(
					/* translators: %s: connection name, e.g. "FedEx REST API" */
					__( 'Successfully authenticated with %s.', 'woocommerce-shipping-fedex' ),
					$this->get_connection_label()
				),
			);
		}

		return array(
			'success' => false,
			'message' => sprintf(
				/* translators: %1$s: connection name, e.g. "FedEx REST API". %2$s: what to check next. */
				__( 'Failed to authenticate with %1$s. %2$s', 'woocommerce-shipping-fedex' ),
				$this->get_connection_label(),
				$this->get_validation_failure_hint()
			),
		);
	}

	/**
	 * What to check when this connection cannot authenticate.
	 *
	 * Shown on the settings screen as well as in the save-time message, because the status row
	 * is what a merchant sees on every later visit.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	public function get_failure_hint() {
		return $this->get_validation_failure_hint();
	}

	/**
	 * What to check when save-time credential validation fails.
	 *
	 * The freight connection overrides this: with its own environment toggle, a correct
	 * production key tested against the QA host fails the same way as a wrong key.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_validation_failure_hint() {
		return __( 'Please verify your API key and secret are correct.', 'woocommerce-shipping-fedex' );
	}

	/**
	 * Check if there's a cached authentication failure.
	 *
	 * @return bool True if there's a cached failure, false otherwise.
	 */
	private function has_cached_failure() {
		return false !== get_transient( $this->auth_failure_transient_name );
	}

	/**
	 * Cache an authentication failure to prevent repeated failed API calls.
	 * Note: Server errors (500, 503) are NOT cached as they are temporary issues.
	 *
	 * @return void
	 */
	private function cache_failure() {
		set_transient( $this->auth_failure_transient_name, time(), self::FAILURE_CACHE_DURATION );
		Logger::warning( $this->log_prefix . '::cache_failure: Authentication failure cached for ' . self::FAILURE_CACHE_DURATION . ' seconds to prevent repeated failed API calls.', $this->log_context() );
	}

	/**
	 * Clear any cached authentication failure.
	 *
	 * @return void
	 */
	private function clear_failure_cache() {
		delete_transient( $this->auth_failure_transient_name );
	}

	/**
	 * Get an access token.
	 *
	 * @param bool $force_refresh Force token refresh.
	 *
	 * @return string|bool
	 */
	public function get_access_token( $force_refresh = false ) {

		// No credentials to authenticate with. That is the default state of a fresh install
		// and of every store that does not use FedEx Freight, not a failure, so return quietly.
		// Without this the request below reports HTTP 0, which cache_failure() deliberately
		// does not cache (it cannot tell "unconfigured" from a network blip), so two error
		// lines would be written on every shipping-method instantiation, forever — and errors
		// are logged even when debug mode is off.
		if ( empty( $this->client_id ) || empty( $this->client_secret ) ) {
			Logger::debug( $this->log_prefix . '::get_access_token: No credentials configured; skipping token request.', $this->log_context() );
			return false;
		}

		// Check for cached authentication failure (unless force refresh is requested).
		if ( ! $force_refresh && $this->has_cached_failure() ) {
			Logger::debug( $this->log_prefix . '::get_access_token: Returning early due to cached authentication failure. Will retry after cache expires.', $this->log_context() );
			return false;
		}

		$access_token = get_transient( $this->access_token_transient_name );

		if ( false === $access_token ) {
			Logger::debug( $this->log_prefix . '::get_access_token: Access token not found in cache or expired. Requesting new token.', $this->log_context() );
		} elseif ( $force_refresh ) {
			Logger::debug( $this->log_prefix . '::get_access_token: Force refresh requested. Requesting new token.', $this->log_context() );
		} else {
			Logger::debug( $this->log_prefix . '::get_access_token: Using cached access token.', $this->log_context() );
		}

		if ( false !== $access_token && ! $force_refresh ) {
			return $access_token;
		}

		$response = $this->get_access_token_from_fedex( $this->client_id, $this->client_secret );

		if ( ! $response['success'] || empty( $response['access_token'] ) || empty( $response['expires_in'] ) ) {
			Logger::error( $this->log_prefix . '::get_access_token: Invalid response from FedEx OAuth API.', $this->log_context() );

			// Only cache authentication failures, not temporary server errors (500, 503).
			// Server errors should be retried on next request.
			$http_code = isset( $response['http_code'] ) ? absint( $response['http_code'] ) : 0;
			if ( $http_code < 500 && 0 !== $http_code ) {
				$this->cache_failure();
			} else {
				Logger::debug( $this->log_prefix . "::get_access_token: Not caching failure - HTTP $http_code is a temporary server error that may resolve quickly.", $this->log_context() );
			}

			return false;
		}

		// Clear any previous failure cache on successful authentication.
		$this->clear_failure_cache();

		$expires_in = absint( $response['expires_in'] );

		// Unusual short token expiration, do not cache.
		if ( $expires_in <= 60 ) {
			Logger::warning( "Short token expiry: {$expires_in}s. Not caching.", $this->log_context() );
			// Just return the token, don't cache it.
			return $response['access_token'];
		}

		// Store token with 60 second buffer to prevent edge cases where token expires during request.
		$cache_duration = $expires_in - 60;

		set_transient( $this->access_token_transient_name, $response['access_token'], $cache_duration );

		Logger::debug( $this->log_prefix . "::get_access_token: New token cached successfully. Expires in {$expires_in} seconds, cached for {$cache_duration} seconds.", $this->log_context() );

		return $response['access_token'];
	}

	/**
	 * Get an access token from the FedEx OAuth API.
	 *
	 * @param string $client_id     Client ID to use for authentication.
	 * @param string $client_secret Client secret to use for authentication.
	 *
	 * @return array The response from the FedEx OAuth API with 'success', 'access_token', 'expires_in', and 'http_code'.
	 */
	private function get_access_token_from_fedex( $client_id, $client_secret ) {
		if ( ! $client_id || ! $client_secret ) {
			Logger::error( $this->log_prefix . '::get_access_token_from_fedex: Client ID or Client Secret is missing.', $this->log_context() );
			return array(
				'success'      => false,
				'http_code'    => 0,
				'access_token' => '',
				'expires_in'   => 0,
			);
		}

		$headers = array(
			'Content-Type' => 'application/x-www-form-urlencoded',
		);

		$body = array(
			'grant_type'    => 'client_credentials',
			'client_id'     => $client_id,
			'client_secret' => $client_secret,
		);

		// FedEx Freight requires a `scope` parameter; the parcel OAuth does not send one.
		if ( '' !== $this->scope ) {
			$body['scope'] = $this->scope;
		}

		$response = wp_remote_post(
			$this->endpoint,
			array(
				'headers' => $headers,
				'body'    => $body,
			)
		);

		$response_body = $this->get_response_body( $response );
		$http_code     = is_wp_error( $response ) ? 0 : wp_remote_retrieve_response_code( $response );

		if ( is_wp_error( $response ) || empty( $response_body->access_token ) || empty( $response_body->expires_in ) ) {
			$error_message = is_wp_error( $response ) ? $response->get_error_message() : $this->retrieve_error_message_from_response( $response_body );

			Logger::error( $this->log_prefix . "::get_access_token_from_fedex: The FedEx OAuth endpoint returned the following error: $error_message (HTTP $http_code)", $this->log_context() );

			return array(
				'success'      => false,
				'http_code'    => $http_code,
				'access_token' => '',
				'expires_in'   => 0,
			);
		}

		Logger::debug( $this->log_prefix . '::get_access_token_from_fedex: Successfully obtained new access token from FedEx.', $this->log_context() );

		return array(
			'success'      => true,
			'http_code'    => $http_code,
			'access_token' => isset( $response_body->access_token ) ? $response_body->access_token : '',
			'expires_in'   => isset( $response_body->expires_in ) ? $response_body->expires_in : 0,
		);
	}

	/**
	 * Get response body.
	 *
	 * @param  array $response FedEx API response.
	 *
	 * @return object
	 */
	private function get_response_body( $response ) {
		return json_decode( wp_remote_retrieve_body( $response ) );
	}

	/**
	 * Get error message from FedEx API response.
	 *
	 * @param  object $response FedEx API response.
	 *
	 * @return string
	 */
	private function retrieve_error_message_from_response( $response ) {
		$message = '';
		if ( isset( $response->errors ) && is_array( $response->errors ) ) {
			foreach ( $response->errors as $error ) {
				if ( empty( $error->code ) || empty( $error->message ) ) {
					continue;
				}

				$message .= "\n" . $error->code . ': ' . $error->message;
			}
		}

		// The freight token host answers in the RFC 6749 shape (error / error_description),
		// which the parcel-shaped loop above cannot read; without this the log line for a
		// freight auth failure carries no cause at all.
		if ( '' === $message && isset( $response->error ) && is_string( $response->error ) ) {
			$message = $response->error;

			if ( isset( $response->error_description ) && is_string( $response->error_description ) ) {
				$message .= ': ' . $response->error_description;
			}
		}

		return $message;
	}
}
