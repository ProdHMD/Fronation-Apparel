<?php
/**
 * FedEx Freight OAuth class file.
 *
 * @package WC_Shipping_Fedex
 */

namespace WooCommerce\FedEx;

defined( 'ABSPATH' ) || exit;

/**
 * Class FedEx_Freight_OAuth
 *
 * OAuth client for the FedEx Freight LTL platform, which the spinoff moved onto its own
 * developer portal with separate credentials, token host, `fxf-api` scope and environment.
 * The token flow itself is identical to parcel, so only the configuration is overridden.
 *
 * @package WooCommerce\FedEx
 *
 * @since 4.8.0
 */
class FedEx_Freight_OAuth extends FedEx_OAuth {

	/**
	 * Prefix identifying freight token activity in the logs.
	 *
	 * @var string
	 *
	 * @since 4.8.0
	 */
	protected $log_prefix = 'FedEx_Freight_OAuth';

	/**
	 * Human-readable name for this connection, used in admin notices.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_connection_label() {
		return __( 'FedEx Freight API', 'woocommerce-shipping-fedex' );
	}

	/**
	 * The FedEx Freight token endpoint, which has its own sandbox host.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_endpoint() {
		return $this->shipping_method->is_freight_production()
			? 'https://auth.fedexfreight.com/am/oauth2/access_token'
			: 'https://auth-qa.fedexfreight.com/am/oauth2/access_token';
	}

	/**
	 * FedEx Freight requires a scope; the parcel OAuth does not send one.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_scope() {
		return 'fxf-api';
	}

	/**
	 * Freight has its own production/sandbox toggle, independent of the parcel environment.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_environment_key() {
		return $this->shipping_method->is_freight_production() ? 'production' : 'test';
	}

	/**
	 * Freight tokens are cached separately from parcel tokens.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_transient_prefix() {
		return 'woocommerce_fedex_freight_oauth';
	}

	/**
	 * A correct production key tested against the QA host fails like a wrong key, so the
	 * environment toggle belongs in the hint.
	 *
	 * @return string
	 *
	 * @since 4.8.0
	 */
	protected function get_validation_failure_hint() {
		return __( 'Please verify your API key and secret are correct, and that the Freight production key setting matches the environment the credentials were issued for.', 'woocommerce-shipping-fedex' );
	}
}
