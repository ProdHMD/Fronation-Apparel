=== WooCommerce FedEx Shipping ===
Contributors: woocommerce, automattic
Tags: woocommerce, shipping, fedex, shipping rates
Requires at least: 7.0
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: woocommerce
WC requires at least: 10.9
WC tested up to: 11.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Obtain shipping rates dynamically via the FedEx API for your orders.

== Description ==

The FedEx extension obtains shipping rates dynamically from the FedEx API during cart and checkout.

It needs a store based in the United States or Canada, and a store currency of USD or CAD. A FedEx account and FedEx API credentials are required.

More information at [WooCommerce FedEx Shipping](https://woocommerce.com/products/fedex-shipping-module/).
