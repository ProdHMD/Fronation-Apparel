
jQuery(function ($) {
	'use strict';
	try {

		// Shared lightcase options for every gift popup. onFinish operates on the open
		// case so it works for any modal (eligible gifts, gift products, force gifts).
		var fgfPopupOptions = {
			onFinish: {
				fgf: function () {
					var lc = $('#lightcase-case');
					lc.find('.owl-nav').remove();
					lc.find('.owl-dots').remove();
					lightcase.resize();
					$(document.body).trigger('fgf-enhanced-carousel');
					$(document.body).trigger('fgf_lightcase_finished');
				}
			},
			onClose: {
				lc: function () {
					$(document.body).trigger('fgf_lightcase_closed');
				}
			}
		};

		/**
		 * Bind every gift popup trigger carrying the fgf-gifts-popup-trigger class
		 * directly through lightcase: eligible gifts, gift products and the force
		 * checkout gifts popup. Re-run on every cart/checkout refresh so freshly
		 * rendered triggers get bound; lightcase's init() unbinds before binding, so
		 * repeat calls never stack handlers. Each bound trigger is flagged so the
		 * delegated fallback below leaves it alone (avoids opening the modal twice).
		 *
		 * Each trigger opens its own modal via its href; a trigger without one (e.g.
		 * a custom button or href="#") falls back to the main gift products popup.
		 *
		 * @since 12.5.0
		 */
		$(document.body).on('fgf-enhanced-lightcase', function ( ) {
			var $triggers = $('.fgf-gifts-popup-trigger');
			if (!$triggers.length) {
				return;
			}

			$triggers.each(function () {
				var href = $(this).attr('href');
				if (!href || '#' === href) {
					$(this).attr('href', '#fgf_gift_products_modal');
				}
			}).lightcase(fgfPopupOptions).attr('data-fgf-lc-bound', '1');
		});

		/**
		 * Delegated fallback for triggers the class based binding above cannot reach:
		 *   - block cart/checkout notice triggers whose fgf-gifts-popup-trigger class
		 *     the notice sanitizer strips (so only the href survives);
		 *   - triggers React re-renders after a block cart update, which replaces the
		 *     bound node with a fresh, unbound one (no data-fgf-lc-bound flag).
		 *
		 * Delegation on document.body survives every re-render. Triggers already bound
		 * directly are flagged and skipped here, so lightcase's own click handler opens
		 * them and the modal never opens twice.
		 *
		 * @since 12.5.0
		 */
		$(document.body).on('click', '.fgf-gifts-popup-trigger, a[href^="#fgf-eligible-gifts-modal-"], a[href="#fgf_gift_products_modal"]', function (event) {
			var trigger = $(this);

			// Already bound directly by lightcase init; let that handler open it.
			if (trigger.attr('data-fgf-lc-bound')) {
				return;
			}

			var target = trigger.attr('href');

			// Triggers with no usable href fall back to the gift products modal.
			if (!target || '#' === target) {
				target = '#fgf_gift_products_modal';
			}

			if (!$(target).length) {
				return;
			}

			event.preventDefault();

			trigger.lightcase('start', $.extend({ href: target }, fgfPopupOptions));
		});

		/**
		 * Call to close light case popup.
		 *
		 * @since 12.4.0
		 */
		$(document.body).on('fgf_close_lightcase', function ( ) {
			$('.lightcase-icon-close').trigger('click');
		});

		// Initialize carousel when cart updated.
		$(document.body).on('updated_wc_div', function ( ) {
			$(document.body).trigger('fgf-enhanced-lightcase');
		});

		// Initialize carousel when checkout updated.
		$(document.body).on('updated_checkout', function ( ) {
			$(document.body).trigger('fgf-enhanced-lightcase');
		});

		$(document.body).trigger('fgf-enhanced-lightcase');
	} catch (err) {
		window.console.log(err);
	}

});
