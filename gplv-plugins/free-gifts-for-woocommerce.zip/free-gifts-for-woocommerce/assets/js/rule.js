/* global fgf_rule_params, ajaxurl, wp */

jQuery(function ($) {
	'use strict';

	var FGF_Admin = {
		init: function ( ) {
			this.trigger_on_page_load();
			// rules tab
			$(document).on('change', '.fgf_rule_types', this.toggle_rule_type);
			$(document).on('change', '.fgf_gift_type', this.toggle_gift_type);
			$(document).on('change', '.fgf_bogo_gift_type', this.toggle_bogo_gift_type);
			$(document).on('change', '.fgf_buy_product_type', this.toggle_buy_product_type);
			$(document).on('change', '.fgf_get_product_type', this.toggle_get_product_type);
			$(document).on('change', '.fgf_bogo_gift_repeat', this.toggle_bogo_gift_repeat);
			$(document).on('change', '.fgf_bogo_gift_repeat_mode', this.toggle_bogo_gift_repeat_mode);
			$(document).on('change', '.fgf-subtotal-gift-type', this.toggle_subtotal_gift_type);
			$(document).on('change', '.fgf-coupon-gift-type', this.toggle_coupon_gift_type);
			$(document).on('change', '.fgf-subtotal-repeat-gift', this.toggle_subtotal_repeat_gift);
			$(document).on('change', '.fgf-subtotal-repeat-gift-mode', this.toggle_subtotal_repeat_gift_mode);
			$(document).on('change', '.fgf-rule-bulk-gift-selection-type-field', this.toggle_bulk_gift_type);
			$(document).on('change', '.fgf-rule-bulk-reward-type-field', this.toggle_bulk_reward_type);
			$(document).on('click', '.fgf-bulk-rule-header', this.toggle_bulk_rule_collapse);
			$(document).on('click', '.fgf-bulk-rules-toggle-all', this.toggle_all_bulk_rules);
			$(document).on('change keyup', '.fgf-bulk-rule-wrapper input, .fgf-bulk-rule-wrapper select', this.refresh_bulk_rule_summary);
			$(document).on('change', '.fgf-gift-selection-field, .fgf-variation-selection-field', this.toggle_automatic_gift_price_consider);
			$(document).on('change', '.fgf-gift-reward-type-field', this.toggle_gift_reward_type);

			// Bulk Rule
			$(document).on('click', '.fgf-add-bulk-rule', this.add_bulk_rule);
			$(document).on('click', '.fgf-remove-bulk-rule', this.remove_bulk_rule);

			$(document).on('change', '.fgf_rule_show_notice', this.toggle_notice);
        	$(document).on('change', '.fgf-rule-show-bogo-eligible-notice-field', this.toggle_bogo_eligible_notice);
			$(document).on('change', '.fgf-rule-show-bulk-eligible-notice-field', this.toggle_bulk_eligible_notice);
			$(document).on('change', '.fgf_user_filter_type', this.toggle_user_filter_type);
			$(document).on('change', '.fgf_product_filter_type', this.toggle_product_filter_type);
			$(document).on('change', '.fgf_applicable_products_type', this.toggle_applicable_products_type);
			$(document).on('change', '.fgf_applicable_categories_type', this.toggle_applicable_categories_type);
			$(document).on('change', '.fgf-filter-coupon-type', this.toggle_filter_coupon_type);
			$(document).on('change', '.fgf-rule-filter-coupon-applicable-type', this.toggle_filter_coupon_applicable_type);
			$(document).on('click', '.fgf_reset_rule_usage_count', this.reset_rule_usage_count);
			$(document).on('change', '.fgf-rule-total-type', this.toggle_rule_total_type);
			$(document).on('change', '.fgf-rule-subtotal-type', this.toggle_rule_subtotal_type);
			$(document).on('change', '.fgf-bulk-pricing-total-type', this.toggle_bulk_pricing_total_type);
			$(document).on('change', '.fgf_rule_allowed_user_type', this.toggle_rule_allowed_user_type);
			$(document).on('change', '.fgf_rule_user_purchased_order_count_type', this.toggle_rule_user_purchased_order_count_type);
			$(document).on('change', '.fgf-rule-restrict-by-wocommerce-coupon-type', this.toggle_rule_restrict_by_wocommerce_coupon_type);
			$(document).on('click', '.fgf-delete-uploaded-img', this.delete_uploaded_image);
			$(document).on('click', '.fgf-upload-img', this.open_wp_frame);

			//Tabbed rule panel.
			$(document).on('fgf-init-tabbed-panels', this.tabbed_rule_panels).trigger('fgf-init-tabbed-panels');

		}, trigger_on_page_load: function ( ) {
			// rules tab
			this.rule_type('.fgf_rule_types');
			this.notice('.fgf_rule_show_notice');
			this.bogo_eligible_notice('.fgf-rule-show-bogo-eligible-notice-field');
			this.bulk_eligible_notice('.fgf-rule-show-bulk-eligible-notice-field');
			this.user_filter_type('.fgf_user_filter_type');
			this.product_filter_type('.fgf_product_filter_type');
			this.filter_coupon_type('.fgf-filter-coupon-type');
			this.rule_total_type('.fgf-rule-total-type');
			this.rule_subtotal_type('.fgf-rule-subtotal-type');
			this.rule_allowed_user_type('.fgf_rule_allowed_user_type');
			this.rule_restrict_by_wocommerce_coupon_type('.fgf-rule-restrict-by-wocommerce-coupon-type');
			this.sortable_default_fields();

		}, toggle_rule_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.rule_type($this);
		}, toggle_gift_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.gift_type($this);
		}, toggle_bogo_gift_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.bogo_gift_type($this);
		}, toggle_buy_product_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.buy_product_type($this);
		}, toggle_get_product_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.get_product_type($this);
		}, toggle_bogo_gift_repeat: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.bogo_gift_repeat($this);
		}, toggle_bogo_gift_repeat_mode: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.bogo_gift_repeat_mode($this);
		}, toggle_subtotal_gift_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.subtotal_gift_type($this);
		}, toggle_coupon_gift_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.coupon_gift_type($this);
		}, toggle_subtotal_repeat_gift: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.subtotal_repeat_gift($this);
		}, toggle_subtotal_repeat_gift_mode: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.subtotal_repeat_gift_mode($this);
		}, toggle_bulk_gift_type: function (event) {
			event.preventDefault( );
			FGF_Admin.bulk_gift_type($(event.currentTarget));
		}, toggle_gift_reward_type: function (event) {
			event.preventDefault( );
			FGF_Admin.gift_reward_type($(event.currentTarget));
		}, toggle_notice: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.notice($this);
		}, toggle_bogo_eligible_notice: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.bogo_eligible_notice($this);
		}, toggle_bulk_eligible_notice: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.bulk_eligible_notice($this);
		},toggle_user_filter_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.user_filter_type($this);
		}, toggle_product_filter_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.product_filter_type($this);
		}, toggle_applicable_products_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.applicable_products_type($this);
		}, toggle_applicable_categories_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);
			FGF_Admin.applicable_categories_type($this);
		}, toggle_filter_coupon_type: function (event) {
			event.preventDefault( );
			FGF_Admin.filter_coupon_type($(event.currentTarget));
		}, toggle_filter_coupon_applicable_type: function (event) {
			event.preventDefault( );
			FGF_Admin.filter_coupon_applicable_type($(event.currentTarget));
		}, toggle_rule_total_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.rule_total_type($this);
		}, toggle_rule_subtotal_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.rule_subtotal_type($this);
		}, toggle_bulk_pricing_total_type: function (event) {
			event.preventDefault( );

			   FGF_Admin.bulk_pricing_total_type($(event.currentTarget));
		}, toggle_rule_allowed_user_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.rule_allowed_user_type($this);
		}, toggle_rule_user_purchased_order_count_type: function (event) {
			event.preventDefault( );
			var $this = $(event.currentTarget);

			FGF_Admin.rule_user_purchased_order_count_type($this);
		}, toggle_rule_restrict_by_wocommerce_coupon_type: function (event) {
			event.preventDefault( );

			FGF_Admin.rule_restrict_by_wocommerce_coupon_type($(event.currentTarget));
		}, rule_type: function ($this) {
			$('.fgf-rule-data-tabs').find('.notices_tab').show();
			$('.fgf_rule_type').closest('div').hide();
			$('.fgf-rule-general-fields-wrapper').hide();
			$('.fgf-rule-notice-fields-wrapper').hide();
			$('.fgf-rule-cart-quantity-wrapper').show();
			$('.fgf-rule-coupon-filter-fields-wrapper').show();

			switch ($($this).val()) {
				case '1':
					$('.fgf_manual_rule_type').closest('div').show();
					$('.fgf-rule-manual-gifts-fields-wrapper').show();
					$('.fgf-rule-manual-gifts-quantity-fields-wrapper').hide();
					FGF_Admin.gift_type('.fgf_gift_type');
					break;

				case '2':
					$('.fgf_gift_type').closest('div').show();
					$('.fgf_automatic_rule_type').closest('div').show();
					$('.fgf-rule-manual-gifts-quantity-fields-wrapper').show();
					$('.fgf-rule-manual-gifts-fields-wrapper').show();
					FGF_Admin.gift_type('.fgf_gift_type');
					break;

				case '3':
					$('.fgf_bogo_rule_type').closest('div').show();
					$('.fgf_automatic_bogo_rule_type').closest('div').show();
					FGF_Admin.buy_product_type('.fgf_buy_product_type');
					FGF_Admin.bogo_gift_type('.fgf_bogo_gift_type');
					FGF_Admin.bogo_gift_repeat('.fgf_bogo_gift_repeat');
					$('.fgf-rule-bogo-gifts-fields-wrapper').show();
					$('.fgf-bogo-rule-notice-fields-wrapper').show();
					break;

				case '4':
					$('.fgf-rule-data-tabs').find('.notices_tab').hide();
					$('.fgf_coupon_rule_type').closest('div').show();
					$('.fgf_automatic_coupon_rule_type').closest('div').show();
					$('.fgf-rule-coupon-gifts-quantity-fields-wrapper').show();
					$('.fgf-rule-coupon-gifts-fields-wrapper').show();
					$('.fgf-rule-coupon-filter-fields-wrapper').hide();
					FGF_Admin.coupon_gift_type('.fgf-coupon-gift-type');
					break;

				case '5':
					$('.fgf_bogo_rule_type').closest('div').show();
					$('.fgf_manual_bogo_rule_type').closest('div').show();
					$('.fgf-rule-bogo-gifts-fields-wrapper').show();
					$('.fgf-rule-bogo-get-product-fields-wrapper').show();
					$('.fgf_get_product_type').closest('div').show();
					$('.fgf-bogo-rule-notice-fields-wrapper').show();
					FGF_Admin.buy_product_type('.fgf_buy_product_type');
					FGF_Admin.get_product_type('.fgf_get_product_type');
					FGF_Admin.bogo_gift_repeat('.fgf_bogo_gift_repeat');
					break;

				case '6':
					$('.fgf-rule-data-tabs').find('.notices_tab').hide();
					$('.fgf_coupon_rule_type').closest('div').show();
					$('.fgf_manual_coupon_rule_type').closest('div').show();
					$('.fgf-rule-coupon-gifts-fields-wrapper').show();
					$('.fgf-rule-coupon-gifts-quantity-fields-wrapper').hide();
					$('.fgf-rule-coupon-filter-fields-wrapper').hide();
					FGF_Admin.coupon_gift_type('.fgf-coupon-gift-type');
					break;

				case '7':
					$('.fgf-subtotal-rule-type').closest('div').show();
					$('.fgf-subtotal-automatic-rule-type').closest('div').hide();
					$('.fgf-subtotal-products-qty-type').closest('div').show();
					$('.fgf-rule-subtotal-gifts-fields-wrapper').show();
					FGF_Admin.subtotal_gift_type('.fgf-subtotal-gift-type');
					FGF_Admin.subtotal_repeat_gift('.fgf-subtotal-repeat-gift');
					break;

				case '8':
					$('.fgf-subtotal-rule-type').closest('div').show();
					$('.fgf-subtotal-products-qty-type').closest('div').hide();
					$('.fgf-rule-subtotal-gifts-fields-wrapper').show();
					FGF_Admin.subtotal_gift_type('.fgf-subtotal-gift-type');
					FGF_Admin.subtotal_repeat_gift('.fgf-subtotal-repeat-gift');
					break;

				case '9':
				case '10':
					$('.fgf-rule-bulk-pricing-gifts-fields-wrapper').show();
					FGF_Admin.bulk_pricing_total_type('.fgf-bulk-pricing-total-type');
					FGF_Admin.initialize_bulk_gift_type();
					FGF_Admin.initialize_bulk_reward_type();
					FGF_Admin.initialize_bulk_rule_collapse();
					$('.fgf-bulk-rule-notice-fields-wrapper').show();

					// The gift/variation selection is asked only for the automatic rule.
					if ('10' === $($this).val()) {
						$('.fgf_automatic_bulk_pricing_rule_type').closest('div').show();
					}
					break;

				case '11':
				case '12':
					$('.fgf-rule-bulk-quantity-gifts-fields-wrapper').show();
					FGF_Admin.initialize_bulk_gift_type();
					FGF_Admin.initialize_bulk_reward_type();
					FGF_Admin.initialize_bulk_rule_collapse();
					$('.fgf-rule-cart-quantity-wrapper').hide();
					$('.fgf-bulk-rule-notice-fields-wrapper').show();

					// The gift/variation selection is asked only for the automatic rule.
					if ('12' === $($this).val()) {
						$('.fgf_automatic_bulk_quantity_rule_type').closest('div').show();
					}
					break;

				case '13':
				case '14':
					$('.fgf-rule-cheapest-gifts-fields-wrapper').show();
					break;

				case '15':
					$('.fgf-rule-free-shipping-fields-wrapper').show();
					break;
			}

			// The gift price section is carried by every rule type that awards a gift
			// product, so it is shown with its rule type and only its own discount
			// fields have to be settled here.
			FGF_Admin.initialize_gift_reward_type();
			FGF_Admin.disable_hidden_gift_price_fields();

			FGF_Admin.automatic_gift_price_consider_visibility();
		}, toggle_bulk_reward_type: function (event) {
			event.preventDefault( );
			FGF_Admin.bulk_reward_type($(event.currentTarget));
		}, initialize_bulk_reward_type: function () {
			$('.fgf-rule-bulk-reward-type-field').each(function () {
				FGF_Admin.bulk_reward_type(this);
			});
		}, bulk_reward_type: function ($this) {
			// The discount is asked only when the bulk rule sets its own discounted reward.
			var row = $($this).closest('.fgf-bulk-rule-wrapper');

			if ('2' === $($this).val()) {
				row.find('.fgf-rule-bulk-discount-field').show();
			} else {
				row.find('.fgf-rule-bulk-discount-field').hide();
			}
		}, initialize_bulk_rule_collapse: function () {
			$('.fgf-bulk-rules-wrapper').each(function () {
				var $wrapper = $(this);

				$wrapper.find('.fgf-bulk-rules-actions').each(function () {
					var $actions = $(this);

					if (!$actions.find('.fgf-bulk-rules-toggle-all').length) {
						$actions.find('.fgf-add-bulk-rule').after(
							$('<button/>', { type: 'button', 'class': 'button fgf-bulk-rules-toggle-all' }));
					}
				});

				// A list of saved rules opens collapsed so that it can be read at a
				// glance; a rule just added on the page opens ready to be filled in.
				var collapse_saved = !$wrapper.data('fgf_collapse_initialised') &&
						$wrapper.find('.fgf-bulk-rule-wrapper').length > 1;

				$wrapper.find('.fgf-bulk-rule-wrapper').each(function () {
					var $row = $(this),
							is_new = !$row.find('> .fgf-bulk-rule-header').length;

					FGF_Admin.build_bulk_rule_header($row);

					if (collapse_saved) {
						FGF_Admin.set_bulk_rule_collapsed($row, true);
					} else if (is_new) {
						FGF_Admin.set_bulk_rule_collapsed($row, false);
					}
				});

				$wrapper.data('fgf_collapse_initialised', true);

				FGF_Admin.refresh_bulk_rules_toggle_all($wrapper);
			});
		}, toggle_bulk_rule_collapse: function (event) {
			// The remove button and anything else interactive in the header keeps
			// its own behaviour.
			if ($(event.target).closest('.fgf-rule-bulk-remove-field').length) {
				return;
			}

			event.preventDefault();
			FGF_Admin.set_bulk_rule_collapsed($(event.currentTarget).closest('.fgf-bulk-rule-wrapper'),
				!$(event.currentTarget).closest('.fgf-bulk-rule-wrapper').hasClass('fgf-bulk-rule-collapsed'));
		}, refresh_bulk_rule_summary: function (event) {
			var $row = $(event.currentTarget).closest('.fgf-bulk-rule-wrapper');

			if ($row.length) {
				FGF_Admin.update_bulk_rule_summary($row);
			}
		}, update_bulk_rule_summary: function ($row) {
			var i18n = FGF_Admin.bulk_rule_i18n,
					$summary = $row.find('> .fgf-bulk-rule-header .fgf-bulk-rule-summary'),
					$min = $row.find('.fgf-rule-bulk-min-qunaity-field, .fgf-rule-bulk-pricing-min-field'),
					// Only the range field decides the format; the discount value is a price field in every row.
					price = $min.hasClass('wc_input_price'),
					min = $.trim($min.val() || ''),
					max = $.trim($row.find('.fgf-rule-bulk-max-qunaity-field, .fgf-rule-bulk-pricing-max-field').val() || ''),
					qty = parseInt($row.find('.fgf-rule-bulk-gift-quantity-field, .fgf-rule-bulk-gift-pricing-field').val(), 10) || 0,
					money = function (v) { return price ? i18n('currency') + v : v; };

			// Range.
			var range;
			if (min && max) {
				range = i18n('range').replace('%1$s', money(min)).replace('%2$s', money(max));
			} else if (max) {
				range = i18n('up_to').replace('%s', money(max));
			} else if (min) {
				range = i18n('from').replace('%s', money(min));
			} else {
				range = i18n('any');
			}

			// What is awarded.
			var $gift = $row.find('.fgf-bulk-gift-type-' + $row.find('.fgf-rule-bulk-gift-selection-type-field').val()),
					names = $gift.find('option:selected').map(function () { return $.trim($(this).text()); }).get(),
					gift = names.length ?
						(names.length > 1 ? names[0] + ' ' + i18n('and_more').replace('%s', names.length - 1) : names[0]) :
						i18n('no_gift');

			// Reward.
			var reward = i18n('free'),
					reward_class = '';

			if ('2' === $row.find('.fgf-rule-bulk-reward-type-field').val()) {
				var value = $.trim($row.find('.fgf-rule-bulk-discount-value-field').val() || ''),
						percent = '1' === $row.find('.fgf-rule-bulk-discount-type-field').val();

				reward_class = value ? ' is-discount' : ' is-unset';
				reward = value ? i18n('discount_off').replace('%s', percent ? value + '%' : i18n('currency') + value) : i18n('no_discount');
			}

			// The pieces are separate so that the range and the reward stay legible
			// and only the gift names are shortened when the line runs short.
			var sep = function () { return $('<span/>', { 'class': 'fgf-bulk-rule-summary-sep', text: '\u00b7' }); };

			$summary.empty()
					.append($('<span/>', { 'class': 'fgf-bulk-rule-summary-range', text: range }))
					.append(sep());

			if (qty) {
				$summary
						.append($('<span/>', { 'class': 'fgf-bulk-rule-summary-count',
							text: (1 === qty ? i18n('gift_count') : i18n('gift_count_plural')).replace('%s', qty) }))
						.append(sep());
			}

			$summary
					.append($('<span/>', { 'class': 'fgf-bulk-rule-summary-gift', text: gift, title: gift }))
					.append($('<span/>', { 'class': 'fgf-bulk-rule-summary-reward' + reward_class, text: reward }));
		}, toggle_automatic_gift_price_consider: function () {
			FGF_Admin.automatic_gift_price_consider_visibility();
		}, automatic_gift_price_consider_visibility: function () {
			// The price is read only when a consideration awards the cheapest or the
			// most expensive one, so the field is asked for only then. The rule type
			// and the gift type decide whether the group is on screen at all, so the
			// field is hidden here and never shown against their decision.
			var by_price = function (value) {
				return '3' === value || '4' === value;
			};

			$('.fgf-automatic-gift-price-consider-field').each(function () {
				var $field = $(this),
						$panel = $field.closest('.fgf-rule-general-fields-wrapper'),
						$product = $panel.find('.fgf-gift-selection-field'),
						needed = by_price( $product.val() ) ||
								by_price( $panel.find('.fgf-variation-selection-field').val() ),
						// The rule type and the gift type decide whether the group is on
						// screen, so the field follows the consideration it belongs to.
						// Visibility is read from the element rather than from an inline
						// style, so hiding the group any other way is honoured too.
						$sibling = $product.closest('.fgf-field-wrapper'),
						on_screen = $sibling.length ? $sibling.is(':visible') : true;

				$field.closest('.fgf-field-wrapper').toggle( needed && on_screen );
			});
		}, build_bulk_rule_header: function ($row) {
			// The header is built here rather than in the markup so that the saved
			// rules and the rules added on the page share one implementation.
			if ($row.find('> .fgf-bulk-rule-header').length) {
				FGF_Admin.update_bulk_rule_summary($row);
				return;
			}

			var $body = $('<div/>', { 'class': 'fgf-bulk-rule-body' }),
					$header = $('<div/>', { 'class': 'fgf-bulk-rule-header' }),
					$remove = $row.find('> .fgf-rule-bulk-remove-field');

			$header.append($('<button/>', {
				type: 'button',
				'class': 'fgf-bulk-rule-toggle',
				'aria-expanded': 'true',
				title: FGF_Admin.bulk_rule_i18n('collapse')
			}));
			$header.append($('<span/>', { 'class': 'fgf-bulk-rule-summary' }));

			$row.children().not($remove).appendTo($body);
			$row.append($header).append($remove).append($body);

			FGF_Admin.update_bulk_rule_summary($row);
		}, set_bulk_rule_collapsed: function ($row, collapse) {
			$row.toggleClass('fgf-bulk-rule-collapsed', collapse);
			$row.find('.fgf-bulk-rule-toggle')
					.attr('aria-expanded', collapse ? 'false' : 'true')
					.attr('title', collapse ? FGF_Admin.bulk_rule_i18n('expand') : FGF_Admin.bulk_rule_i18n('collapse'));

			if (!collapse) {
				// select2 measures itself while hidden, so it is redrawn once shown.
				$row.find('.fgf_select2').each(function () {
					if ($(this).data('select2')) {
						$(this).trigger('change.select2');
					}
				});
			}

			FGF_Admin.refresh_bulk_rules_toggle_all($row.closest('.fgf-bulk-rules-wrapper'));
		}, toggle_all_bulk_rules: function (event) {
			event.preventDefault();

			var $button = $(event.currentTarget),
					collapse = 'collapse' === $button.data('action'),
					$rows = $button.closest('.fgf-bulk-rules-wrapper').find('.fgf-bulk-rule-wrapper');

			$rows.each(function () {
				FGF_Admin.set_bulk_rule_collapsed($(this), collapse);
			});

			FGF_Admin.refresh_bulk_rules_toggle_all($button.closest('.fgf-bulk-rules-wrapper'));
		}, refresh_bulk_rules_toggle_all: function ($wrapper) {
			var $button = $wrapper.find('.fgf-bulk-rules-toggle-all'),
					total = $wrapper.find('.fgf-bulk-rule-wrapper').length,
					collapsed = $wrapper.find('.fgf-bulk-rule-wrapper.fgf-bulk-rule-collapsed').length,
					collapse = collapsed < total;

			$button.toggle(total > 1)
					.data('action', collapse ? 'collapse' : 'expand')
					.text(collapse ? FGF_Admin.bulk_rule_i18n('collapse_all') : FGF_Admin.bulk_rule_i18n('expand_all'));

			// With no rules yet there is only one thing to do, so the rules are
			// added from the top and the lower controls stay out of the way.
			$wrapper.find('.fgf-bulk-rules-actions').last().toggle(total > 0);
		}, bulk_rule_i18n: function (key) {
			var i18n = ('undefined' !== typeof fgf_rule_params && fgf_rule_params.i18n_bulk_rule) ? fgf_rule_params.i18n_bulk_rule : {};

			return (undefined === i18n[key]) ? '' : i18n[key];
		}, initialize_gift_reward_type: function () {
			$('.fgf-gift-reward-type-field').each(function () {
				FGF_Admin.gift_reward_type(this);
			});

		}, disable_hidden_gift_price_fields: function () {
			// Every rule type carries its own copy of the gift price fields and they
			// all share one name, so the copies of the rule types that are not on
			// screen are disabled and left out of the posted rule.
			$('.fgf-gift-price-field').prop('disabled', true);
			$('.fgf-rule-general-fields-wrapper:visible').find('.fgf-gift-price-field').prop('disabled', false);

		}, gift_reward_type: function ($this) {
			// The discount belongs to the reward beside it, so only the fields of this
			// copy are settled and the copies of the other rule types are left alone.
			var $section = $($this).closest('.fgf-rule-gift-price-fields-wrapper');

			$section.find('.fgf-rule-gift-discount-field').closest('div').toggle('2' === $($this).val());

		}, gift_type: function ($this) {
			$('.fgf-gift-selection-type-field').closest('div').hide();
			$('.fgf-gift-selection-type-' + $($this).val()).closest('div').show();
			FGF_Admin.automatic_gift_selection('.fgf-automatic-gift-selection-field', '2', $($this).val());
		}, automatic_gift_selection: function (field, automatic_rule_type, gift_type) {
			// The automatic rules award a single product out of the selected
			// categories/brands, so the gift selection is not asked for the manual
			// rules nor for the individually selected gift products.
			var wrapper = $(field).closest('div');

			if (automatic_rule_type === $('.fgf_rule_types').val() && ('2' === gift_type || 'brand' === gift_type)) {
				wrapper.show();
			} else {
				wrapper.hide();
			}

			// The price consideration is shown along with the rest of the group, so
			// it is asked again only while one of the considerations compares by it.
			FGF_Admin.automatic_gift_price_consider_visibility();
		}, buy_product_type: function ($this) {
			$('.fgf-buy-product-selection-type-field').closest('div').hide();
			$('.fgf-buy-product-selection-type-field-' + $($this).val()).closest('div').show();
			FGF_Admin.buy_category_type();
		}, get_product_type: function ($this) {
			$('.fgf-get-product-selection-type-field').closest('div').hide();
			$('.fgf-get-product-selection-type-field-' + $($this).val()).closest('div').show();
			FGF_Admin.automatic_gift_selection('.fgf-bogo-automatic-gift-selection-field', '3', $($this).val());
		}, bogo_gift_repeat: function ($this) {
			if ($($this).is(":checked")) {
				$('.fgf_bogo_gift_repeat_field').closest('div').show();
				FGF_Admin.bogo_gift_repeat_mode('.fgf_bogo_gift_repeat_mode');
			} else {
				$('.fgf_bogo_gift_repeat_field').closest('div').hide();
			}
		}, bogo_gift_repeat_mode: function ($this) {
			if ($($this).val() === '1') {
				$('.fgf_bogo_gift_repeat_limit').closest('div').hide();
			} else {
				$('.fgf_bogo_gift_repeat_limit').closest('div').show();
			}
		}, bogo_gift_type: function ($this) {
			if ($($this).val() === '1') {
				$('.fgf-rule-bogo-get-product-fields-wrapper').hide();
			} else {
				$('.fgf_get_product_type').closest('div').show();
				$('.fgf-rule-bogo-get-product-fields-wrapper').show();
				FGF_Admin.get_product_type('.fgf_get_product_type');
			}

			FGF_Admin.buy_category_type();
		}, buy_category_type: function (  ) {
			if (('5' === $('.fgf_rule_types').val() || '2' === $('.fgf_bogo_gift_type').val()) && '2' === $('.fgf_buy_product_type').val()) {
				$('.fgf_buy_category_type').closest('div').show();
			} else {
				$('.fgf_buy_category_type').closest('div').hide();
			}
		}, subtotal_gift_type: function ($this) {
			$('.fgf-subtotal-gift-selection-type-field').closest('div').hide();
			$('.fgf-subtotal-gift-selection-type-' + $($this).val()).closest('div').show();
			FGF_Admin.automatic_gift_selection('.fgf-subtotal-automatic-gift-selection-field', '8', $($this).val());
		}, coupon_gift_type: function ($this) {
			$('.fgf-coupon-gift-selection-type-field').closest('div').hide();
			$('.fgf-coupon-gift-selection-type-' + $($this).val()).closest('div').show();
			FGF_Admin.automatic_gift_selection('.fgf-coupon-automatic-gift-selection-field', '4', $($this).val());
		}, subtotal_repeat_gift: function ($this) {

			if ($($this).is(":checked")) {
				$('.fgf-subtotal-repeat-gift-field').closest('div').show();
				FGF_Admin.subtotal_repeat_gift_mode('.fgf-subtotal-repeat-gift-mode');
			} else {
				$('.fgf-subtotal-repeat-gift-field').closest('div').hide();
			}
		}, subtotal_repeat_gift_mode: function ($this) {
			if ('1' === $($this).val()) {
				$('.fgf-subtotal-gift-repeat-limit').closest('div').hide();
			} else {
				$('.fgf-subtotal-gift-repeat-limit').closest('div').show();
			}
		}, initialize_bulk_gift_type: function () {
			$('.fgf-rule-bulk-gift-selection-type-field').each(function (eve) {
				FGF_Admin.bulk_gift_type(this);
			});
		}, bulk_gift_type: function ($this) {
			var row = $($this).closest('.fgf-bulk-rule-wrapper');

			row.find('.fgf-bulk-gift-type-field').closest('div').hide();
			row.find('.fgf-rule-bulk-gift-selection-type-field').closest('div').show();
			row.find('.fgf-bulk-gift-type-' + $($this).val()).closest('div').show();
		}, notice: function ($this) {
			if ($($this).val() === '2') {
				$('.fgf_rule_notice').closest('div').show();
			} else {
				$('.fgf_rule_notice').closest('div').hide();
			}
		},bogo_eligible_notice: function ($this) {
			if ($($this).val() === '2') {
				$('.fgf-rule-bogo-eligible-notice-field').closest('div').show();
			} else {
				$('.fgf-rule-bogo-eligible-notice-field').closest('div').hide();
			}
		},bulk_eligible_notice: function ($this) {
			if ($($this).val() === '2') {
				$('.fgf-rule-bulk-eligible-notice-field').closest('div').show();
			} else {
				$('.fgf-rule-bulk-eligible-notice-field').closest('div').hide();
			}
		}, user_filter_type: function ($this) {
			$('.fgf_user_filter').closest('div').hide();
			$('.fgf_user_filter-' + $($this).val()).closest('div').show();
		}, product_filter_type: function ($this) {
			$('.fgf_product_filter').closest('div').hide();
			switch ($($this).val()) {
				case '2':
					$('.fgf_include_products').closest('div').show();
					$('.fgf_applicable_products_type').closest('div').show();
					FGF_Admin.applicable_products_type('.fgf_applicable_products_type');
					break;

				case '3':
					$('.fgf_exclude_products').closest('div').show();
					break;

				case '5':
					$('.fgf_include_categories').closest('div').show();
					$('.fgf_applicable_categories_type').closest('div').show();
					FGF_Admin.applicable_categories_type('.fgf_applicable_categories_type');
					break;

				case '6':
					$('.fgf_exclude_categories').closest('div').show();
					break;
			}

			$(document).trigger('fgf_product_filter_type_options', [$($this).val()]);

		}, applicable_products_type: function ($this) {
			$('.fgf_include_product_count').closest('div').hide();
			if ($($this).val() === '4') {
				$('.fgf_include_product_count').closest('div').show();
			}
		}, applicable_categories_type: function ($this) {
			$('.fgf_include_category_product_count').closest('div').hide();
			if ($($this).val() === '4') {
				$('.fgf_include_category_product_count').closest('div').show();
			}
		}, filter_coupon_type: function ($this) {
			$('.fgf-rule-filter-coupon').closest('div').hide();
			switch ($($this).val()) {
				case '2':
					$('.fgf-rule-filter-include-coupons').closest('div').show();
					$('.fgf-rule-filter-coupon-applicable-type').closest('div').show();
					FGF_Admin.filter_coupon_applicable_type('.fgf-rule-filter-coupon-applicable-type');
					break;

				case '3':
					$('.fgf-rule-filter-exclude-coupons').closest('div').show();
					break;
			}
		}, filter_coupon_applicable_type: function ($this) {
			$('.fgf-rule-filter-coupon-count').closest('div').hide();
			if ($($this).val() === '4') {
				$('.fgf-rule-filter-coupon-count').closest('div').show();
			}
		}, rule_total_type: function ($this) {
			var val = $($this).val();

			$('.fgf-rule-cart-total-type-fields').closest('div').hide();
			$('.fgf-rule-cart-total-type-' + val).closest('div').show();

		}, rule_subtotal_type: function ($this) {
			var val = $($this).val();

			$('.fgf-rule-total-type-fields').closest('div').hide();
			$('.fgf-rule-total-type-' + val).closest('div').show();

		},bulk_pricing_total_type: function ($this) {
			var val = $($this).val();

			$('.fgf-bulk-pricing-total-type-field').closest('div').hide();
			$('.fgf-bulk-pricing-total-type-' + val).closest('div').show();

		}, rule_allowed_user_type: function ($this) {

			if ($($this).val() === '2') {
				$('.fgf-rule-user-count-field').closest('div').show();
				FGF_Admin.rule_user_purchased_order_count_type('.fgf_rule_user_purchased_order_count_type');
			} else {
				$('.fgf-rule-user-count-field').closest('div').hide();
			}
		}, rule_user_purchased_order_count_type: function ($this) {
			switch ($($this).val()) {
				case '3':
					$('.fgf_rule_user_purchased_order_min_count').closest('div').show();
					break;
				default:
					$('.fgf_rule_user_purchased_order_min_count').closest('div').hide();
					break;
			}
		}, rule_restrict_by_wocommerce_coupon_type: function ($this) {
			switch ($($this).val()) {
				case '2':
					$('.fgf-rule-restrict-by-wocommerce-coupon').closest('div').show();
					break;
				default:
					$('.fgf-rule-restrict-by-wocommerce-coupon').closest('div').hide();
					break;
			}
		}, sortable_default_fields: function () {
			var listtable = $('table.fgf_rules #the-list').closest('table');

			listtable.sortable({
				items: 'tr',
				handle: '.fgf_post_sort_handle',
				axis: 'y',
				containment: listtable,
				update: function (event, ui) {
					var sort_order = [];

					listtable.find('.fgf_rules_sortable').each(function (e) {
						sort_order.push($(this).val( ));
					});

					$.post(ajaxurl, {
						action: 'fgf_drag_rules_list',
						sort_order: sort_order,
						fgf_security: fgf_rule_params.fgf_rules_drag_nonce
					});
				}
			});
		}, reset_rule_usage_count: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget);

			FGF_Admin.block($this);

			var data = {
				action: 'fgf_reset_rule_usage_count',
				rule_id: $($this).data('rule-id'),
				fgf_security: fgf_rule_params.fgf_rules_nonce,
			};

			$.post(ajaxurl, data, function (res) {

				if (true === res.success) {
					alert(res.data.msg);
					location.reload(true);
				} else {
					alert(res.data.error);
				}

				FGF_Admin.unblock($this);
			}
			);
		}, tabbed_rule_panels: function ( ) {

			// trigger the clicked link.
			$('.fgf-rule-data-tab-link').on('click', function (event) {
				event.preventDefault();
				var $this = $(event.currentTarget),
						panel_content = $($this).closest('.fgf-rule-data-panel-content');

				$('.fgf-rule-data-tab', panel_content).removeClass('active');
				$($this).parent().addClass('active');

				$('div.fgf-rule-options-wrapper', panel_content).hide();
				$($($this).attr('href')).show();
			});

			// Trigger the first link.
			$('div.fgf-rule-data-panel-content').each(function () {
				$(this).find('.fgf-rule-data-tab').eq(0).find('a').click();
			});
		}, open_wp_frame: function (event) {
			event.preventDefault( );
			var img_container = $(this).closest('.fgf-upload-img-container'),
					wp_frame;

			// If the media frame already exists, reopen it.
			if (wp_frame) {
				wp_frame.open( );
				return;
			}

			// Create a new media frame.
			wp_frame = wp.media({
				frame: 'select',
				title: $(this).data('button-title') ? $(this).data('button-title') : fgf_admin_params.media_title,
				multiple: false,
				library: {
					type: 'image'
				},
				button: {
					text: $(this).data('button-text') ? $(this).data('button-text') : fgf_admin_params.media_button_text
				}
			});

			// When an image is selected, run a callback.
			wp_frame.on('select', function ( ) {
				// Get the attachement details from the media state.
				var attachment = wp_frame.state( ).get('selection').first( ).toJSON( );

				// Send the attachment url to input hidden field.
				img_container.find('.fgf-upload-img-url').val(attachment.id);

				// Send the attachement URL to custom preview.
				var img = $('<img />');
				img.attr('src', attachment.url);
				img_container.find('.fgf-uploaded-img-wrapper').empty( ).append(img);
				img_container.find('.fgf-delete-uploaded-img').show();
			});

			// Finally, open the modal.
			wp_frame.open( );
		},
		delete_uploaded_image: function (event) {
			event.preventDefault( );
			var img_container = $(this).closest('.fgf-upload-img-container');

			// Remove the attachment url.
			img_container.find('.fgf-upload-img-url').val('');
			img_container.find('.fgf-uploaded-img-wrapper').empty( );

			$(this).hide();
		}, add_bulk_rule: function (event) {
			event.preventDefault();
			var $this = $(event.currentTarget),
					rule_template = wp.template($($this).data('template_name')),
					wrapper = $($this).closest('.fgf-bulk-rules-wrapper'),
					last_rule_wrapper = wrapper.find('.fgf-bulk-rule-wrapper:last'),
					rule_id = last_rule_wrapper.data('rule_id') + 1 || 0;

			// The rules sit between the two sets of controls, so a rule added on
			// the page joins the list rather than landing after the lower one.
			var list = wrapper.find('.fgf-bulk-rules-list');

			(list.length ? list : wrapper).append(rule_template({rule_id: rule_id}));

			$(document.body).trigger('fgf-enhanced-init');
			FGF_Admin.initialize_bulk_gift_type();
			FGF_Admin.initialize_bulk_reward_type();
					FGF_Admin.initialize_bulk_rule_collapse();
		}, remove_bulk_rule: function (event) {
			event.preventDefault();

			var $wrapper = $(event.currentTarget).closest('.fgf-bulk-rules-wrapper');

			$($(event.currentTarget)).closest('.fgf-bulk-rule-wrapper').remove();

			FGF_Admin.refresh_bulk_rules_toggle_all($wrapper);
		}, block: function (id) {
			$(id).block({
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.7
				}
			});
		}, unblock: function (id) {
			$(id).unblock();
		}
	};
	FGF_Admin.init( );
});
