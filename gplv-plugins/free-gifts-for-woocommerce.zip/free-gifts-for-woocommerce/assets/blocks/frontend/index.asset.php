<?php return array( 'dependencies' => array( 'jquery', 'react', 'wc-blocks-checkout', 'wc-settings', 'wp-data', 'wp-element' ), 'version' => FGF_VERSION );
