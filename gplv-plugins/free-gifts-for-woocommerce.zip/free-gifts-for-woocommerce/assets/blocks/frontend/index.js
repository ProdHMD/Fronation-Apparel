/**
 * Cart / Checkout block.
 * 
 * @since 11.0.0
 */
(() => {
	'use strict';
	var reactElement = window.wp.element,
			wc_blocks_checkout = window.wc.blocksCheckout,
			wp_data = window.wp.data,
			wc_plugin_data = window.wc.wcSettings,
			notice_ids = [],
			// Eligible notice progress bars, keyed by the id of the placeholder anchor
			// their notice carries, and the observer that puts them back whenever the
			// notices are painted again.
			progress_bars = {},
			progress_bars_observer = null,
			progress_bars_frame = null;

	const {
		createNotice, removeNotice
	} = wp_data.dispatch('core/notices');
	const{
		gift_added_message
	} = wc_plugin_data.getSetting('fgf-wc-blocks_data');

	/**
	 * Free gifts cart block class.
	 * 
	 * @since 11.0.0
	 * @return {JSX.Element} A Wrapper used to display the free gifts related data in the cart page.
	 */
	const FreeGiftsCartBlock = {
		context: 'wc/cart',
		getElement: function (e) {
			if(!e.extensions){
				return null;
			}

			const extension = e.extensions['fgf-free-gifts'];
			if(!extension){
				return null;
			}

			const giftsHTML = extension?.cart_gifts_html;
			const cartNotices = extension?.cart_notices;
			const snackbarNotices = extension?.snackbar_notices;
			const eligiblePopupsHTML = extension?.eligible_popups_html;
			const progressBars = extension?.eligible_notice_progress_bars;

			// Always clean before adding
			reactElement.useEffect(() => {
				removeNotices(FreeGiftsCartBlock.context);
			}, [cartNotices, snackbarNotices]);

			// Add notices safely
			reactElement.useEffect(() => {
				if (cartNotices) {
					createNotices(cartNotices, FreeGiftsCartBlock.context);
				}

				if (snackbarNotices) {
					createSnackBarNotices(snackbarNotices);
				}
			}, [cartNotices, snackbarNotices]);

			// Put the progress bars back into the notices the block paints from the
			// same payload.
			reactElement.useEffect(() => {
				renderEligibleNoticeProgressBars(progressBars);
			}, [cartNotices, progressBars]);

			reactElement.useEffect(() => {
				renderEligiblePopups(eligiblePopupsHTML);
			}, [eligiblePopupsHTML]);

			// Run jQuery AFTER DOM update
			reactElement.useEffect(() => {
				if (giftsHTML || eligiblePopupsHTML){
					jQuery(document.body).trigger('fgf-enhanced-carousel');
					jQuery(document.body).trigger('fgf-enhanced-lightcase');
				}
			}, [giftsHTML , eligiblePopupsHTML]);

			if (!giftsHTML){
				return null;
			}

			return reactElement.createElement(reactElement.RawHTML, null, giftsHTML);
		}
	};

	/**
	 * Free gifts checkout block class.
	 * 
	 * @since 11.0.0
	 * @return {JSX.Element} A Wrapper used to display the free gifts related data in the checkout page.
	 */
	const FreeGiftsCheckoutBlock = {
		context: 'wc/checkout',
		getElement: function (e) {
			if(!e.extensions){
				return null;
			}

			const extension = e.extensions['fgf-free-gifts'];
			if(!extension){
				return null;
			}

			const giftsHTML = extension?.checkout_gifts_html;
			const checkoutNotices = extension?.checkout_notices;
			const snackbarNotices = extension?.snackbar_notices;
			const eligiblePopupsHTML = extension?.eligible_popups_html;
			const progressBars = extension?.eligible_notice_progress_bars;

			// Always clean before adding
			reactElement.useEffect(() => {
				removeNotices(FreeGiftsCheckoutBlock.context);
			}, [checkoutNotices, snackbarNotices]);

			// Add notices safely
			reactElement.useEffect(() => {
				if (checkoutNotices) {
					createNotices(checkoutNotices, FreeGiftsCheckoutBlock.context);
				}

				if (snackbarNotices) {
					createSnackBarNotices(snackbarNotices);
				}
			}, [checkoutNotices, snackbarNotices]);

			// Put the progress bars back into the notices the block paints from the
			// same payload.
			reactElement.useEffect(() => {
				renderEligibleNoticeProgressBars(progressBars);
			}, [checkoutNotices, progressBars]);

			reactElement.useEffect(() => {
				renderEligiblePopups(eligiblePopupsHTML);
			}, [eligiblePopupsHTML]);

			// Run jQuery AFTER DOM update
			reactElement.useEffect(() => {
				if (giftsHTML || eligiblePopupsHTML){
					jQuery(document.body).trigger('fgf-enhanced-carousel');
					jQuery(document.body).trigger('fgf-enhanced-lightcase');
				}
			}, [giftsHTML , eligiblePopupsHTML]);

			if (!giftsHTML){
				return null;
			}

			return reactElement.createElement(reactElement.RawHTML, null, giftsHTML);
		}
	};

	/**
	 * Force gifts popup checkout block class.
	 * 
	 * @since 12.4.0
	 * @return {JSX.Element} A Wrapper used to display the force gifts popup related data in the checkout page.
	 */
	const ForceGiftsPopupCheckoutBlock = {
		context: 'wc/checkout',
		getElement: function (e) {
			if(!e.extensions){
				return null;
			}

			const extension = e.extensions['fgf-free-gifts'];
			if(!extension){
				return null;
			}

			const giftsPopupHTML = extension?.force_gifts_popup_html;
			if (!giftsPopupHTML) {
				return null;
			}

			// Reinitialize third party library.
			reactElement.useEffect(() => {
				if(giftsPopupHTML){
					jQuery(document.body).trigger('fgf-enhanced-carousel');
			    	jQuery(document.body).trigger('fgf-enhanced-lightcase');
				}
			},[giftsPopupHTML]);
			
			return reactElement.createElement(reactElement.RawHTML, null, giftsPopupHTML);
		}
	};

	/**
	 * Progress bar cart block class.
	 * 
	 * @since 11.0.0
	 * @return {JSX.Element} A Wrapper used to display the progress bar related data in the cart page.
	 */
	const ProgressBarCartBlock = {
		context: 'wc/cart',
		getElement: function (e) {
			if(!e.extensions){
				return null;
			}

			if (!e.extensions['fgf-free-gifts']) {
				return null;
			}

			if (!e.extensions['fgf-free-gifts']['cart_progress_bar_html']) {
				return null;
			}

			return reactElement.createElement(reactElement.RawHTML, null, e.extensions['fgf-free-gifts']['cart_progress_bar_html']);
		}
	};

	/**
	 * Prgress bar checkout block class.
	 * 
	 * @since 11.0.0
	 * @return {JSX.Element} A Wrapper used to display the progress bar related data in the checkout page.
	 */
	const ProgressBarCheckoutBlock = {
		context: 'wc/checkout',
		getElement: function (e) {
			if(!e.extensions){
				return null;
			}

			if (!e.extensions['fgf-free-gifts']) {
				return null;
			}

			if (!e.extensions['fgf-free-gifts']['checkout_progress_bar_html']) {
				return null;
			}

			return reactElement.createElement(reactElement.RawHTML, null, e.extensions['fgf-free-gifts']['checkout_progress_bar_html']);
		}
	};

	/**
	 * Modify the free gifts cart item in the cart item table.
	 * 
	 * @since 11.0.0
	 */
	const CartItem = {
		/**
		 * Handles remove item link.
		 * 
		 * @since 11.0.0
		 * @param {boolean} defaultValue
		 * @param {object} extensions
		 * @param {array} args
		 * @returns {string}
		 */
		handleRemoveItemLink: function (defaultValue, extensions, args) {
			// Check current cart item is a free gift cart item.
			if (!extensions['fgf-free-gifts'] || undefined === extensions['fgf-free-gifts'].show_remove_link) {
				return defaultValue;
			}

			return extensions['fgf-free-gifts'].show_remove_link;
		},
		/**
		 * Modify the cart item price.
		 * 
		 * The value is a format the cart interpolates, and its <price/> stands for the
		 * price the cart holds - already the price the gift was awarded at. So the
		 * price is shown by handing the format back as it is, and the label is shown by
		 * putting it in front of the price, which the stylesheet then hides: a format
		 * that leaves <price/> out is refused and falls back to the price alone.
		 * 
		 * @since 11.0.0
		 * @param {string} defaultValue
		 * @param {object} extensions
		 * @param {object} args
		 * @param {boolean} validation
		 * @returns {string}
		 */
		handleItemPrice: function (defaultValue, extensions, args, validation) {
			// Check current cart item is a free gift cart item.
			if (!extensions['fgf-free-gifts'] || !extensions['fgf-free-gifts'].item_price) {
				return defaultValue;
			}

			// Discounted price already not having the price return it as same value.
			if (!extensions['fgf-free-gifts'].item_price.discounted_price) {
				return defaultValue;
			}

			// The price is the one the format already carries, so it is shown once.
			if ('price' === extensions['fgf-free-gifts'].item_price.type) {
				return defaultValue;
			}

			return extensions['fgf-free-gifts'].item_price.label + defaultValue;
		},
		/**
		 * Mark the cart item of a gift whose price is shown as a label.
		 * 
		 * The label is printed beside the price the format has to carry, so the row is
		 * marked for the stylesheet to hide that price behind it.
		 * 
		 * @since 13.8.0
		 * @param {string} defaultValue
		 * @param {object} extensions
		 * @param {object} args
		 * @returns {string}
		 */
		handleItemClass: function (defaultValue, extensions, args) {
			// Check current cart item is a free gift cart item shown with the label.
			if (!extensions['fgf-free-gifts'] || !extensions['fgf-free-gifts'].item_price) {
				return defaultValue;
			}

			if (!extensions['fgf-free-gifts'].item_price.discounted_price || 'price' === extensions['fgf-free-gifts'].item_price.type) {
				return defaultValue;
			}

			return (defaultValue ? defaultValue + ' ' : '') + 'fgf-gift-item-price-label';
		}
	};
	/**
	 * Render the eligible notice gifts popup modals outside the sanitized notice.
	 *
	 * The WooCommerce Blocks notice sanitizer strips the modal markup (form
	 * elements, hidden inputs, wrapper classes), so the modals are delivered via
	 * the Store API and rendered here into a single container appended to the body.
	 * The trigger link inside the notice opens them by its href target.
	 *
	 * @since 13.5.0
	 * @param {string} html
	 * @returns {undefined}
	 */
	function renderEligiblePopups(html) {
		// Remove any previously rendered modals before injecting fresh markup. This
		// covers both a prior injection and the server-rendered copies output on
		// wp_footer during the initial page load (WooCommerce preloads the Store API
		// cart data server-side, which registers the modals). Clearing them first
		// keeps a single copy and avoids duplicate element ids.
		jQuery('.fgf-eligible-gifts-modal-holder').remove();
		jQuery('#fgf-eligible-gifts-popups').remove();

		if (!html) {
			return;
		}

		jQuery('<div id="fgf-eligible-gifts-popups"></div>').appendTo(document.body).html(html);
	}

	/**
	 * Render the eligible notice progress bars inside their notice.
	 *
	 * The block notice list sanitizes the notice HTML down to a handful of tags as
	 * soon as the banner holds more than one notice, which strips the bar markup.
	 * The bars are delivered separately through the Store API and put back here,
	 * in place of the placeholder anchor the notice carries, which the sanitizer
	 * keeps.
	 *
	 * @since 13.8.0
	 * @param {object} bars Bar markup keyed by placeholder id.
	 * @returns {undefined}
	 */
	function renderEligibleNoticeProgressBars(bars) {
		// An empty payload arrives as an array, a filled one as an object.
		progress_bars = (bars && !Array.isArray(bars)) ? bars : {};

		fillEligibleNoticeProgressBars();
		observeEligibleNoticeProgressBars();
	}

	/**
	 * Replace the progress bar placeholders with the bars of the current payload.
	 *
	 * Filling a placeholder takes it out of the document, so this only ever acts on
	 * the notices the block has just painted.
	 *
	 * @since 13.8.0
	 * @returns {undefined}
	 */
	function fillEligibleNoticeProgressBars() {
		jQuery('a[name^="fgf-enpb-"]').each(function () {
			const bar = progress_bars[jQuery(this).attr('name')];
			if (!bar) {
				return;
			}

			jQuery(this).replaceWith(bar);
		});
	}

	/**
	 * Watch for the notices being painted so the bars are put back into them.
	 *
	 * The notice content is rendered as raw HTML, so every re-render restores the
	 * placeholder the payload carries and the bar has to be filled in again. The
	 * refill is deferred to the next frame so a burst of updates costs one pass.
	 *
	 * @since 13.8.0
	 * @returns {undefined}
	 */
	function observeEligibleNoticeProgressBars() {
		// Nothing to put back until a notice actually carries a bar.
		if (jQuery.isEmptyObject(progress_bars)) {
			if (progress_bars_observer) {
				progress_bars_observer.disconnect();
				progress_bars_observer = null;
			}

			return;
		}

		if (progress_bars_observer) {
			return;
		}

		progress_bars_observer = new MutationObserver(function () {
			if (progress_bars_frame) {
				return;
			}

			progress_bars_frame = window.requestAnimationFrame(function () {
				progress_bars_frame = null;
				fillEligibleNoticeProgressBars();
			});
		});

		progress_bars_observer.observe(document.body, {childList: true, subtree: true});
	}

	/**
	 * Create snackbar notices to the block.
	 *
	 * @since 11.0.0
	 * @param {array} notices
	 * @param {string} context
	 * @returns {undefined}
	 */
	function createSnackBarNotices(group_notices, context, status = 'success') {
		if (group_notices) {
			jQuery.each(group_notices, function (type, notices) {
				jQuery.each(notices, function (index, notice) {
					createNotice(type, notice, {
						id: 'fgf-gift-snackbar-notices' + index,
						context: 'wc/cart',
						type: 'snackbar'
					});
				});
			});
		}
	}

	/**
	 * Create notices to the block.
	 * 
	 * @since 11.0.0
	 * @param {array} notices
	 * @param {string} context
	 * @returns {undefined}
	 */
	function createNotices(notices, context, status = 'success') {
		// Add eligible notices.
		if (notices) {
			jQuery.each(notices, function (index, notice) {
				let id = 'fgf-gifts-notice-' + index;
				createNotice(status, '<div class="fgf-gifts-notices-wrapper">' + notice + '</div>', {
					id: id,
					context: context,
					isDismissible: true
				});
				notice_ids.push(id);
			});
		}
	}

	/**
	 * Remove previous notices from the block.
	 * 
	 * @since 11.0.0
	 * @param {string} context
	 * @returns {undefined}
	 */
	function removeNotices(context) {
		jQuery.each(notice_ids, function (index, id) {
			removeNotice(id, context);
		});
	}

	/**
	 * Create a cart notice.
	 * 
	 * @since 12.4.0
	 */
	jQuery(document).on('fgf_create_cart_notice', function () {
		createNotice('success', gift_added_message, {
			id: 'fgf-gift-added',
			context: 'wc/cart',
			type: 'snackbar'
		});
	});

	/**
	 * Update cart after gifts are added.
	 * 
	 * @since 11.0.0
	 */
	jQuery(document).on('fgf_update_cart_block', function () {
		// Refresh the cart.
		wc_blocks_checkout.extensionCartUpdate({
			namespace: 'fgf-free-gifts',
			data: {
				action: 'refresh_cart'
			}
		}).then(() => {
			// Reinitialize third party library
			jQuery(document.body).trigger('fgf-enhanced-carousel');
			jQuery(document.body).trigger('fgf-enhanced-lightcase');
		}).finally(() => {
			createNotice('success', gift_added_message, {
				id: 'fgf-gift-added',
				context: 'wc/cart',
				type: 'snackbar'
			});
		});
	});

	// Register inner block of progress bar in the cart block.
	wc_blocks_checkout.registerCheckoutBlock({
		metadata: JSON.parse("{\"name\":\"woocommerce/fgf-wc-cart-progress-bar-block\",\"icon\":\"cart\",\"keywords\":[\"progress\",\"bar\",\"gifts\"],\"version\":\"1.0.0\",\"title\":\"Gifts Progress Bar\",\"description\":\"Shows the gifts progress bar layout in the cart block.\",\"category\":\"woocommerce\",\"supports\":{\"align\":false,\"html\":false,\"multiple\":false,\"reusable\":false},\"attributes\":{\"className\":{\"type\":\"string\",\"default\":\"\"},\"lock\":{\"type\":\"object\",\"default\":{\"remove\":true,\"move\":false}}},\"parent\":[\"woocommerce/cart-items-block\"],\"textdomain\":\"free-gifts-for-woocommerce\",\"apiVersion\":3}"),
		component: ProgressBarCartBlock.getElement
	});
	// Register inner block of progress bar in the checkout block.
	wc_blocks_checkout.registerCheckoutBlock({
		metadata: JSON.parse("{\"name\":\"woocommerce/fgf-wc-checkout-progress-bar-block\",\"icon\":\"cart\",\"keywords\":[\"progress\",\"bar\",\"gifts\"],\"version\":\"1.0.0\",\"title\":\"Gifts Progress Bar\",\"description\":\"Shows the gifts progress bar layout in the checkout block.\",\"category\":\"woocommerce\",\"supports\":{\"align\":false,\"html\":false,\"multiple\":false,\"reusable\":false},\"attributes\":{\"className\":{\"type\":\"string\",\"default\":\"\"},\"lock\":{\"type\":\"object\",\"default\":{\"remove\":true,\"move\":false}}},\"parent\":[\"woocommerce/checkout-fields-block\"],\"textdomain\":\"free-gifts-for-woocommerce\",\"apiVersion\":3}"),
		component: ProgressBarCheckoutBlock.getElement
	});

	// Register inner block of gifts in the cart block.
	wc_blocks_checkout.registerCheckoutBlock({
		metadata: JSON.parse("{\"name\":\"woocommerce/fgf-wc-cart-free-gifts-block\",\"icon\":\"cart\",\"keywords\":[\"free\",\"gifts\"],\"version\":\"1.0.0\",\"title\":\"Free Gifts\",\"description\":\"Shows the free gifts layout in the cart block.\",\"category\":\"woocommerce\",\"supports\":{\"align\":false,\"html\":false,\"multiple\":false,\"reusable\":false},\"attributes\":{\"className\":{\"type\":\"string\",\"default\":\"\"},\"lock\":{\"type\":\"object\",\"default\":{\"remove\":true,\"move\":false}}},\"parent\":[\"woocommerce/cart-items-block\"],\"textdomain\":\"free-gifts-for-woocommerce\",\"apiVersion\":3}"),
		component: FreeGiftsCartBlock.getElement
	});
	// Register inner block of gifts in the checkout block.
	wc_blocks_checkout.registerCheckoutBlock({
		metadata: JSON.parse("{\"name\":\"woocommerce/fgf-wc-checkout-free-gifts-block\",\"icon\":\"cart\",\"keywords\":[\"free\",\"gifts\"],\"version\":\"1.0.0\",\"title\":\"Free Gifts\",\"description\":\"Shows the free gifts layout in the checkout block.\",\"category\":\"woocommerce\",\"supports\":{\"align\":false,\"html\":false,\"multiple\":false,\"reusable\":false},\"attributes\":{\"className\":{\"type\":\"string\",\"default\":\"\"},\"lock\":{\"type\":\"object\",\"default\":{\"remove\":true,\"move\":false}}},\"parent\":[\"woocommerce/checkout-fields-block\"],\"textdomain\":\"free-gifts-for-woocommerce\",\"apiVersion\":3}"),
		component: FreeGiftsCheckoutBlock.getElement
	});

	// Register inner block of force gifts popup in the checkout block.
	wc_blocks_checkout.registerCheckoutBlock({
		metadata: JSON.parse("{\"name\":\"woocommerce/fgf-wc-checkout-force-gifts-popup-block\",\"icon\":\"cart\",\"keywords\":[\"free\",\"gifts\"],\"version\":\"1.0.0\",\"title\":\"Free Gifts\",\"description\":\"Shows the force gifts popup layout in the checkout block.\",\"category\":\"woocommerce\",\"supports\":{\"align\":false,\"html\":false,\"multiple\":false,\"reusable\":false},\"attributes\":{\"className\":{\"type\":\"string\",\"default\":\"\"},\"lock\":{\"type\":\"object\",\"default\":{\"remove\":true,\"move\":false}}},\"parent\":[\"woocommerce/checkout-fields-block\"],\"textdomain\":\"free-gifts-for-woocommerce\",\"apiVersion\":3}"),
		component: ForceGiftsPopupCheckoutBlock.getElement
	});

	// Alter the free gifts cart item in the cart item table.
	wc_blocks_checkout.registerCheckoutFilters('fgf-free-gifts', {
		showRemoveItemLink: CartItem.handleRemoveItemLink,
		cartItemPrice: CartItem.handleItemPrice,
		cartItemClass: CartItem.handleItemClass
	});

	/**
	 * Prevent the placing the order in the checkout when the remaining gifts are available.
	 * 
	 * @since 12.4.0
	 * */ 
	var valid_types=['2','3'];
	const blockCheckout=document.querySelector('.wc-block-checkout');
	if(blockCheckout && valid_types.includes(fgf_frontend_params.force_checkout_type) && fgf_frontend_params.is_block_checkout){
		/*
		 * Whether the place order click is still to be held back for the forced gifts
		 * popup. One flag for the checkout rather than one per observed change, so only
		 * the popup this opened itself places the order when it is closed. Every gift
		 * popup announces its close with the same event, so closing another one - the
		 * "View Gifts" popup of an eligible notice - leaves the checkout alone.
		 */
		let stopped_place_order = true;

		/**
		 * Hold the place order click back and show the forced gifts popup instead.
		 *
		 * @since 12.4.0
		 * @param {object} e
		 * @returns {boolean}
		 */
		function preventPlaceOrder(e) {
			// Let the order through once the shopper has been shown the popup, and when
			// there is no popup to show them.
			if (!stopped_place_order || !jQuery('.fgf-popup-force-checkout-gifts').length) {
				return true;
			}

			e.stopImmediatePropagation();
			e.preventDefault();

			stopped_place_order = false;
			jQuery('.fgf-popup-force-checkout-gifts').click();

			return false;
		}

		/**
		 * Place the order once the shopper has skipped the forced gifts popup.
		 *
		 * Bound once, outside the observer below: the observer runs on every change the
		 * checkout makes to its DOM, and binding here would stack a handler per change.
		 *
		 * @since 12.4.0
		 */
		jQuery(document.body).on('fgf_lightcase_closed', function () {
			// Only the popup opened in place of the place order click places the order.
			if (stopped_place_order) {
				return;
			}

			jQuery('button.wc-block-components-checkout-place-order-button').click();
		});

		const checkoutObserver = new MutationObserver(() => {
			const placeOrderButton = document.querySelector('button.wc-block-components-checkout-place-order-button');

			// The button is bound once, and again whenever the checkout re-renders it as
			// a fresh element, which carries none of the flag.
			if (!placeOrderButton || placeOrderButton.dataset.popupAttached) {
				return;
			}

			if (!jQuery('.fgf-popup-force-checkout-gifts').length) {
				return;
			}

			placeOrderButton.dataset.popupAttached = 'true';
			placeOrderButton.addEventListener('click', preventPlaceOrder);
		});

		// Observe DOM for changes, as checkout blocks load via JS
		checkoutObserver.observe(blockCheckout, { childList: true, subtree: true });
	}
})();
