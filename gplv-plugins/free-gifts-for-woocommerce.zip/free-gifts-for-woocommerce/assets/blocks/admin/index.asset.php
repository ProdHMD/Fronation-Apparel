<?php
return array( 'dependencies' => array( 'react', 'wc-settings', 'wp-element', 'wp-i18n' ), 'version' => FGF_VERSION );
