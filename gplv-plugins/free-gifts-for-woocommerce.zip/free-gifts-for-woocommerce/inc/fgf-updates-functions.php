<?php
/**
 * Updates functions.
 *
 * @since 13.8.0
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly.

if ( ! function_exists( 'fgf_get_eligible_notices_display_pages_update_data' ) ) {

	/**
	 * Get the pages each of the eligible notices display locations stood for.
	 *
	 * The "Free Gift(s) Eligibility Notice will be Displayed on" setting held a single
	 * choice of the cart and the checkout before 13.8.0, where it became the pages
	 * the notices are displayed on.
	 *
	 * @since 13.8.0
	 * @return array
	 */
	function fgf_get_eligible_notices_display_pages_update_data() {
		return array(
			// Cart & Checkout.
			'1' => array( wc_get_page_id( 'cart' ), wc_get_page_id( 'checkout' ) ),
			// Cart.
			'2' => array( wc_get_page_id( 'cart' ) ),
			// Checkout.
			'3' => array( wc_get_page_id( 'checkout' ) ),
			// Neither the cart nor the checkout.
			'4' => array(),
		);
	}

}

if ( ! function_exists( 'fgf_convert_legacy_eligible_notices_display_pages' ) ) {

	/**
	 * Convert a legacy eligible notices display location into the ids of the pages
	 * it stood for.
	 *
	 * The update that stores the pages runs in the admin, so the conversion is also
	 * applied by fgf_get_eligible_notices_display_pages() while it has not run yet,
	 * leaving the frontend of a site that has not been visited in the admin since the
	 * plugin was updated on the pages it was configured with.
	 *
	 * @since 13.8.0
	 * @param mixed $value Stored setting value.
	 * @return array The page ids as strings, the form the setting holds.
	 */
	function fgf_convert_legacy_eligible_notices_display_pages( $value ) {
		if ( is_array( $value ) ) {
			return $value;
		}

		// The pages are resolved through WooCommerce, so the value is left untouched
		// until it is loaded.
		if ( ! function_exists( 'wc_get_page_id' ) ) {
			return $value;
		}

		$legacy_page_ids = fgf_get_eligible_notices_display_pages_update_data();
		$legacy_value = is_scalar( $value ) ? (string) $value : '';
		$page_ids = isset( $legacy_page_ids[ $legacy_value ] ) ? $legacy_page_ids[ $legacy_value ] : fgf_get_default_eligible_notices_display_pages();

		// The ids are answered as strings, the form the multiselect setting holds.
		return array_map( 'strval', array_values( array_unique( array_filter( array_map( 'absint', $page_ids ) ) ) ) );
	}

}
