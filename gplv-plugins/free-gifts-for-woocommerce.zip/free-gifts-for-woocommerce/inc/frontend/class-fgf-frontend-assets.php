<?php

/**
 * Frontend Assets
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}
if (!class_exists('FGF_Fronend_Assets')) {

	/**
	 * Class.
	 */
	class FGF_Fronend_Assets {

		/**
		 * Suffix.
		 * 
		 * @var string
		 */
		private static $suffix;

		/**
		 * Scripts.
		 *
		 * @since 5.2.0
		 * @var array
		 */
		private static $scripts = array();

		/**
		 * Styles.
		 *
		 * @since 5.2.0
		 * @var array
		 */
		private static $styles = array();

		/**
		 * Localized scripts.
		 *
		 * @since 10.2.0
		 * @var array
		 */
		private static $wp_localized_scripts = array();

		/**
		 * In Footer.
		 * 
		 * @var bool
		 */
		private static $in_footer = false;

		/**
		 * Class Initialization.
		 */
		public static function init() {

			self::$suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

			// Enqueue script in footer.
			if ('2' == get_option('fgf_settings_frontend_enqueue_scripts_type')) {
				self::$in_footer = true;
			}

			add_action('wp_enqueue_scripts', array( __CLASS__, 'external_js_files' ));
			add_action('wp_enqueue_scripts', array( __CLASS__, 'external_css_files' ));
			add_action('wp_print_scripts', array( __CLASS__, 'print_scripts' ), 5);
			add_action('wp_print_footer_scripts', array( __CLASS__, 'print_scripts' ), 5);
		}

		/**
		 * Enqueue external JS files
		 */
		public static function external_js_files() {
			// Frontend
			$permalink = get_permalink();
			$add_to_cart_link = esc_url(add_query_arg(array( 'fgf_gift_product' => '%s', 'fgf_rule_id' => '%s', 'fgf_buy_product_id' => '%s', 'fgf_coupon_id' => '%s' ), $permalink));

			wp_enqueue_script('fgf-frontend', FGF_PLUGIN_URL . '/assets/js/frontend.js', array( 'jquery', 'jquery-blockui' ), FGF_VERSION, self::$in_footer);
			wp_localize_script(
					'fgf-frontend', 'fgf_frontend_params', array(
				'gift_products_pagination_nonce' => wp_create_nonce('fgf-gift-products-pagination'),
				'gift_product_nonce' => wp_create_nonce('fgf-gift-product'),
				'ajaxurl' => FGF_ADMIN_AJAX_URL,
				'current_page_url' => $permalink,
				'add_to_cart_link' => $add_to_cart_link,
				'ajax_add_to_cart' => get_option('fgf_settings_enable_ajax_add_to_cart', 'no'),
				'quantity_field_enabled' => get_option('fgf_settings_gift_product_quantity_field_enabled', '2'),
				'dropdown_add_to_cart_behaviour' => get_option('fgf_settings_dropdown_add_to_cart_behaviour'),
				'dropdown_display_type' => get_option('fgf_settings_gift_dropdown_display_type'),
				'add_to_cart_alert_message' => get_option('fgf_settings_gift_product_dropdown_valid_message', 'Please select a Gift'),
					)
			);

			//Register the carousel assets.
			self::register_carousel_assets();
			//Register the lightcase assets.
			self::register_lightcase_assets();
		}

		public static function external_css_files() {
			wp_register_style('fgf-inline-style', false, array(), FGF_VERSION); // phpcs:ignore
			wp_enqueue_style('fgf-inline-style');

			//Add inline style.
			self::add_inline_style();

			// Frontend.
			wp_enqueue_style('fgf-frontend-css', FGF_PLUGIN_URL . '/assets/css/frontend.css', array(), FGF_VERSION);
		}

		/**
		 * Add Inline style
		 */
		public static function add_inline_style() {
			$contents = get_option('fgf_settings_custom_css', '');

			if (!$contents) {
				return;
			}

			//Add custom css as inline style.
			wp_add_inline_style('fgf-inline-style', $contents);
		}

		/**
		 * Register the carousel assets.
		 * 
		 * @since 10.2.0
		 */
		private static function register_carousel_assets() {
			// Owl carousel JS.
			wp_register_script('owl-carousel', FGF_PLUGIN_URL . '/assets/js/owl.carousel' . self::$suffix . '.js', array( 'jquery' ), FGF_VERSION, self::$in_footer);
			wp_register_script('fgf-owl-carousel', FGF_PLUGIN_URL . '/assets/js/owl-carousel-enhanced.js', array( 'jquery', 'owl-carousel' ), FGF_VERSION, self::$in_footer);

			// Owl carousel CSS.
			wp_register_style('owl-carousel', FGF_PLUGIN_URL . '/assets/css/owl.carousel' . self::$suffix . '.css', array(), FGF_VERSION);
			wp_register_style('fgf-owl-carousel', FGF_PLUGIN_URL . '/assets/css/owl-carousel-enhanced.css', array(), FGF_VERSION);
		}

		/**
		 * Enqueue the carousel assets.
		 * 
		 * @since 10.2.0
		 */
		public static function enqueue_carousel_assets() {
			// Scripts.
			self::$scripts[] = 'fgf-owl-carousel';

			// Localize.
			self::set_localize_scripts('fgf-owl-carousel', 'fgf_carousel_params', fgf_get_carousel_options());

			// Styles.
			self::$styles[] = 'owl-carousel';
			self::$styles[] = 'fgf-owl-carousel';
		}

		/**
		 * Register the lightcase assets.
		 * 
		 * @since 10.2.0
		 */
		private static function register_lightcase_assets() {
			// Lightcase.
			wp_register_script('lightcase', FGF_PLUGIN_URL . '/assets/js/lightcase' . self::$suffix . '.js', array( 'jquery' ), FGF_VERSION, self::$in_footer);
			// Enhanced lightcase.
			wp_enqueue_script('fgf-lightcase', FGF_PLUGIN_URL . '/assets/js/fgf-lightcase-enhanced.js', array( 'jquery', 'jquery-blockui', 'lightcase' ), FGF_VERSION, self::$in_footer);
			// Lightcase CSS.
			wp_enqueue_style('lightcase', FGF_PLUGIN_URL . '/assets/css/lightcase' . self::$suffix . '.css', array(), FGF_VERSION);
		}

		/**
		 * Set the localize the scripts.
		 *
		 * @since 10.2.0
		 * @param string $handle
		 * @param string $object_name
		 * @param array  $l10n
		 */
		public static function set_localize_scripts( $handle, $object_name, $l10n ) {
			self::$wp_localized_scripts[$handle] = array(
				'object_name' => $object_name,
				'i10n' => $l10n,
			);
		}

		/**
		 * Print scripts.
		 * 
		 * @since 10.2.0
		 */
		public static function print_scripts() {

			// Enqueue scripts.
			foreach (self::$scripts as $handle) {
				if (!wp_script_is($handle, 'registered')) {
					continue;
				}

				wp_enqueue_script($handle);
			}

			// Print Localized scripts.
			foreach (self::$wp_localized_scripts as $handle => $data) {
				if (!wp_script_is($handle)) {
					continue;
				}

				wp_localize_script($handle, $data['object_name'], $data['i10n']);
			}

			// Enqueue styles.
			foreach (self::$styles as $handle) {
				if (!wp_style_is($handle, 'registered')) {
					continue;
				}

				wp_enqueue_style($handle);
			}
		}
	}

	FGF_Fronend_Assets::init();
}
