<?php

/**
 * Compatibility - Advanced Product Fields for WooCommerce.
 *
 * @since 13.5.0
 * @tested up to 1.7
 * @pluginauthor Studio Wombat
 * @authorurl https://studiowombat.com
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'FGF_Advanced_Product_Fields_Compatibility' ) ) {

	/**
	 * Class.
	 *
	 * @since 13.5.0
	 */
	class FGF_Advanced_Product_Fields_Compatibility extends FGF_Compatibility {

		/**
		 * Class Constructor.
		 *
		 * @since 13.5.0
		 */
		public function __construct() {
			$this->id = 'advanced_product_fields';

			parent::__construct();
		}

		/**
		 * Is plugin enabled?.
		 *
		 * @since 13.5.0
		 * @return bool
		 */
		public function is_plugin_enabled() {
			return function_exists( 'wapf' ) || function_exists('wapf_pro');
		}

		/**
		 * Frontend Action.
		 *
		 * @since 13.5.0
		 */
		public function frontend_action() {
			// Strip personalization data leaked onto auto-added gift products.
			// Priority 100 runs after WAPF's priority-10 callback, but still before
			// WooCommerce derives the cart-item id from the cart item data.
			add_filter( 'woocommerce_add_cart_item_data', array( $this, 'remove_personalization_from_gift_product' ), 100, 1 );
		}

		/**
		 * Prevent WAPF personalization fields from being inherited by auto-added gift products.
		 *
		 * When a personalized product is added in the same request, its form fields stay in
		 * $_REQUEST. WooCommerce re-runs woocommerce_add_cart_item_data when the gift is added
		 * programmatically, so WAPF attaches its `wapf` data to the gift. A free gift has no
		 * personalization of its own, so strip those keys back out.
		 *
		 * @since 13.5.0
		 * @param array $cart_item_data
		 * @return array
		 */
		public function remove_personalization_from_gift_product( $cart_item_data ) {
			if ( ! isset( $cart_item_data['fgf_gift_product'] ) ) {
				return $cart_item_data;
			}

			/**
			 * This hook is used to alter the gift product excluded cart item data keys.
			 * 
			 * @since 13.5.0
			 */
			$excluded_keys = (array) apply_filters( 'fgf_gift_product_excluded_cart_item_data_keys', array( 'wapf', 'wapf_field_groups' ) );

			foreach ( $excluded_keys as $key ) {
				unset( $cart_item_data[ $key ] );
			}

			return $cart_item_data;
		}
	}

}
