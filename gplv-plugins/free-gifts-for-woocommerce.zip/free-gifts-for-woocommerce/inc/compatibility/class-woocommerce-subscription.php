<?php

/**
 * Compatibility - WooCommerce Subscription Plugin.
 *
 * Compatibility last checked version of 5.0.1
 *
 * @link https://woocommerce.com/products/woocommerce-subscriptions/
 *
 * @since 9.8.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'FGF_WooCommerce_Subscription_Compatibility' ) ) {

	/**
	 * Class.
	 *
	 * @since 9.8.0
	 */
	class FGF_WooCommerce_Subscription_Compatibility extends FGF_Compatibility {

		/**
		 * Class Constructor.
		 *
		 * @since 9.8.0
		 */
		public function __construct() {
			$this->id = 'woocommerce_subscription';

			parent::__construct();
		}

		/**
		 * Is plugin enabled?.
		 *
		 * @since 9.8.0
		 * @return boolean
		 * */
		public function is_plugin_enabled() {
			return class_exists( 'WC_Subscriptions' );
		}

		/**
		 * Admin action.
		 *
		 * @since 12.9.0
		 */
		public function admin_action() {
			// Enable the compatibility tab.
			add_filter( 'fgf_enable_compatibility_tab', '__return_true' );
			// Add sections to the compatibility tab.
			add_filter( 'fgf_get_sections_compatibility', array( __CLASS__, 'add_sections' ), 10, 1 );
			// Add settings for the compatibility tab.
			add_filter( 'fgf_get_settings_compatibility_woocommerce_subscription', array( __CLASS__, 'add_settings' ), 10, 1 );
		}

		/**
		 * Front end action.
		 *
		 * @since 9.8.0
		 */
		public function frontend_action() {
			// Set the extra properties for the subscription product as free gifts.
			add_action( 'woocommerce_get_cart_item_from_session', array( __CLASS__, 'set_subscription_product_property' ), 10, 3 );
			// Alert the recurring subscription product price as free gift product which is used to set the next renewal price.
			add_filter( 'fgf_gift_product_price', array( __CLASS__, 'alter_recurring_subscription_product_price' ), 10, 3 );
			// Alert the subscription product price as free gift product.
			add_filter( 'woocommerce_subscriptions_cart_get_price', array( __CLASS__, 'alter_subscription_product_price' ), 10, 3 );
			// Prevent awarding free gifts on subscription renewal orders.
			add_filter( 'fgf_restrict_rules', array( __CLASS__, 'maybe_prevent_gifts_on_subscription_renewal' ), 10, 1 );
			// Remove the renewal order free gift product line item data.
			add_filter( 'woocommerce_order_again_cart_item_data', array( __CLASS__, 'remove_renewal_order_free_gift_line_item_data' ), 10, 3 );
		}

		/**
		 * Add settings for the compatibility tab.
		 *
		 * @since 12.9.0
		 * @param array $settings
		 * @return array
		 */
		public static function add_settings( $settings ) {
			$settings[] = array(
				'title' => __( 'WooCommerce Subscription Settings', 'free-gifts-for-woocommerce' ),
				'type' => 'title',
				'id' => 'fgf_compatibility_woocommerce_subscription_settings',
			);
			$settings[] = array(
				'title' => __( 'Restrict Gift Products on Renewal', 'free-gifts-for-woocommerce' ),
				'id' => 'fgf_prevent_award_gifts_subscription_renewal',
				'type' => 'checkbox',
				'default' => 'no',
				'desc' => __( 'When enabled, gift product(s) will not be awarded during subscription renewals.', 'free-gifts-for-woocommerce' ),
			);
			$settings[] = array(
				'title' => __( 'Apply Original Price during Subscription Renewal', 'free-gifts-for-woocommerce' ),
				'id' => 'fgf_subscription_renewal_use_original_price',
				'type' => 'checkbox',
				'default' => 'yes',
				'desc' => __( 'When enabled, the actual subscription product price will be applied at renewal.', 'free-gifts-for-woocommerce' ),
			);
			$settings[] = array(
				'type' => 'sectionend',
				'id' => 'fgf_compatibility_woocommerce_subscription_settings_end',
			);

			return $settings;
		}

		/**
		 * Add sections to the compatibility tab.
		 *
		 * @since 12.9.0
		 * @param array $sections
		 * @return array
		 */
		public static function add_sections( $sections ) {
			$sections['woocommerce_subscription'] = __( 'WooCommerce Subscription', 'free-gifts-for-woocommerce' );

			return $sections;
		}

		/**
		 * Set the extra properties for the subscription product as free gifts.
		 *
		 * @since 9.8.0
		 * @param array  $session_data
		 * @param array  $values
		 * @param string $key
		 * @return array
		 */
		public static function set_subscription_product_property( $session_data, $values, $key ) {
			// Don't consider if the product is not a free gift product.
			if ( ! isset( $session_data['fgf_gift_product'] ) || ! is_object( $session_data['data'] ) ) {
				return $session_data;
			}

			// Don't consider if the product is not a subscription product.
			if ( ! WC_Subscriptions_Product::is_subscription( $session_data['data'] ) ) {
				return $session_data;
			}

			$session_data['data']->add_meta_data( 'fgf_subscription_product', true );

			return $session_data;
		}

		/**
		 * Alert the recurring subscription product price as free gift product which is used to set the next renewal price.
		 *
		 * @since 9.8.0
		 * @param float  $price
		 * @param string $cart_item_key
		 * @param array  $cart_item
		 * @return float
		 */
		public static function alter_recurring_subscription_product_price( $price, $cart_item_key, $cart_item ) {
			// Don't consider if the option is enabled to use original price for renewal.
			if ( 'no' === get_option( 'fgf_subscription_renewal_use_original_price', 'yes' ) ) {
				return $price;
			}

			// Don't consider if the calculation type is not recurring calculation.
			if ( 'recurring_total' != WC_Subscriptions_Cart::get_calculation_type() ) {
				return $price;
			}

			// Don't consider if the product is not a subscription product.
			if ( ! WC_Subscriptions_Product::is_subscription( $cart_item['data'] ) ) {
				return $price;
			}

			// Set the original product price for renewal total.
			return wc_get_product( $cart_item['data']->get_id() )->get_price();
		}

		/**
		 * Alert the subscription product price as free gift product which will omit the price in the cart total.
		 *
		 * @since 9.8.0
		 * @param float  $price
		 * @param string $product
		 * @return float
		 */
		public static function alter_subscription_product_price( $price, $product ) {
			// Don't consider if the calculation type is recurring calculation.
			if ( 'recurring_total' === WC_Subscriptions_Cart::get_calculation_type() ) {
				return $price;
			}

			// Don't consider if the product is not a subscription product.
			if ( ! WC_Subscriptions_Product::is_subscription( $product ) ) {
				return $price;
			}

			// Don't consider the product is not a free gift product.
			if ( ! $product->get_meta( 'fgf_subscription_product' ) ) {
				return $price;
			}

			// Set the price as 0.
			return 0;
		}

		/**
		 * Maybe prevent awarding free gifts on subscription renewal orders.
		 *
		 * @since 12.9.0
		 * @param boolean $restrict_rules
		 * @return boolean
		 */
		public static function maybe_prevent_gifts_on_subscription_renewal( $restrict_rules ) {
			// Don't consider if the option is disabled to prevent awarding gifts on subscription renewal.
			if ( 'no' === get_option( 'fgf_prevent_award_gifts_subscription_renewal', 'no' ) ) {
				return $restrict_rules;
			}

			// Return empty restrict rules if the cart contains renewal order.
			return wcs_cart_contains_renewal() ? true : $restrict_rules;
		}

		/**
		 * Remove the free gift product line item data when renewal the products.
		 *
		 * @since 9.8.0
		 * @param array  $cart_item_data
		 * @param array  $line_item
		 * @param object $subscription
		 * @return array
		 */
		public static function remove_renewal_order_free_gift_line_item_data( $cart_item_data, $line_item, $subscription ) {
			// Don't consider if the line item is not a free gift product.
			if ( ! isset( $cart_item_data['subscription_renewal']['custom_line_item_meta']['_fgf_gift_product'] ) ) {
				return $cart_item_data;
			}

			// Remove the parent order line item for the free gifts products.
			$cart_item_data['subscription_renewal']['custom_line_item_meta'] = array();

			return $cart_item_data;
		}
	}

}
