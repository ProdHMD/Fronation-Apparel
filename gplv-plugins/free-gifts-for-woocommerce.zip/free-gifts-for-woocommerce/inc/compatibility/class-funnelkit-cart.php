<?php

/**
 * Compatibility - FunnelKit Cart for WooCommerce
 * 
 * @since 10.7.0
 * @tested up to 1.2.0
 * @pluginauthor Funnel Kit
 * @authorurl https://funnelkit.com
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

if (!class_exists('FGF_Funnelkit_Cart_Compatibility')) {

	/**
	 * Class.
	 * 
	 * @since 10.7.0
	 */
	class FGF_Funnelkit_Cart_Compatibility extends FGF_Compatibility {

		/**
		 * Class Constructor.
		 * 
		 * @since 10.7.0
		 */
		public function __construct() {
			$this->id = 'funnelkit_cart';

			parent::__construct();
		}

		/**
		 * Is plugin enabled?.
		 * 
		 * @since 10.7.0
		 * @return bool
		 * */
		public function is_plugin_enabled() {
			return class_exists('FKCart\Plugin');
		}

		/**
		 * Frontend Action.
		 * 
		 * @since 10.7.0
		 */
		public function frontend_action() {
			// Add or remove the free gifts based on cart contents.
			add_action('woocommerce_ajax_added_to_cart', array( $this, 'handle_free_gifts' ), 999);
		}

		/**
		 * Handle free gifts after products added in the cart.
		 * 
		 * @since 10.7.0
		 */
		public function handle_free_gifts() {
			// Reset the rules cache data.
			self::reset_rules_cached_data();

			FGF_Gift_Products_Handler::automatic_gift_product(false);
			FGF_Gift_Products_Handler::bogo_gift_product(false);
			FGF_Gift_Products_Handler::coupon_gift_product(false);
		}

		/**
		 * Reset the rules cached data.
		 * 
		 * Which will solve the automatic gifts not adding or removing issues in the side cart.
		 * 
		 * @since 10.7.0
		 */
		public function reset_rules_cached_data() {
			// Reset to add automatic gifts in the cart.
			FGF_Gift_Products_Handler::$automatic_gifts_added = false;
			// Reset to remove automatic gifts in the cart.
			FGF_Gift_Products_Handler::$automatic_gifts_removed = false;
			// Reset cached rule data.
			FGF_Rule_Handler::reset();
		}
	}

}
