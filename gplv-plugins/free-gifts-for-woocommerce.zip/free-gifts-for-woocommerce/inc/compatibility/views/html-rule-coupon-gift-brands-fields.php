<?php
/**
 * HTML- Coupon Gift brands search fields.
 *
 * @since 13.7.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class='fgf-field-wrapper'>
	<span class='fgf-field-title'>
		<label><?php esc_html_e( 'Select Brands', 'free-gifts-for-woocommerce' ); ?><span class='required'>*</span></label>
		<?php fgf_wc_help_tip( __( "The products from the selected brands will be added to the user's cart once the coupon applied", 'free-gifts-for-woocommerce' ) ); ?>
	</span>
	<span class='fgf-field'>
		<select class='fgf-coupon-gift-brands fgf_select2 fgf_rule_type fgf_coupon_rule_type fgf-coupon-gift-selection-type-brand fgf-coupon-gift-selection-type-field' name='fgf_rule[fgf_coupon_gift_brands][]' multiple='multiple'>
			<?php
			foreach ( $brands as $brand_id => $brand_name ) :
				$selected = ( in_array( $brand_id, $selected_brand_ids ) ) ? ' selected="selected"' : '';
				?>
				<option value="<?php echo esc_attr( $brand_id ); ?>"<?php echo esc_attr( $selected ); ?>><?php echo esc_html( $brand_name ); ?></option>
			<?php endforeach; ?>
		</select>
	</span>
</div>
<?php
