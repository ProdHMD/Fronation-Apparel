<?php

/**
 * Polylang Compatibility.
 *
 * @since 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'FGF_Polylang_Compatibility' ) ) {

	/**
	 * Class.
	 *
	 * @since 1.0.0
	 */
	class FGF_Polylang_Compatibility extends FGF_Compatibility {

		/**
		 * Class Constructor.
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			$this->id = 'polylang';

			parent::__construct();
		}

		/**
		 * Is plugin enabled?.
		 *
		 * @since 1.0.0
		 * @return bool
		 */
		public function is_plugin_enabled() {
			return class_exists( 'Polylang' );
		}

		/**
		 * Action
		 *
		 * @since 1.0.0
		 */
		public function actions() {
			// Check if the product id is valid.
			add_filter( 'fgf_is_valid_product', array( $this, 'valid_product' ), 10, 2 );
		}

		/**
		 * Admin-only hooks for language-filtered product search.
		 *
		 * @since 13.5.0
		 */
		public function admin_action() {
			// Set the language attribute for the select2 field.
			add_filter( 'fgf_select2_field_lang_attribute', array( $this, 'set_select2_field_lang_attribute' ), 10, 2 );
			// Remove the WPML JSON search founded products hook.
			add_filter( 'fgf_json_search_found_products', array( $this, 'remove_wpml_json_search_found_products_hook' ), 10, 1 );
		}

		/**
		 * Check whether a product ID is valid for the current Polylang language.
		 *
		 * @since 1.0.0
		 * @param bool $bool       Existing validity flag.
		 * @param int  $product_id WooCommerce product post ID.
		 * @return bool
		 */
		public function valid_product( $bool, $product_id ) {
			global $polylang;

			// Pass through when Polylang has not enabled product-type translation.
			if ( ! $this->is_product_translation_enabled() ) {
				return $bool;
			}

			// Accept the product when its language matches the current language.
			if ( pll_get_post_language( $product_id ) === pll_current_language() ) {
				return $bool;
			}

			return false;
		}

		/**
		 * Set the language attribute for the select2 field.
		 *
		 * @since 13.5.0
		 * @param string $lang The default language.
		 * @param array  $args The arguments passed to the select2 field.
		 * @return string
		 */     
		public function set_select2_field_lang_attribute( $lang, $args ) {
			$current = pll_current_language();

			// pll_current_language() is false when the admin views "All Languages".
			return $current ? $current : 'all';
		}

		/**
		 * Remove the WPML JSON search founded products hook.
		 *
		 * @since 13.5.0
		 * @param array $products The products found in JSON search.
		 * @return array
		 */
		public function remove_wpml_json_search_found_products_hook( $products ) {
			if ( !function_exists( 'PLLWC' ) || !is_object( PLLWC()->admin_products ) ) {
				return $products;
			}

			$lang = isset( $_GET['lang'] ) ? wc_clean( wp_unslash( $_GET['lang'] ) ) : '';
			//Return original IDs if the current language is not 'all'.
			if ( 'all' !== $lang ) {
				return $products;
			}

			remove_filter( 'woocommerce_json_search_found_products', array( PLLWC()->admin_products, 'search_found_products' ) );

			return $products;
		}

		// -------------------------------------------------------------------------
		// Private helpers
		// -------------------------------------------------------------------------

		/**
		 * Whether Polylang has translation enabled for the product post type.
		 *
		 * @since 13.5.0
		 * @return bool
		 */
		private function is_product_translation_enabled() {
			global $polylang;

			return is_object( $polylang )
				&& isset( $polylang->links_model->model->post )
				&& $polylang->links_model->model->post->is_translated_object_type( 'product' );
		}
	}

}
