<?php
/**
 * Updates.
 *
 * @since 13.8.0
 * */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'FGF_Updates' ) ) {

	/**
	 * Class.
	 *
	 * @since 13.8.0
	 */
	class FGF_Updates {

		/**
		 * DB updates and callbacks that need to be run per version.
		 *
		 * @since 13.8.0
		 * @var array
		 */
		private static $updates = array(
			'update_1380' => '13.8.0',
		);

		/**
		 * Maybe run updates if the versions do not match.
		 *
		 * @since 13.8.0
		 * @return void
		 */
		public static function maybe_run() {
			// Return if it will not run admin.
			if ( ! is_admin() || defined( 'DOING_AJAX' ) || defined( 'DOING_CRON' ) ) {
				return;
			}

			if ( fgf_check_is_array( self::$updates ) && version_compare( get_option( 'fgf_updated_version' ), self::get_latest_update_version(), '<' ) ) {
				self::maybe_update_version();
			}
		}

		/**
		 * Update FGF DB version to current if unavailable.
		 *
		 * @since 13.8.0
		 * @param int|string $version Version number.
		 * @return void
		 */
		public static function update_version( $version = null ) {
			update_option( 'fgf_updated_version', empty( $version ) ? FGF_VERSION : $version );
		}

		/**
		 * Get the version of the last data update.
		 *
		 * @since 13.8.0
		 * @return string
		 */
		private static function get_latest_update_version() {
			return max( array_values( self::$updates ) );
		}

		/**
		 * Check whether we need to show or run db updates during install.
		 *
		 * @since 13.8.0
		 * @return void
		 */
		private static function maybe_update_version() {
			if ( ! fgf_check_is_array( self::$updates ) ) {
				self::update_version();
				return;
			}

			// The version of the last update is stored, and not the version of the
			// plugin, so the updates are not run again by a build whose version is
			// behind the update that has already been run.
			$needs_db_update = version_compare( get_option( 'fgf_updated_version' ), self::get_latest_update_version(), '<' );
			if ( ! $needs_db_update ) {
				self::update_version( self::get_latest_update_version() );
				return;
			}

			// Update FGF database.
			foreach ( self::$updates as $update => $updating_version ) {
				if ( is_callable( array( 'FGF_Updates', $update ) ) ) {
					call_user_func_array( array( 'FGF_Updates', $update ), array( $updating_version ) );
				}
			}

			self::update_version( self::get_latest_update_version() );
		}

		/**
		 * Update Version 13.8.0 eligible notices display setting.
		 *
		 * The "Free Gift(s) Eligibility Notice will be Displayed on" setting held a
		 * single choice of the cart and the checkout, and now holds the pages the
		 * notices are displayed on, so the choice is stored as the pages it stood for.
		 *
		 * @since 13.8.0
		 * @param string $updating_version Version.
		 * @return void
		 */
		public static function update_1380( $updating_version ) {
			// Return if the eligible notices display setting is updated.
			if ( 'yes' === get_option( 'fgf_eligible_notices_display_pages_upgraded', 'no' ) ) {
				return;
			}

			$stored_value = get_option( 'fgf_settings_display_cart_notices_type' );
			// Nothing to update when the setting is unset or already holds the pages.
			if ( false !== $stored_value && ! is_array( $stored_value ) ) {
				update_option( 'fgf_settings_display_cart_notices_type', fgf_convert_legacy_eligible_notices_display_pages( $stored_value ) );
			}

			update_option( 'fgf_eligible_notices_display_pages_upgraded', 'yes' );
		}
	}
}
