<?php

/**
 * Default functions.
 *
 * @since 9.2.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'fgf_get_rule_statuses_options' ) ) {

	/**
	 * Get the rule statuses options.
	 *
	 * @since 9.6.0
	 * @staticvar $rule_statuses
	 * @return array
	 */
	function fgf_get_rule_statuses_options() {
		static $rule_statuses;
		if ( $rule_statuses ) {
			return $rule_statuses;
		}

		$rule_statuses = array(
			'fgf_active' => __( 'Active', 'free-gifts-for-woocommerce' ),
			'fgf_inactive' => __( 'In-active', 'free-gifts-for-woocommerce' ),
		);

		/**
		 * This hook is used to alter the rule statuses options.
		 *
		 * @param array $rule_statuses rule statuses
		 * @since 9.6.0
		 */
		$rule_statuses = apply_filters( 'fgf_rule_statuses_options', $rule_statuses );

		return $rule_statuses;
	}

}

if ( ! function_exists( 'fgf_get_rule_criteria_total_type_options' ) ) {

	/**
	 * Get the rule criteria total type options.
	 *
	 * @since 8.6
	 * @return array
	 */
	function fgf_get_rule_criteria_total_type_options() {
		static $options;
		if ( isset( $options ) ) {
			return $options;
		}

		$options = array(
			'1' => __( 'Cart Subtotal', 'free-gifts-for-woocommerce' ),
			'2' => __( 'Order Total', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Category Total', 'free-gifts-for-woocommerce' ),
		);

		/**
		 * This hook is used to alter the rule criteria total type options
		 *
		 * @since 8.6
		 */
		$options = apply_filters( 'fgf_rule_criteria_total_type_options', $options );

		return $options;
	}

}

if ( ! function_exists( 'fgf_get_rule_cheapest_gift_price_type_options' ) ) {

	/**
	 * Get the rule cheapest gift price type options.
	 *
	 * @since 11.4.0
	 * @return array
	 */
	function fgf_get_rule_cheapest_gift_price_type_options() {
		static $options;
		if ( isset( $options ) ) {
			return $options;
		}

		$options = array(
			'1' => __( 'Price of the Product in the Cart', 'free-gifts-for-woocommerce' ),
			'2' => __( 'Sub-total Price of the Product in the Cart', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Regular Price of the Product', 'free-gifts-for-woocommerce' ),
			'4' => __( 'Sale Price of the Product', 'free-gifts-for-woocommerce' ),
		);

		/**
		 * This hook is used to alter the rule cheapest gift price type options
		 *
		 * @since 11.4.0
		 */
		$options = apply_filters( 'fgf_rule_cheapest_gift_price_type_options', $options );

		return $options;
	}

}

if ( ! function_exists( 'fgf_get_rule_gift_reward_type_options' ) ) {

	/**
	 * Get the rule gift award type options.
	 *
	 * The rule and every one of its bulk rules are awarded with the same reward
	 * types, so the bulk rules are offered and validated against this list too.
	 *
	 * @since 13.8.0
	 * @return array
	 */
	function fgf_get_rule_gift_reward_type_options() {
		static $options;
		if ( isset( $options ) ) {
			return $options;
		}

		$options = array(
			'1' => __( 'Completely Free', 'free-gifts-for-woocommerce' ),
			'2' => __( 'At a Discounted Price', 'free-gifts-for-woocommerce' ),
		);

		/**
		 * This hook is used to alter the rule gift award type options
		 *
		 * @since 13.8.0
		 */
		$options = apply_filters( 'fgf_rule_gift_reward_type_options', $options );

		return $options;
	}

}

if ( ! function_exists( 'fgf_get_rule_gift_discount_type_options' ) ) {

	/**
	 * Get the rule gift discount type options.
	 *
	 * @since 13.8.0
	 * @return array
	 */
	function fgf_get_rule_gift_discount_type_options() {
		static $options;
		if ( isset( $options ) ) {
			return $options;
		}

		$options = array(
			'1' => __( 'Percentage', 'free-gifts-for-woocommerce' ),
			'2' => __( 'Fixed Amount', 'free-gifts-for-woocommerce' ),
		);

		/**
		 * This hook is used to alter the rule gift discount type options
		 *
		 * @since 13.8.0
		 */
		$options = apply_filters( 'fgf_rule_gift_discount_type_options', $options );

		return $options;
	}

}

if ( ! function_exists( 'fgf_rule_user_filter_options' ) ) {

	/**
	 * Get the rule user filter options
	 *
	 * @since 9.2
	 * @return array
	 */
	function fgf_rule_user_filter_options() {
		static $rule_user_filters;
		if ( isset( $rule_user_filters ) ) {
			return $rule_user_filters;
		}

		$rule_user_filters = array(
			'1' => __( 'All User(s)', 'free-gifts-for-woocommerce' ),
			'2' => __( 'Include User(s)', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Exclude User(s)', 'free-gifts-for-woocommerce' ),
			'4' => __( 'Include User Role(s)', 'free-gifts-for-woocommerce' ),
			'5' => __( 'Exclude User Role(s)', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule user filter options
		 *
		 * @since 9.2
		 */
		$rule_user_filters = apply_filters( 'fgf_rule_user_filter_options', $rule_user_filters );

		return $rule_user_filters;
	}

}

if ( ! function_exists( 'fgf_rule_filter_coupon_options' ) ) {

	/**
	 * Get the rule filter coupon options
	 *
	 * @since 13.0.0
	 * @return array
	 */
	function fgf_rule_filter_coupon_options() {
		static $rule_coupon_filters;
		if ( isset( $rule_coupon_filters ) ) {
			return $rule_coupon_filters;
		}

		$rule_coupon_filters = array(
			'1' => __( 'Select an Option', 'free-gifts-for-woocommerce' ),
			'2' => __( 'Include Coupon(s)', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Exclude Coupon(s)', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule filter coupon options
		 *
		 * @since 13.0.0
		 */
		$rule_coupon_filters = apply_filters( 'fgf_rule_filter_coupon_options', $rule_coupon_filters );

		return $rule_coupon_filters;
	}

}

if ( ! function_exists( 'fgf_rule_product_filter_options' ) ) {

	/**
	 * Get the rule product filter options
	 *
	 * @since 9.2
	 * @return array
	 */
	function fgf_rule_product_filter_options() {
		static $rule_product_filters;
		if ( isset( $rule_product_filters ) ) {
			return $rule_product_filters;
		}

		$rule_product_filters = array(
			'1' => __( 'All Product(s)', 'free-gifts-for-woocommerce' ),
			'2' => __( 'Include Product(s)', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Exclude Product(s)', 'free-gifts-for-woocommerce' ),
			'4' => __( 'All Categories', 'free-gifts-for-woocommerce' ),
			'5' => __( 'Include Categories', 'free-gifts-for-woocommerce' ),
			'6' => __( 'Exclude Categories', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule product filter options
		 *
		 * @since 9.2
		 */
		$rule_product_filters = apply_filters( 'fgf_rule_product_filter_options', $rule_product_filters );

		return $rule_product_filters;
	}

}

if ( ! function_exists( 'fgf_rule_virtual_product_restriction_options' ) ) {

	/**
	 * Get the rule virtual product restriction options
	 *
	 * @since 11.3.0
	 * @return array
	 */
	function fgf_rule_virtual_product_restriction_options() {
		static $rule_virtual_product_restriction_options;
		if ( isset( $rule_virtual_product_restriction_options ) ) {
			return $rule_virtual_product_restriction_options;
		}

		$rule_virtual_product_restriction_options = array(
			'1' => __( 'Select an option', 'free-gifts-for-woocommerce' ),
			'2' => __( 'Only Virtual Products', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule virtual product restriction options
		 *
		 * @since 11.3.0
		 */
		$rule_virtual_product_restriction_options = apply_filters( 'fgf_rule_virtual_product_restriction_options', $rule_virtual_product_restriction_options );

		return $rule_virtual_product_restriction_options;
	}

}

if ( ! function_exists( 'fgf_rule_product_applicable_filter_options' ) ) {

	/**
	 * Get the rule product applicable filter options
	 *
	 * @since 9.2
	 * @return array
	 */
	function fgf_rule_product_applicable_filter_options() {
		static $rule_product_applicable_filters;
		if ( isset( $rule_product_applicable_filters ) ) {
			return $rule_product_applicable_filters;
		}

		$rule_product_applicable_filters = array(
			'1' => __( 'Any one of the selected Product(s) must be in cart', 'free-gifts-for-woocommerce' ),
			'2' => __( 'All the selected Product(s) must be in cart', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Only the selected Product(s) must be in cart', 'free-gifts-for-woocommerce' ),
			'4' => __( 'User purchases the Specified Number of Products', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule product applicable filter options
		 *
		 * @since 9.2
		 */
		$rule_product_applicable_filters = apply_filters( 'fgf_rule_product_applicable_filter_options', $rule_product_applicable_filters );

		return $rule_product_applicable_filters;
	}

}

if ( ! function_exists( 'fgf_rule_category_applicable_filter_options' ) ) {

	/**
	 * Get the rule category applicable filter options
	 *
	 * @since 9.2
	 * @return array
	 */
	function fgf_rule_category_applicable_filter_options() {
		static $rule_category_applicable_filters;
		if ( isset( $rule_category_applicable_filters ) ) {
			return $rule_category_applicable_filters;
		}

		$rule_category_applicable_filters = array(
			'1' => __( 'Any one of the product(s) should be from the selected category', 'free-gifts-for-woocommerce' ),
			'2' => __( 'One product from each category must be in cart', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Only products from the selected category should be in cart', 'free-gifts-for-woocommerce' ),
			'4' => __( 'Total Quantity of the Product(s) from the selected categories', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule category applicable filter options
		 *
		 * @since 9.2
		 */
		$rule_category_applicable_filters = apply_filters( 'fgf_rule_category_applicable_filter_options', $rule_category_applicable_filters );

		return $rule_category_applicable_filters;
	}

}

if ( ! function_exists( 'fgf_rule_applicable_brands_filter_options' ) ) {

	/**
	 * Get the rule applicable brands filter options
	 *
	 * @since 9.4.0
	 * @return array
	 */
	function fgf_rule_applicable_brands_filter_options() {
		static $rule_applicable_brand_filters;
		if ( isset( $rule_applicable_brand_filters ) ) {
			return $rule_applicable_brand_filters;
		}

		$rule_applicable_brand_filters = array(
			'1' => __( 'Any one of the product(s) should be in the cart from the selected Brand(s)', 'free-gifts-for-woocommerce' ),
			'2' => __( 'One product from each Brand must be in cart', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Only products from the selected Brand(s) should be in cart', 'free-gifts-for-woocommerce' ),
			'4' => __( 'Total Quantity of the Product(s) from the selected brands', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule applicable brands filter options
		 *
		 * @since 9.4.0
		 */
		$rule_applicable_brand_filters = apply_filters( 'fgf_rule_applicable_brands_filter_options', $rule_applicable_brand_filters );

		return $rule_applicable_brand_filters;
	}

}

if ( ! function_exists( 'fgf_rule_filter_coupon_applicable_type_options' ) ) {

	/**
	 * Get the rule filter coupon applicable type options
	 *
	 * @since 13.0.0
	 * @return array
	 */
	function fgf_rule_filter_coupon_applicable_type_options() {
		static $rule_filter_coupon_applicable_type_filters;
		if ( isset( $rule_filter_coupon_applicable_type_filters ) ) {
			return $rule_filter_coupon_applicable_type_filters;
		}

		$rule_filter_coupon_applicable_type_filters = array(
			'1' => __( 'Any one of the selected coupon(s) must be applied', 'free-gifts-for-woocommerce' ),
			'2' => __( 'All the selected coupon(s) must be applied', 'free-gifts-for-woocommerce' ),
			'3' => __( 'Only the selected coupon(s) must be applied', 'free-gifts-for-woocommerce' ),
			'4' => __( 'User applied the Specified Number of coupons', 'free-gifts-for-woocommerce' ),
		);
		/**
		 * This hook is used to alter the rule filter coupon applicable type options
		 *
		 * @since 13.0.0
		 */
		$rule_filter_coupon_applicable_type_filters = apply_filters( 'fgf_rule_filter_coupon_applicable_type_options', $rule_filter_coupon_applicable_type_filters );

		return $rule_filter_coupon_applicable_type_filters;
	}

}

if ( ! function_exists( 'fgf_get_eligible_notices_display_all_pages_value' ) ) {

	/**
	 * Get the value the All Pages choice of the eligible notices is held as.
	 *
	 * The value is not empty, so that the multiselect sanitizer of WooCommerce keeps
	 * it along with the page ids instead of dropping it with the empty values.
	 *
	 * @since 13.8.0
	 * @return string
	 */
	function fgf_get_eligible_notices_display_all_pages_value() {
		return 'all';
	}

}

if ( ! function_exists( 'fgf_get_default_eligible_notices_display_pages' ) ) {

	/**
	 * Get the pages the eligible notices are displayed on by default.
	 *
	 * The ids are answered as strings, the form the multiselect setting holds and
	 * compares its options against.
	 *
	 * @since 13.8.0
	 * @return array
	 */
	function fgf_get_default_eligible_notices_display_pages() {
		// The setting held the Cart & Checkout choice by default before 13.8.0, so
		// the cart and the checkout pages are the default pages.
		$page_ids = array( wc_get_page_id( 'cart' ), wc_get_page_id( 'checkout' ) );
		$page_ids = array_map( 'strval', array_values( array_filter( array_map( 'absint', $page_ids ) ) ) );

		/**
		 * This hook is used to alter the default eligible notices display pages.
		 *
		 * @since 13.8.0
		 */
		return apply_filters( 'fgf_default_eligible_notices_display_pages', $page_ids );
	}

}

if ( ! function_exists( 'fgf_get_pages_options' ) ) {

	/**
	 * Get the pages of the site as options.
	 *
	 * A draft page is never served to a visitor, so it is not offered. Any page given
	 * in $include_page_ids is offered whatever its status, so a page already chosen
	 * for a setting is not dropped from it the next time the settings are saved.
	 *
	 * @since 13.8.0
	 * @param array $include_page_ids Ids of the pages to offer whatever their status.
	 * @return array
	 */
	function fgf_get_pages_options( $include_page_ids = array() ) {
		$include_page_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $include_page_ids ) ) ) );

		static $pages_options = array();
		$cache_key = implode( ',', $include_page_ids );
		if ( isset( $pages_options[ $cache_key ] ) ) {
			return $pages_options[ $cache_key ];
		}

		$options = array();

		// The list is only there to render and to save the settings page, and the
		// settings are also built on a frontend request to fill their defaults in, so
		// the pages are not queried for it.
		if ( ! is_admin() ) {
			$pages_options[ $cache_key ] = $options;

			return $pages_options[ $cache_key ];
		}

		$pages = get_pages(
			/**
			 * This hook is used to alter the arguments the pages are queried with.
			 *
			 * @since 13.8.0
			 */
			apply_filters(
				'fgf_pages_options_query_args',
				array(
					'sort_column' => 'menu_order,post_title',
					'sort_order' => 'ASC',
					'post_status' => array( 'publish', 'private' ),
				)
			)
		);

		// The page holding the posts is served as the blog archive, where the content
		// of the page itself is never rendered, so it is left out rather than offered
		// as a page the notices could never be shown on.
		$posts_page_id = absint( get_option( 'page_for_posts' ) );

		if ( is_array( $pages ) ) {
			foreach ( $pages as $page ) {
				if ( $posts_page_id && absint( $page->ID ) === $posts_page_id ) {
					continue;
				}

				$options[ $page->ID ] = fgf_get_page_option_label( $page );
			}
		}

		// A page already chosen for a setting is offered even where the list above does
		// not hold it, so that a page since drafted, privatised or trashed is kept by
		// the setting instead of being dropped by the next save.
		foreach ( $include_page_ids as $page_id ) {
			if ( isset( $options[ $page_id ] ) ) {
				continue;
			}

			$page = get_post( $page_id );
			if ( ! is_a( $page, 'WP_Post' ) || 'page' !== $page->post_type ) {
				continue;
			}

			$options[ $page_id ] = fgf_get_page_option_label( $page );
		}

		/**
		 * This hook is used to alter the pages options.
		 *
		 * @since 13.8.0
		 */
		$pages_options[ $cache_key ] = apply_filters( 'fgf_pages_options', $options, $include_page_ids );

		return $pages_options[ $cache_key ];
	}

}

if ( ! function_exists( 'fgf_get_page_option_label' ) ) {

	/**
	 * Get the label a page is offered with.
	 *
	 * @since 13.8.0
	 * @param WP_Post $page Page.
	 * @return string
	 */
	function fgf_get_page_option_label( $page ) {
		$label = $page->post_title ? $page->post_title : sprintf(
			/* translators: %d: page id */
			__( '#%d (no title)', 'free-gifts-for-woocommerce' ),
			$page->ID
		);

		// The page WooCommerce is set up to serve the cart, the checkout or the shop
		// from is named as such, since its title alone does not say so and leaving it
		// out of the chosen pages is what turns its notices off.
		$wc_page_labels = array(
			'cart' => _x( 'Cart', 'the WooCommerce cart page', 'free-gifts-for-woocommerce' ),
			'checkout' => _x( 'Checkout', 'the WooCommerce checkout page', 'free-gifts-for-woocommerce' ),
			'shop' => _x( 'Shop', 'the WooCommerce shop page', 'free-gifts-for-woocommerce' ),
		);

		foreach ( $wc_page_labels as $wc_page => $wc_page_label ) {
			if ( absint( wc_get_page_id( $wc_page ) ) !== absint( $page->ID ) ) {
				continue;
			}

			$label = sprintf(
				/* translators: 1: page title, 2: the WooCommerce page it is set up as */
				_x( '%1$s (%2$s)', 'page offered by a setting', 'free-gifts-for-woocommerce' ),
				$label,
				$wc_page_label
			);
			break;
		}

		// The status of a page that is not published is named, so it is plain that the
		// notices are not shown on it while it stays that way.
		if ( 'publish' !== $page->post_status ) {
			$status = get_post_status_object( $page->post_status );
			$label = sprintf(
				/* translators: 1: page title, 2: post status label */
				_x( '%1$s (%2$s)', 'page offered by a setting', 'free-gifts-for-woocommerce' ),
				$label,
				$status ? $status->label : $page->post_status
			);
		}

		return $label;
	}

}
