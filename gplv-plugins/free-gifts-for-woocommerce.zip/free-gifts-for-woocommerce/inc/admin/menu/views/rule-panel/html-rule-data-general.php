<?php
/**
 * Panel - General.
 *
 * @since 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div id="fgf_rule_data_general" class='fgf-rule-options-wrapper'>
	<?php
	include_once 'html-rule-data-manual-gifts.php';
	include_once 'html-rule-data-bogo-gifts.php';
	include_once 'html-rule-data-coupon-gifts.php';
	include_once 'html-rule-data-subtotal-gifts.php';
	include_once 'html-rule-data-bulk-pricing-gifts.php';
	include_once 'html-rule-data-bulk-quantity-gifts.php';
	include_once 'html-rule-data-cheapest-gifts.php';
	include_once 'html-rule-data-free-shipping.php';
	?>
</div>
<?php
