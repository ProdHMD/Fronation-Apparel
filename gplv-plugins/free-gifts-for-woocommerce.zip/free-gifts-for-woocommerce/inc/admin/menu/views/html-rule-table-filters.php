<?php
/**
 * Rule table filters.
 *
 * The rules are filtered by the type of the rule and by the reward it awards its
 * gifts with, and both are kept in the query string of the list table.
 *
 * @since 13.8.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- The filters are read from the list table query string.
$rule_type = isset( $_REQUEST['fgf_rule_types'] ) ? wc_clean( wp_unslash( $_REQUEST['fgf_rule_types'] ) ) : '';
$reward = isset( $_REQUEST['fgf_rule_reward'] ) ? wc_clean( wp_unslash( $_REQUEST['fgf_rule_reward'] ) ) : '';
// phpcs:enable
?>
<select class='fgf-rule-types' name='fgf_rule_types'>
	<option value='' <?php selected( $rule_type, '' ); ?>><?php esc_html_e( 'Select a Rule Type', 'free-gifts-for-woocommerce' ); ?></option>
	<?php foreach ( fgf_get_rule_types() as $type_id => $type_name ) : ?>
		<option value='<?php echo esc_attr( $type_id ); ?>' <?php selected( $rule_type, $type_id ); ?>><?php echo esc_html( $type_name ); ?></option>
	<?php endforeach; ?>
</select>
<select class='fgf-rule-rewards' name='fgf_rule_reward'>
	<option value='' <?php selected( $reward, '' ); ?>><?php esc_html_e( 'Select Offer Type', 'free-gifts-for-woocommerce' ); ?></option>
	<?php foreach ( fgf_get_rule_gift_reward_type_options() as $type_id => $type_name ) : ?>
		<option value='<?php echo esc_attr( $type_id ); ?>' <?php selected( $reward, $type_id ); ?>><?php echo esc_html( $type_name ); ?></option>
	<?php endforeach; ?>
</select>
<?php
