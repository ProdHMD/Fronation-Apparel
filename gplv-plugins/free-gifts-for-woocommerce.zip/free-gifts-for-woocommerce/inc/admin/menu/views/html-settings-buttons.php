<?php
/**
 * Admin HTML settings buttons.
 *
 * The reset button needs its own form, so the settings form is closed here and
 * a second one is opened. Both button rows are kept inside a single wrapper so
 * they line up through flexbox instead of hard coded offsets, which keeps the
 * layout intact on every WordPress admin style version.
 * */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class = 'fgf-settings-buttons'>
	<?php if ( ! isset( $GLOBALS['hide_save_button'] ) ) : ?>
		<p class = 'submit fgf-settings-buttons-item'>
			<input name='fgf_save' class='button-primary fgf-settings-save-btn submit' type='submit' value="<?php esc_attr_e( 'Save changes', 'free-gifts-for-woocommerce' ); ?>" />
			<input type="hidden" name="save" value="save"/>
			<?php wp_nonce_field( 'fgf_save_settings', '_fgf_nonce', false, true ); ?>
		</p>
	<?php endif; ?>

	<?php if ( $reset ) : ?>
		</form>
		<form method='post' action='' enctype='multipart/form-data' class="fgf-reset-form">
			<p class = 'submit fgf-settings-buttons-item'>
				<input id='reset' name='fgf_reset' class='button-secondary fgf-settings-reset-btn' type='submit' value="<?php esc_attr_e( 'Reset', 'free-gifts-for-woocommerce' ); ?>"/>
				<input type="hidden" name="reset" value="reset"/>
				<?php wp_nonce_field( 'fgf_reset_settings', '_fgf_nonce', false, true ); ?>
			</p>
		</form>
	<?php endif; ?>
</div>
