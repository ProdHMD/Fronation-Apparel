<?php

/**
 * Compatibility Tab.
 *
 * @since 12.9.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( class_exists( 'FGF_Compatibility_Tab' ) ) {
	return new FGF_Compatibility_Tab();
}

/**
 * Class.
 *
 * @since 12.9.0
 */
class FGF_Compatibility_Tab extends FGF_Settings_Page {

	/**
	 * Constructor.
	 *
	 * @since 12.9.0
	 */
	public function __construct() {
		$this->id = 'compatibility';
		$this->label = __( 'Compatibility', 'free-gifts-for-woocommerce' );

		parent::__construct();
	}
}

return new FGF_Settings_Tab();
