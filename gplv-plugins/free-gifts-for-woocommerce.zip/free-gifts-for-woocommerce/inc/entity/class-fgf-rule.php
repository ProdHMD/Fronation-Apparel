<?php

/**
 * Rule.
 *
 * @since 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'FGF_Rule' ) ) {

	/**
	 * Class.
	 *
	 * @since 1.0.0
	 */
	class FGF_Rule extends FGF_Post {

		/**
		 * Post Type.
		 *
		 * @since 1.0.0
		 * @var string
		 */
		protected $post_type = FGF_Register_Post_Types::RULES_POSTTYPE;

		/**
		 * Post Status.
		 *
		 * @since 1.0.0
		 * @var string
		 */
		protected $post_status = 'fgf_active';

		/**
		 * Post keys.
		 *
		 * @since 11.1.0
		 * @var array.
		 * */
		protected $post_keys = array(
			'description' => 'post_content',
		);

		/**
		 * Meta data keys.
		 *
		 * @since 1.0.0
		 * @var array
		 */
		protected $meta_data_keys = array(
			'fgf_rule_type' => '1',
			'fgf_rule_consider_type' => '1',
			'fgf_gift_reward_type' => '1',
			'fgf_gift_discount_type' => '1',
			'fgf_gift_discount_value' => '',
			'fgf_gift_type' => '1',
			'fgf_gift_products' => array(),
			'fgf_gift_categories' => array(),
			'fgf_automatic_gift_selection' => '1',
			'fgf_automatic_gift_price_consider_type' => '1',
			'fgf_automatic_gift_count' => '1',
			'fgf_automatic_variation_selection' => '1',
			'fgf_automatic_product_qty' => '',
			'fgf_bogo_gift_type' => '1',
			'fgf_buy_product_type' => '1',
			'fgf_buy_category_type' => '1',
			'fgf_buy_product' => array(),
			'fgf_buy_categories' => array(),
			'fgf_buy_product_consider_type' => '1',
			'fgf_buy_category_consider_type' => '1',
			'fgf_buy_product_quantity_consider_type' => '1',
			'fgf_get_product_type' => '1',
			'fgf_get_products' => array(),
			'fgf_get_categories' => array(),
			'fgf_bogo_automatic_gift_selection' => '1',
			'fgf_bogo_automatic_gift_price_consider_type' => '1',
			'fgf_bogo_automatic_gift_count' => '1',
			'fgf_bogo_automatic_variation_selection' => '1',
			'fgf_buy_quantity_type' => '1',
			'fgf_bogo_get_gift_type' => '1',
			'fgf_buy_product_count' => '',
			'fgf_get_product_count' => '',
			'fgf_bogo_gift_repeat' => '',
			'fgf_bogo_gift_repeat_mode' => '1',
			'fgf_bogo_gift_repeat_limit' => '',
			'fgf_apply_coupon' => array(),
			'fgf_coupon_gift_type' => '1',
			'fgf_coupon_gift_products' => array(),
			'fgf_coupon_gift_categories' => array(),
			'fgf_coupon_automatic_gift_selection' => '1',
			'fgf_coupon_automatic_gift_price_consider_type' => '1',
			'fgf_coupon_automatic_gift_count' => '1',
			'fgf_coupon_automatic_variation_selection' => '1',
			'fgf_coupon_gift_products_qty' => '1',
			'fgf_subtotal_price_type' => '1',
			'fgf_total_categories' => array(),
			'fgf_consider_subcategories_total' => 1,
			'fgf_calculate_total_discounted_category_total' => 1,
			'fgf_subtotal_price' => '',
			'fgf_subtotal_gift_type' => '1',
			'fgf_subtotal_gift_products' => array(),
			'fgf_subtotal_gift_categories' => array(),
			'fgf_subtotal_automatic_gift_selection' => '1',
			'fgf_subtotal_automatic_gift_price_consider_type' => '1',
			'fgf_subtotal_automatic_gift_count' => '1',
			'fgf_subtotal_automatic_variation_selection' => '1',
			'fgf_total_gift_products_qty_type' => '1',
			'fgf_subtotal_gift_products_qty' => '1',
			'fgf_subtotal_repeat_gift' => 'no',
			'fgf_subtotal_repeat_gift_mode' => '1',
			'fgf_subtotal_repeat_gift_limit' => '1',
			'fgf_bulk_quantity_rules_consider_type' => '1',
			'fgf_bulk_quantity_rules' => array(),
			'fgf_bulk_quantity_automatic_gift_selection' => '1',
			'fgf_bulk_quantity_automatic_gift_price_consider_type' => '1',
			'fgf_bulk_quantity_automatic_gift_count' => '1',
			'fgf_bulk_quantity_automatic_variation_selection' => '1',
			'fgf_bulk_pricing_total_type' => '1',
			'fgf_bulk_pricing_categories' => array(),
			'fgf_consider_bulk_pricing_subcategories_total' => '1',
			'fgf_calculate_bulk_pricing_discounted_category_total' => '1',
			'fgf_bulk_pricing_rules_consider_type' => '1',
			'fgf_bulk_pricing_rules' => array(),
			'fgf_bulk_pricing_automatic_gift_selection' => '1',
			'fgf_bulk_pricing_automatic_gift_price_consider_type' => '1',
			'fgf_bulk_pricing_automatic_gift_count' => '1',
			'fgf_bulk_pricing_automatic_variation_selection' => '1',
			'fgf_cheapest_gift_price_type' => '1',
			'fgf_cheapest_gift_quantity' => '1',
			'fgf_free_shipping_methods' => array(),
			'fgf_rule_valid_from_date' => '',
			'fgf_rule_valid_to_date' => '',
			'fgf_rule_week_days_validation' => array(),
			'fgf_rule_gifts_count_per_order' => '',
			'fgf_rule_usage_count' => '',
			'fgf_rule_restriction_count' => '',
			'fgf_rule_allowed_user_type' => '1',
			'fgf_rule_allowed_user_count' => '1',
			'fgf_rule_allowed_user_usage_count' => array(),
			'fgf_rule_user_purchased_order_count_type' => 1,
			'fgf_rule_user_purchased_order_min_count' => 1,
			'fgf_rule_user_purchased_order_max_count' => 1,
			'fgf_rule_restrict_by_wocommerce_coupon_type' => '1',
			'fgf_rule_restrict_by_wocommerce_coupon' => '1',
			'fgf_condition_type' => '',
			'fgf_total_type' => '',
			'fgf_cart_categories' => array(),
			'fgf_consider_cart_subcategories_total' => 1,
			'fgf_exclude_category_subtotal_discount_amount' => '',
			'fgf_cart_subtotal_min_value' => '',
			'fgf_cart_subtotal_max_value' => '',
			'fgf_quantity_min_value' => '',
			'fgf_quantity_max_value' => '',
			'fgf_product_count_min_value' => '',
			'fgf_product_count_max_value' => '',
			'fgf_user_filter_type' => '',
			'fgf_include_users' => array(),
			'fgf_exclude_users' => array(),
			'fgf_include_user_roles' => array(),
			'fgf_exclude_user_roles' => array(),
			'fgf_product_filter_type' => '',
			'fgf_include_products' => array(),
			'fgf_include_product_count' => '',
			'fgf_exclude_products' => array(),
			'fgf_applicable_products_type' => '',
			'fgf_applicable_categories_type' => '',
			'fgf_include_categories' => array(),
			'fgf_include_category_product_count' => '1',
			'fgf_exclude_categories' => array(),
			'fgf_virtual_product_restriction' => '1',
			'fgf_filter_coupon_type' => '1',
			'fgf_filter_coupon_applicable_type' => '1',
			'fgf_filter_coupon_count' => '1',
			'fgf_filter_include_coupons' => array(),
			'fgf_filter_exclude_coupons' => array(),
			'fgf_show_notice' => '1',
			'fgf_notice' => '',
			'fgf_notice_image_id' => '',
			'fgf_show_notice_progress_bar' => '1',
			'fgf_show_bogo_eligible_notice' => '1',
			'fgf_bogo_eligible_notice' => '',
			'fgf_show_bulk_eligible_notice' => '1',
			'fgf_bulk_eligible_notice' => '',
			'fgf_bulk_notice_image_id' => '',
			'fgf_show_bulk_notice_progress_bar' => '1',
		);

		/**
		 * Duplicate meta data keys.
		 *
		 * @since 9.9.0
		 * @var array
		 */
		protected $duplicate_meta_keys = array(
			'fgf_rule_type',
			'fgf_rule_consider_type',
			'fgf_gift_reward_type',
			'fgf_gift_discount_type',
			'fgf_gift_discount_value',
			'fgf_gift_type',
			'fgf_gift_products',
			'fgf_gift_categories',
			'fgf_automatic_gift_selection',
			'fgf_automatic_gift_price_consider_type',
			'fgf_automatic_gift_count',
			'fgf_automatic_variation_selection',
			'fgf_automatic_product_qty',
			'fgf_bogo_gift_type',
			'fgf_buy_product_type',
			'fgf_buy_product',
			'fgf_buy_categories',
			'fgf_buy_product_consider_type',
			'fgf_buy_category_consider_type',
			'fgf_buy_category_type',
			'fgf_buy_product_quantity_consider_type',
			'fgf_get_product_type',
			'fgf_get_products',
			'fgf_get_categories',
			'fgf_bogo_automatic_gift_selection',
			'fgf_bogo_automatic_gift_price_consider_type',
			'fgf_bogo_automatic_gift_count',
			'fgf_bogo_automatic_variation_selection',
			'fgf_buy_quantity_type',
			'fgf_bogo_get_gift_type',
			'fgf_buy_product_count',
			'fgf_get_product_count',
			'fgf_bogo_gift_repeat',
			'fgf_bogo_gift_repeat_mode',
			'fgf_bogo_gift_repeat_limit',
			'fgf_apply_coupon',
			'fgf_coupon_gift_type',
			'fgf_coupon_gift_products',
			'fgf_coupon_gift_categories',
			'fgf_coupon_automatic_gift_selection',
			'fgf_coupon_automatic_gift_price_consider_type',
			'fgf_coupon_automatic_gift_count',
			'fgf_coupon_automatic_variation_selection',
			'fgf_coupon_gift_products_qty',
			'fgf_subtotal_price_type',
			'fgf_total_categories',
			'fgf_consider_subcategories_total',
			'fgf_calculate_total_discounted_category_total',
			'fgf_subtotal_price',
			'fgf_subtotal_gift_type',
			'fgf_subtotal_gift_products',
			'fgf_subtotal_gift_categories',
			'fgf_subtotal_automatic_gift_selection',
			'fgf_subtotal_automatic_gift_price_consider_type',
			'fgf_subtotal_automatic_gift_count',
			'fgf_subtotal_automatic_variation_selection',
			'fgf_total_gift_products_qty_type',
			'fgf_subtotal_gift_products_qty',
			'fgf_subtotal_repeat_gift',
			'fgf_subtotal_repeat_gift_mode',
			'fgf_subtotal_repeat_gift_limit',
			'fgf_bulk_quantity_rules_consider_type',
			'fgf_bulk_quantity_rules',
			'fgf_bulk_quantity_automatic_gift_selection',
			'fgf_bulk_quantity_automatic_gift_price_consider_type',
			'fgf_bulk_quantity_automatic_gift_count',
			'fgf_bulk_quantity_automatic_variation_selection',
			'fgf_bulk_pricing_total_type',
			'fgf_bulk_pricing_categories',
			'fgf_consider_bulk_pricing_subcategories_total',
			'fgf_calculate_bulk_pricing_discounted_category_total',
			'fgf_bulk_pricing_rules_consider_type',
			'fgf_bulk_pricing_rules',
			'fgf_bulk_pricing_automatic_gift_selection',
			'fgf_bulk_pricing_automatic_gift_price_consider_type',
			'fgf_bulk_pricing_automatic_gift_count',
			'fgf_bulk_pricing_automatic_variation_selection',
			'fgf_cheapest_gift_price_type',
			'fgf_cheapest_gift_quantity',
			'fgf_free_shipping_methods',
			'fgf_rule_valid_from_date',
			'fgf_rule_valid_to_date',
			'fgf_rule_week_days_validation',
			'fgf_rule_gifts_count_per_order',
			'fgf_rule_usage_count',
			'fgf_rule_restriction_count',
			'fgf_rule_allowed_user_type',
			'fgf_rule_allowed_user_count',
			'fgf_rule_allowed_user_usage_count',
			'fgf_rule_user_purchased_order_count_type',
			'fgf_rule_user_purchased_order_min_count',
			'fgf_rule_user_purchased_order_max_count',
			'fgf_exclude_category_subtotal_discount_amount',
			'fgf_rule_restrict_by_wocommerce_coupon_type',
			'fgf_rule_restrict_by_wocommerce_coupon',
			'fgf_condition_type',
			'fgf_total_type',
			'fgf_cart_categories',
			'fgf_consider_cart_subcategories_total',
			'fgf_cart_subtotal_min_value',
			'fgf_cart_subtotal_max_value',
			'fgf_quantity_min_value',
			'fgf_quantity_max_value',
			'fgf_product_count_min_value',
			'fgf_product_count_max_value',
			'fgf_show_notice',
			'fgf_notice',
			'fgf_notice_image_id',
			'fgf_show_notice_progress_bar',
			'fgf_show_bogo_eligible_notice',
			'fgf_bogo_eligible_notice',
			'fgf_show_bulk_eligible_notice',
			'fgf_bulk_eligible_notice',
			'fgf_bulk_notice_image_id',
			'fgf_show_bulk_notice_progress_bar',
			'fgf_user_filter_type',
			'fgf_include_users',
			'fgf_exclude_users',
			'fgf_include_user_roles',
			'fgf_exclude_user_roles',
			'fgf_product_filter_type',
			'fgf_include_products',
			'fgf_include_product_count',
			'fgf_exclude_products',
			'fgf_applicable_products_type',
			'fgf_applicable_categories_type',
			'fgf_include_categories',
			'fgf_include_category_product_count',
			'fgf_exclude_categories',
			'fgf_virtual_product_restriction',
			'fgf_filter_coupon_type',
			'fgf_filter_coupon_applicable_type',
			'fgf_filter_coupon_count',
			'fgf_filter_include_coupons',
			'fgf_filter_exclude_coupons',
		);

		/**
		 * Compatibility meta data keys.
		 *
		 * @since 9.4.0
		 * @var array
		 */
		protected $compatibility_meta_data_keys = array(
			'fgf_gift_brands' => array(),
			'fgf_cart_brands' => array(),
			'fgf_applicable_brands_type' => '1',
			'fgf_include_brands' => array(),
			'fgf_exclude_brands' => array(),
			'fgf_brand_product_count' => '',
			'fgf_buy_product_brands' => array(),
			'fgf_buy_brand_consider_type' => '1',
			'fgf_buy_brand_quantity_consider_type' => '1',
			'fgf_get_product_brands' => array(),
			'fgf_subtotal_gift_total_brands' => array(),
			'fgf_subtotal_gift_brands' => array(),
			'fgf_coupon_gift_brands' => array(),
		);

		/**
		 * Get the formatted created date time.
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_formatted_created_date() {
			return FGF_Date_Time::get_wp_format_datetime( $this->get_created_date() );
		}

		/**
		 * Get the formatted modified date time.
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_formatted_modified_date() {
			return FGF_Date_Time::get_wp_format_datetime( $this->get_modified_date() );
		}

		/**
		 * Get the notice image URL.
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_notice_image_url() {
			return ( $this->get_notice_image_id() ) ? wp_get_attachment_image_url( $this->get_notice_image_id() ) : '';
		}

		/**
		 * Get the bulk notice image URL.
		 *
		 * @since 12.0.0
		 * @return string
		 */
		public function get_bulk_notice_image_url() {
			return ( $this->get_bulk_notice_image_id() ) ? wp_get_attachment_image_url( $this->get_bulk_notice_image_id() ) : '';
		}

		/**
		 * Get the rule mode.
		 *
		 * @since 1.0.0
		 * @return string
		 */
		public function get_rule_mode() {
			switch ( $this->get_rule_type() ) {
				case '2':
					$mode = 'automatic';
					break;
				case '3':
					$mode = 'bogo';
					break;
				case '4':
					$mode = 'coupon';
					break;
				case '5':
					$mode = 'manual_bogo';
					break;
				case '6':
					$mode = 'manual_coupon';
					break;
				case '7':
					$mode = 'manual_subtotal';
					break;
				case '8':
					$mode = 'subtotal';
					break;
				case '9':
					$mode = 'manual_bulk_pricing';
					break;
				case '10':
					$mode = 'bulk_pricing';
					break;
				case '11':
					$mode = 'manual_bulk_quantity';
					break;
				case '12':
					$mode = 'bulk_quantity';
					break;
				case '13':
					$mode = 'manual_cheapest_gift';
					break;
				case '14':
					$mode = 'cheapest_gift';
					break;
				default:
					$mode = 'manual';
					break;
			}

			return $mode;
		}

		/**
		 * Is the gift awarded at a discount instead of for free?
		 *
		 * The gift is awarded at a discount only when the reward is set to the
		 * discounted gift and a discount value is configured.
		 *
		 * @since 13.8.0
		 * @param array $bulk_rule Bulk rule the gift is awarded for. Default empty.
		 * @return bool
		 */
		public function is_gift_discount_enabled( $bulk_rule = array() ) {
			$reward = $this->get_effective_gift_reward( $bulk_rule );

			return '2' === (string) $reward['reward_type'] && (float) $reward['discount_value'] > 0;
		}

		/**
		 * Is the progress bar of the eligibility notice enabled?.
		 *
		 * @since 13.8.0
		 * @param bool $bulk Whether the bulk eligibility notice is asked for.
		 * @return bool
		 */
		public function is_notice_progress_bar_enabled( $bulk = false ) {
			if ( $bulk ) {
				return '2' == $this->get_show_bulk_notice_progress_bar();
			}

			return '2' == $this->get_show_notice_progress_bar();
		}

		/**
		 * Pick the criterion that decides the progress of the eligibility notice.
		 *
		 * The rule combines its criteria with AND or with OR, so when more than one
		 * of them is configured the progress follows the criterion furthest from
		 * completion for AND - the gift is only unlocked once every criterion is met
		 * - and the closest one for OR, where any one of them is enough.
		 *
		 * @since 13.8.0
		 * @param array $criteria Criteria measured against the cart.
		 * @return array|null
		 */
		public function pick_progress_criterion( $criteria ) {
			if ( ! fgf_check_is_array( $criteria ) ) {
				return null;
			}

			$is_any_condition = '2' == $this->get_condition_type();
			$picked           = null;
			foreach ( $criteria as $criterion ) {
				if ( is_null( $picked ) ) {
					$picked = $criterion;
					continue;
				}

				if ( $is_any_condition ? $criterion['percentage'] > $picked['percentage'] : $criterion['percentage'] < $picked['percentage'] ) {
					$picked = $criterion;
				}
			}

			return $picked;
		}

		/**
		 * Get the reward type the gift is awarded with.
		 *
		 * A reward configured as a discount but left without a discount value
		 * awards the gift for free, so the gift is awarded as a free gift.
		 *
		 * @since 13.8.0
		 * @param array $bulk_rule Bulk rule the gift is awarded for. Default empty.
		 * @return string
		 */
		public function get_awarded_gift_reward_type( $bulk_rule = array() ) {
			return $this->is_gift_discount_enabled( $bulk_rule ) ? '2' : '1';
		}

		/**
		 * Get the reward the gift products are awarded with.
		 *
		 * Each bulk rule carries its own reward, so that a rule can award a bigger
		 * discount on its higher tiers. A gift awarded for a bulk rule is therefore
		 * never priced with the reward of the rule, and a bulk rule saved before the
		 * reward was introduced awards a free gift as it did then.
		 *
		 * @since 13.8.0
		 * @param array $bulk_rule Bulk rule the gift is awarded for. Default empty.
		 * @return array
		 */
		public function get_effective_gift_reward( $bulk_rule = array() ) {
			if ( fgf_check_is_array( $bulk_rule ) ) {
				$reward_types = fgf_get_rule_gift_reward_type_options();

				return array(
					'reward_type' => isset( $bulk_rule['reward_type'] ) && array_key_exists( $bulk_rule['reward_type'], $reward_types ) ? $bulk_rule['reward_type'] : '1',
					'discount_type' => isset( $bulk_rule['discount_type'] ) ? $bulk_rule['discount_type'] : '1',
					'discount_value' => isset( $bulk_rule['discount_value'] ) ? $bulk_rule['discount_value'] : '',
				);
			}

			return array(
				'reward_type' => $this->get_gift_reward_type(),
				'discount_type' => $this->get_gift_discount_type(),
				'discount_value' => $this->get_gift_discount_value(),
			);
		}

		/**
		 * Get the price at which the rule awards the given gift product.
		 *
		 * The gift is awarded for free, unless the rule awards it at a discount off
		 * the gift product's own price.
		 *
		 * @since 13.8.0
		 * @param int|object $product
		 * @param array      $bulk_rule Bulk rule the gift is awarded for. Default empty.
		 * @return float|string
		 */
		public function get_gift_product_price( $product, $bulk_rule = array() ) {
			$product = is_object( $product ) ? $product : wc_get_product( $product );
			$price = fgf_get_free_gift_product_price();

			if ( is_object( $product ) && $this->is_gift_discount_enabled( $bulk_rule ) ) {
				$product_price = (float) $product->get_price();
				$reward = $this->get_effective_gift_reward( $bulk_rule );
				$discount = (float) $reward['discount_value'];

				// The percentage discount is taken off the gift product's own price.
				if ( '1' === (string) $reward['discount_type'] ) {
					$discount = $product_price * $discount / 100;
				}

				// The gift is never awarded at a negative price.
				$price = max( 0, round( $product_price - $discount, wc_get_price_decimals() ) );
			}

			/**
			 * This hook is used to alter the price at which the rule awards the gift product.
			 *
			 * @since 13.8.0
			 */
			return apply_filters( 'fgf_rule_gift_product_price', $price, $this, $product, $bulk_rule );
		}

		/**
		 * Get the bulk rules the rule awards its gifts for.
		 *
		 * Only the bulk pricing and the bulk quantity rule types award their gifts
		 * for bulk rules, and each of them keeps those rules in its own field.
		 *
		 * @since 13.8.0
		 * @return array
		 */
		public function get_bulk_rules() {
			switch ( $this->get_rule_type() ) {
				case '9':
				case '10':
					return $this->get_bulk_pricing_rules();

				case '11':
				case '12':
					return $this->get_bulk_quantity_rules();
			}

			return array();
		}

		/**
		 * Get the label of the reward the rule awards its gifts with.
		 *
		 * Each bulk rule carries its own reward, so a bulk rule is labelled with the
		 * reward it awards rather than with the reward of the rule.
		 *
		 * @since 13.8.0
		 * @param array $bulk_rule Bulk rule the gifts are awarded for. Default empty.
		 * @return string The label is not escaped, so escape it where it is displayed.
		 */
		public function get_gift_reward_label( $bulk_rule = array() ) {
			$reward = $this->get_effective_gift_reward( $bulk_rule );
			$reward_types = fgf_get_rule_gift_reward_type_options();

			if ( ! $this->is_gift_discount_enabled( $bulk_rule ) ) {
				return isset( $reward_types['1'] ) ? $reward_types['1'] : '';
			}

			// The percentage is shown as it is configured, and the fixed amount in the
			// store currency, so the reward reads the way it was entered.
			if ( '1' === (string) $reward['discount_type'] ) {
				/* translators: %s: percentage discounted off the gift product price */
				return sprintf( __( '%s%% off', 'free-gifts-for-woocommerce' ), $reward['discount_value'] );
			}

			/* translators: %s: amount discounted off the gift product price */
			return sprintf( __( '%s off', 'free-gifts-for-woocommerce' ), html_entity_decode( wp_strip_all_tags( fgf_price( $reward['discount_value'], false ) ), ENT_QUOTES, 'UTF-8' ) );
		}

		/**
		 * Get the reward the rule awards its gifts with.
		 *
		 * The bulk rules carry a reward on each of their rules, so the rewards they
		 * award are summarised, while every other rule type awards the one reward it
		 * carries.
		 *
		 * @since 13.8.0
		 * @return string The summary is not escaped, so escape it where it is displayed.
		 */
		public function get_gift_reward_summary() {
			$bulk_rules = $this->get_bulk_rules();

			if ( ! fgf_check_is_array( $bulk_rules ) ) {
				return $this->get_gift_reward_label();
			}

			// The same reward is only named once, so a rule that awards one reward on
			// every one of its rules reads as that reward.
			$labels = array();
			foreach ( $bulk_rules as $bulk_rule ) {
				if ( ! fgf_check_is_array( $bulk_rule ) ) {
					continue;
				}

				$labels[] = $this->get_gift_reward_label( $bulk_rule );
			}

			return fgf_check_is_array( $labels ) ? implode( ', ', array_unique( $labels ) ) : '';
		}

		/**
		 * Get the current gift product selection type.
		 *
		 * Every rule type keeps its gift product selection in its own field, and the
		 * bulk rules keep it in each of their bulk rules. An empty value is returned
		 * for the rules that let the user choose the gift, since those never resolve
		 * the gift on their own.
		 *
		 * @since 13.7.0
		 * @param array $bulk_rule
		 * @return string
		 */
		public function get_current_automatic_gift_type( $bulk_rule = array() ) {
			switch ( $this->get_rule_type() ) {
				// Automatic gifts.
				case '2':
					return $this->get_gift_type();

				// BOGO based automatic gifts.
				case '3':
					// The same bought product is gifted, so there is nothing to pick from.
					if ( '1' === $this->get_bogo_gift_type() ) {
						return '';
					}

					return $this->get_product_type();

				// Coupon based automatic gifts.
				case '4':
					return $this->get_coupon_gift_type();

				// Total based automatic gifts.
				case '8':
					return $this->get_subtotal_gift_type();

				// Bulk pricing/quantity based automatic gifts.
				case '10':
				case '12':
					return isset( $bulk_rule['gift_type'] ) ? $bulk_rule['gift_type'] : '';
			}

			return '';
		}

		/**
		 * Get the current gift selection.
		 *
		 * @since 13.7.0
		 * @return string
		 */
		public function get_current_automatic_gift_selection() {
			switch ( $this->get_rule_type() ) {
				// Automatic gifts.
				case '2':
					return $this->get_automatic_gift_selection();

				// BOGO based automatic gifts.
				case '3':
					return $this->get_bogo_automatic_gift_selection();

				// Coupon based automatic gifts.
				case '4':
					return $this->get_coupon_automatic_gift_selection();

				// Total based automatic gifts.
				case '8':
					return $this->get_subtotal_automatic_gift_selection();

				// Bulk pricing based automatic gifts.
				case '10':
					return $this->get_bulk_pricing_automatic_gift_selection();

				// Bulk quantity based automatic gifts.
				case '12':
					return $this->get_bulk_quantity_automatic_gift_selection();
			}

			return '';
		}

		/**
		 * Get the current gift price consideration type.
		 *
		 * Decides which of the product prices the Cheapest/Most Expensive gift
		 * selection compares the eligible gifts by.
		 *
		 * @since 13.8.0
		 * @return string
		 */
		public function get_current_automatic_gift_price_consider_type() {
			switch ( $this->get_rule_type() ) {
				// Automatic gifts.
				case '2':
					return $this->get_automatic_gift_price_consider_type();

				// BOGO based automatic gifts.
				case '3':
					return $this->get_bogo_automatic_gift_price_consider_type();

				// Coupon based automatic gifts.
				case '4':
					return $this->get_coupon_automatic_gift_price_consider_type();

				// Total based automatic gifts.
				case '8':
					return $this->get_subtotal_automatic_gift_price_consider_type();

				// Bulk pricing based automatic gifts.
				case '10':
					return $this->get_bulk_pricing_automatic_gift_price_consider_type();

				// Bulk quantity based automatic gifts.
				case '12':
					return $this->get_bulk_quantity_automatic_gift_price_consider_type();
			}

			return '';
		}

		/**
		 * Get the current gift selection count.
		 *
		 * At least a single gift is awarded, so the count never falls below one.
		 *
		 * @since 13.7.0
		 * @return int
		 */
		public function get_current_automatic_gift_count() {
			switch ( $this->get_rule_type() ) {
				// Automatic gifts.
				case '2':
					$count = $this->get_automatic_gift_count();
					break;

				// BOGO based automatic gifts.
				case '3':
					$count = $this->get_bogo_automatic_gift_count();
					break;

				// Coupon based automatic gifts.
				case '4':
					$count = $this->get_coupon_automatic_gift_count();
					break;

				// Total based automatic gifts.
				case '8':
					$count = $this->get_subtotal_automatic_gift_count();
					break;

				// Bulk pricing based automatic gifts.
				case '10':
					$count = $this->get_bulk_pricing_automatic_gift_count();
					break;

				// Bulk quantity based automatic gifts.
				case '12':
					$count = $this->get_bulk_quantity_automatic_gift_count();
					break;

				default:
					$count = 0;
					break;
			}

			return ( $count ) ? $count : 1;
		}

		/**
		 * Get the current gift variation selection.
		 *
		 * @since 13.7.0
		 * @return string
		 */
		public function get_current_automatic_variation_selection() {
			switch ( $this->get_rule_type() ) {
				// Automatic gifts.
				case '2':
					return $this->get_automatic_variation_selection();

				// BOGO based automatic gifts. The bought product is gifted along with
				// its own variation, so nothing is resolved by the rule.
				case '3':
					return ( '1' === $this->get_bogo_gift_type() ) ? '' : $this->get_bogo_automatic_variation_selection();

				// Coupon based automatic gifts.
				case '4':
					return $this->get_coupon_automatic_variation_selection();

				// Total based automatic gifts.
				case '8':
					return $this->get_subtotal_automatic_variation_selection();

				// Bulk pricing based automatic gifts.
				case '10':
					return $this->get_bulk_pricing_automatic_variation_selection();

				// Bulk quantity based automatic gifts.
				case '12':
					return $this->get_bulk_quantity_automatic_variation_selection();
			}

			return '';
		}

		/**
		 * Awards the gifts of the selected categories/brands one at a time?
		 *
		 * @since 13.7.0
		 * @param array $bulk_rule
		 * @return boolean
		 */
		public function awards_single_taxonomy_gift( $bulk_rule = array() ) {
			return in_array( $this->get_current_automatic_gift_type( $bulk_rule ), array( '2', 'brand' ), true );
		}

		/**
		 * Get the prepared BOGO gift details with/without frontend product page link.
		 *
		 * @since 12.0.0
		 * @param int/bool $current_product_id
		 * @return string
		 */
		public function get_prepared_bogo_gift_details( $current_product_id = false ) {
			$details = '';

			switch ( $this->get_rule_type() ) {
				case '5':
					if ( '2' === $this->get_bogo_get_gift_type() ) {
						return self::prepare_products_name_with_link( array( $current_product_id ) );
					}

					$details = ( '2' === $this->get_product_type() ) ? self::prepare_category_name_with_link( $this->get_categories() ) : self::prepare_products_name_with_link( $this->get_products() );
					break;
				case '3':
					if ( '1' === $this->get_bogo_gift_type() ) {
						return self::prepare_products_name_with_link( array( $current_product_id ) );
					}

					$details = ( '2' === $this->get_product_type() ) ? self::prepare_category_name_with_link( $this->get_categories() ) : self::prepare_products_name_with_link( $this->get_products() );
					break;
			}

			/**
			 * This hook is used to alter the prepared BOGO gift details.
			 *
			 * @since 13.7.0
			 */
			return apply_filters( 'fgf_prepared_bogo_gift_details', $details, $this );
		}

		/**
		 * Prepare the term names with the frontend archive link.
		 *
		 * Exposed so the compatibility integrations can render their own taxonomy
		 * based gift details in the same format.
		 *
		 * @since 13.7.0
		 * @param array  $term_ids
		 * @param string $taxonomy
		 * @return string
		 */
		public function get_prepared_terms_details( $term_ids, $taxonomy = 'product_cat' ) {
			return self::prepare_category_name_with_link( $term_ids, $taxonomy );
		}

		/**
		 * Get the eligible notice gifts popup markup (trigger link + hidden modal).
		 *
		 * Returns an empty string when the rule has no displayable gifts so the
		 * "View Gifts" link only appears when there is something to show. The result
		 * is cached per rule for the request, since the same rule's notice can be
		 * resolved multiple times (eligible, bulk and BOGO notice shortcodes).
		 *
		 * @since 13.5.0
		 * @return string
		 */
		public function get_eligible_gifts_popup_html() {
			static $cache = array();

			$rule_id = $this->get_id();
			if ( isset( $cache[ $rule_id ] ) ) {
				return $cache[ $rule_id ];
			}

			$gift_products = FGF_Gift_Products_Handler::get_rule_preview_gift_products( $rule_id );
			if ( ! fgf_check_is_array( $gift_products ) ) {
				$cache[ $rule_id ] = '';

				return '';
			}

			$modal_id = 'fgf-eligible-gifts-modal-' . $rule_id;

			/*
			 * Register the eligible gift products to be rendered outside the notice (in
			 * the footer / Store API). The notice sanitizer (wc_kses_notice) strips form
			 * elements, hidden inputs and the like, which breaks the dropdown layout and
			 * AJAX pagination. Only the trigger link (an anchor) stays inline in the
			 * notice; the modal is rendered intact elsewhere. We store the gift products
			 * (not the markup or display args) so the layout/template work is only done
			 * when the modal is actually output. The heading and trigger label are
			 * option/filter derived, so they are resolved at render time from the rule id.
			 */
			FGF_Notices_Handler::add_eligible_popup_modal( $modal_id, $gift_products, $rule_id );

			/*
			 * The link is dropped into the middle of the notice sentence, which is run
			 * through wpautop() afterwards, and that turns the line breaks the template
			 * is written with into a <br /> that would split the sentence in two.
			 */
			$cache[ $rule_id ] = trim(
				fgf_get_template_html(
					'eligible-gifts-popup-trigger.php',
					array(
						'modal_id' => $modal_id,
						'label' => fgf_get_eligible_gifts_popup_trigger_label( $rule_id ),
					)
				)
			);

			return $cache[ $rule_id ];
		}

		/**
		 * Get the prepared Bulk gift details with/without frontend product page link.
		 *
		 * @since 11.9.0
		 * @param array $bulk_rule
		 * @return string
		 */
		public function get_prepared_bulk_gift_details( $bulk_rule ) {
			$details = '';

			if ( in_array( $this->get_rule_type(), array( '9', '10', '11', '12' ) ) ) {
				$details = ( '2' === $bulk_rule['gift_type'] ) ? self::prepare_category_name_with_link( $bulk_rule['gift_categories'] ) : self::prepare_products_name_with_link( $bulk_rule['gift_products'] );
			}

			/**
			 * This hook is used to alter the prepared bulk gift details.
			 *
			 * @since 13.7.0
			 */
			return apply_filters( 'fgf_prepared_bulk_gift_details', $details, $bulk_rule, $this );
		}

		/**
		 * Prepare products with link.
		 *
		 * @since 11.9.0
		 * @return string
		 * */
		private function prepare_products_name_with_link( $product_ids ) {
			$products_name_with_link = '';

			foreach ( $product_ids as $product_id ) {
				$product = wc_get_product( $product_id );
				// Validate the product.
				if ( ! $product ) {
					continue;
				}

				$products_name_with_link .= '<a href="' . esc_url( $product->get_permalink() ) . '" >' . $product->get_name() . '</a> , ';
			}

			return rtrim( $products_name_with_link, ' , ' );
		}

		/**
		 * Prepare category with link.
		 *
		 * @since 11.9.0
		 * @return string
		 * */
		private function prepare_category_name_with_link( $category_ids, $taxonomy = 'product_cat' ) {
			$category_name_with_link = '';

			foreach ( $category_ids as $category_id ) {
				$category = get_term_by( 'id', $category_id, $taxonomy );
				// Validate the product.
				if ( ! $category ) {
					continue;
				}

				$category_name_with_link .= '<a href="' . esc_url( get_term_link( $category ) ) . '" >' . $category->name . '</a> , ';
			}

			return rtrim( $category_name_with_link, ' , ' );
		}

		/**
		 * Get Buy product quantity consider mode.
		 *
		 * @since 12.0.0
		 * @return string
		 */
		public function get_buy_product_quantity_consider_mode() {
			return '2' === $this->get_buy_category_type() ? 'group' : 'single';
		}

		/**
		 * Is exclude category subtotal discount amount?
		 *
		 * @since 9.6.0
		 * @return boolean
		 */
		public function is_exclude_category_subtotal_discount_amount() {
			return '2' == $this->get_exclude_category_subtotal_discount_amount();
		}

		/**
		 * Is exclude bulk pricing category subtotal discount amount?
		 *
		 * @since 12.0.0
		 * @return boolean
		 */
		public function is_exclude_bulk_pricing_category_subtotal_discount_amount() {
			return '2' == $this->get_calculate_bulk_pricing_discounted_category_total();
		}

		/**
		 * Consider subcategories total?
		 *
		 * @since 9.6.0
		 * @return boolean
		 */
		public function consider_subcategories_total() {
			return '2' == $this->get_consider_subcategories_total();
		}

		/**
		 * Calculate total discounted category total.
		 *
		 * @since 9.6.0
		 * @return boolean
		 */
		public function calculate_total_discounted_category_total() {
			return '2' == $this->get_calculate_total_discounted_category_total();
		}

		/**
		 * Get current buy product consider type
		 *
		 * @since 11.1.0
		 * @return string
		 */
		public function get_current_buy_product_consider_type() {
			/**
			 * This hook is used to alter the Buy product consider type.
			 *
			 * @since 11.3.0
			 */
			return apply_filters( 'fgf_rule_current_buy_product_consider_type', '2' === $this->get_buy_product_type() ? $this->get_buy_category_consider_type() : $this->get_buy_product_consider_type(), $this );
		}

		/**
		 * Get current buy product quantity consider type
		 *
		 * @since 11.1.0
		 * @return string
		 */
		public function get_current_buy_product_quantity_consider_type() {
			/**
			 * This hook is used to alter the Buy product quantity consider type.
			 *
			 * @since 11.3.0
			 */
			return apply_filters( 'fgf_rule_current_buy_product_quantity_consider_type', '2' === $this->get_buy_product_type() ? $this->get_buy_category_type() : $this->get_buy_product_quantity_consider_type(), $this );
		}

		/**
		 * Get the parsed from date time.
		 *
		 * @since 11.5.0
		 * @return string
		 */
		public function get_parsed_from_date() {
			if ( ! $this->get_rule_valid_from_date() || fgf_date_contain_time( $this->get_rule_valid_from_date() ) ) {
				return $this->get_rule_valid_from_date();
			}

			return $this->get_rule_valid_from_date() . ' 00:00';
		}

		/**
		 * Get the parsed to date time.
		 *
		 * @since 11.5.0
		 * @return string
		 */
		public function get_parsed_to_date() {
			if ( ! $this->get_rule_valid_to_date() || fgf_date_contain_time( $this->get_rule_valid_to_date() ) ) {
				return $this->get_rule_valid_to_date();
			}

			return $this->get_rule_valid_to_date() . ' 23:59';
		}

		/**
		 * Get the formatted from date time.
		 *
		 * @since 11.5.0
		 * @return string
		 */
		public function get_formatted_from_date() {
			return FGF_Date_Time::get_wp_format_datetime( $this->get_parsed_from_date() );
		}

		/**
		 * Get the formatted to date time.
		 *
		 * @since 11.5.0
		 * @return string
		 */
		public function get_formatted_to_date() {
			return FGF_Date_Time::get_wp_format_datetime( $this->get_parsed_to_date() );
		}

		/**
		 * Setters and Getters
		 */

		/**
		 * Set description.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_description( $value ) {
			$this->set_post_prop( 'description', $value );
		}

		/**
		 * Set rule type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_rule_type( $value ) {
			$this->set_meta_prop( 'fgf_rule_type', $value );
		}

		/**
		 * Set rule consider type.
		 *
		 * @since 10.3.0
		 * @param string $value
		 */
		public function set_rule_consider_type( $value ) {
			$this->set_meta_prop( 'fgf_rule_consider_type', $value );
		}

		/**
		 * Set gift award type.
		 *
		 * @since 13.8.0
		 * @param string $value
		 */
		public function set_gift_reward_type( $value ) {
			$this->set_meta_prop( 'fgf_gift_reward_type', $value );
		}

		/**
		 * Set gift discount type.
		 *
		 * @since 13.8.0
		 * @param string $value
		 */
		public function set_gift_discount_type( $value ) {
			$this->set_meta_prop( 'fgf_gift_discount_type', $value );
		}

		/**
		 * Set gift discount value.
		 *
		 * @since 13.8.0
		 * @param string $value
		 */
		public function set_gift_discount_value( $value ) {
			$this->set_meta_prop( 'fgf_gift_discount_value', $value );
		}

		/**
		 * Set gift type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_gift_type( $value ) {
			$this->set_meta_prop( 'fgf_gift_type', $value );
		}

		/**
		 * Set gift products.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_gift_products( $value ) {
			$this->set_meta_prop( 'fgf_gift_products', $value );
		}

		/**
		 * Set gift categories.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_gift_categories( $value ) {
			$this->set_meta_prop( 'fgf_gift_categories', $value );
		}

		/**
		 * Set BOGO gift type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_bogo_gift_type( $value ) {
			$this->set_meta_prop( 'fgf_bogo_gift_type', $value );
		}

		/**
		 * Set buy product type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_buy_product_type( $value ) {
			$this->set_meta_prop( 'fgf_buy_product_type', $value );
		}

		/**
		 * Set buy product.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_buy_product( $value ) {
			$this->set_meta_prop( 'fgf_buy_product', $value );
		}

		/**
		 * Set buy categories.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_buy_categories( $value ) {
			$this->set_meta_prop( 'fgf_buy_categories', $value );
		}

		/**
		 * Set buy product consider type.
		 *
		 * @since 11.1.0
		 * @param string $value
		 */
		public function set_buy_product_consider_type( $value ) {
			$this->set_meta_prop( 'fgf_buy_product_consider_type', $value );
		}

		/**
		 * Set buy category consider type.
		 *
		 * @since 11.1.0
		 * @param string $value
		 */
		public function set_buy_category_consider_type( $value ) {
			$this->set_meta_prop( 'fgf_buy_category_consider_type', $value );
		}

		/**
		 * Set buy category type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_buy_category_type( $value ) {
			$this->set_meta_prop( 'fgf_buy_category_type', $value );
		}

		/**
		 * Set buy product quantity consider type.
		 *
		 * @since 11.1.0
		 * @param string $value
		 */
		public function set_buy_product_quantity_consider_type( $value ) {
			$this->set_meta_prop( 'fgf_buy_product_quantity_consider_type', $value );
		}

		/**
		 * Set get product type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_get_product_type( $value ) {
			$this->set_meta_prop( 'fgf_get_product_type', $value );
		}

		/**
		 * Set get products.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_get_products( $value ) {
			$this->set_meta_prop( 'fgf_get_products', $value );
		}

		/**
		 * Set get categories.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_get_categories( $value ) {
			$this->set_meta_prop( 'fgf_get_categories', $value );
		}

		/**
		 * Set buy quantity type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_buy_quantity_type( $value ) {
			$this->set_meta_prop( 'fgf_buy_quantity_type', $value );
		}

		/**
		 * Set BOGO get gift type.
		 *
		 * @since 11.3.0
		 * @param string $value
		 */
		public function set_bogo_get_gift_type( $value ) {
			$this->set_meta_prop( 'fgf_bogo_get_gift_type', $value );
		}

		/**
		 * Set buy product count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_buy_product_count( $value ) {
			$this->set_meta_prop( 'fgf_buy_product_count', $value );
		}

		/**
		 * Set get product count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_get_product_count( $value ) {
			$this->set_meta_prop( 'fgf_get_product_count', $value );
		}

		/**
		 * Set BOGO gift repeat.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_bogo_gift_repeat( $value ) {
			$this->set_meta_prop( 'fgf_bogo_gift_repeat', $value );
		}

		/**
		 * Set BOGO gift repeat mode.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_bogo_gift_repeat_mode( $value ) {
			$this->set_meta_prop( 'fgf_bogo_gift_repeat_mode', $value );
		}

		/**
		 * Set BOGO gift repeat limit.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_bogo_gift_repeat_limit( $value ) {
			$this->set_meta_prop( 'fgf_bogo_gift_repeat_limit', $value );
		}

		/**
		 * Set apply coupon.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_apply_coupon( $value ) {
			$this->set_meta_prop( 'fgf_apply_coupon', $value );
		}

		/**
		 * Set coupon gift type.
		 *
		 * @since 13.7.0
		 * @param string $value
		 */
		public function set_coupon_gift_type( $value ) {
			$this->set_meta_prop( 'fgf_coupon_gift_type', $value );
		}

		/**
		 * Set coupon gift products.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_coupon_gift_products( $value ) {
			$this->set_meta_prop( 'fgf_coupon_gift_products', $value );
		}

		/**
		 * Set coupon gift categories.
		 *
		 * @since 13.7.0
		 * @param array $value
		 */
		public function set_coupon_gift_categories( $value ) {
			$this->set_meta_prop( 'fgf_coupon_gift_categories', $value );
		}

		/**
		 * Set coupon gift products quantity.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_coupon_gift_products_qty( $value ) {
			$this->set_meta_prop( 'fgf_coupon_gift_products_qty', $value );
		}

		/**
		 * Set subtotal price type.
		 *
		 * @since 11.5.0
		 * @param int $value
		 */
		public function set_subtotal_price_type( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_price_type', $value );
		}

		/**
		 * Set total categories.
		 *
		 * @since 11.5.0
		 * @param array $value
		 */
		public function set_total_categories( $value ) {
			$this->set_meta_prop( 'fgf_total_categories', $value );
		}

		/**
		 * Set consider subcategories total.
		 *
		 * @since 11.5.0
		 * @param int $value
		 */
		public function set_consider_subcategories_total( $value ) {
			$this->set_meta_prop( 'fgf_consider_subcategories_total', $value );
		}

		/**
		 * Set calculate total discounted category total.
		 *
		 * @since 11.5.0
		 * @param int $value
		 */
		public function set_calculate_total_discounted_category_total( $value ) {
			$this->set_meta_prop( 'fgf_calculate_total_discounted_category_total', $value );
		}

		/**
		 * Set subtotal price.
		 *
		 * @since 11.1.0
		 * @param float $value
		 */
		public function set_subtotal_price( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_price', $value );
		}

		/**
		 * Set subtotal gift type.
		 *
		 * @since 11.1.0
		 * @param string $value
		 */
		public function set_subtotal_gift_type( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_gift_type', $value );
		}

		/**
		 * Set subtotal gift products.
		 *
		 * @since 11.1.0
		 * @param array $value
		 */
		public function set_subtotal_gift_products( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_gift_products', $value );
		}

		/**
		 * Set subtotal gift categories.
		 *
		 * @since 11.1.0
		 * @param array $value
		 */
		public function set_subtotal_gift_categories( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_gift_categories', $value );
		}

		/**
		 * Set total gift products quantity type.
		 *
		 * @since 12.5.0
		 * @param int $value
		 */
		public function set_total_gift_products_qty_type( $value ) {
			$this->set_meta_prop( 'fgf_total_gift_products_qty_type', $value );
		}

		/**
		 * Set subtotal gift products quantity.
		 *
		 * @since 11.1.0
		 * @param int $value
		 */
		public function set_subtotal_gift_products_qty( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_gift_products_qty', $value );
		}

		/**
		 * Set subtotal repeat gift.
		 *
		 * @since 11.1.0
		 * @param string $value
		 */
		public function set_subtotal_repeat_gift( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_repeat_gift', $value );
		}

		/**
		 * Set subtotal repeat gift mode.
		 *
		 * @since 11.1.0
		 * @param string $value
		 */
		public function set_subtotal_repeat_gift_mode( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_repeat_gift_mode', $value );
		}

		/**
		 * Set subtotal repeat gift limit.
		 *
		 * @since 11.1.0
		 * @param int $value
		 */
		public function set_subtotal_repeat_gift_limit( $value ) {
			$this->set_meta_prop( 'fgf_subtotal_repeat_gift_limit', $value );
		}

		/**
		 * Set bulk quantity rules consider type.
		 *
		 * @since 12.0.0
		 * @param string $value
		 */
		public function set_bulk_quantity_rules_consider_type( $value ) {
			$this->set_meta_prop( 'fgf_bulk_quantity_rules_consider_type', $value );
		}

		/**
		 * Set bulk quantity rules.
		 *
		 * @since 12.0.0
		 * @param array $value
		 */
		public function set_bulk_quantity_rules( $value ) {
			$this->set_meta_prop( 'fgf_bulk_quantity_rules', $value );
		}

		/**
		 * Set bulk pricing total type.
		 *
		 * @since 12.0.0
		 * @param string $value
		 */
		public function set_bulk_pricing_total_type( $value ) {
			$this->set_meta_prop( 'fgf_bulk_pricing_total_type', $value );
		}

		/**
		 * Set bulk pricing categories.
		 *
		 * @since 12.0.0
		 * @param array $value
		 */
		public function set_bulk_pricing_categories( $value ) {
			$this->set_meta_prop( 'fgf_bulk_pricing_categories', $value );
		}

		/**
		 * Set consider bulk pricing subcategories total.
		 *
		 * @since 12.0.0
		 * @param string $value
		 */
		public function set_consider_bulk_pricing_subcategories_total( $value ) {
			$this->set_meta_prop( 'fgf_consider_bulk_pricing_subcategories_total', $value );
		}

		/**
		 * Set calculate bulk pricing discounted category total.
		 *
		 * @since 12.0.0
		 * @param string $value
		 */
		public function set_calculate_bulk_pricing_discounted_category_total( $value ) {
			$this->set_meta_prop( 'fgf_calculate_bulk_pricing_discounted_category_total', $value );
		}

		/**
		 * Set bulk pricing rules consider type.
		 *
		 * @since 12.0.0
		 * @param string $value
		 */
		public function set_bulk_pricing_rules_consider_type( $value ) {
			$this->set_meta_prop( 'fgf_bulk_pricing_rules_consider_type', $value );
		}

		/**
		 * Set bulk pricing rules.
		 *
		 * @since 12.0.0
		 * @param array $value
		 */
		public function set_bulk_pricing_rules( $value ) {
			$this->set_meta_prop( 'fgf_bulk_pricing_rules', $value );
		}

		/**
		 * Set cheapest gift price type.
		 *
		 * @since 12.0.0
		 * @param int $value
		 */
		public function set_cheapest_gift_price_type( $value ) {
			$this->set_meta_prop( 'fgf_cheapest_gift_price_type', $value );
		}

		/**
		 * Set cheapest gift quantity.
		 *
		 * @since 12.0.0
		 * @param int $value
		 */
		public function set_cheapest_gift_quantity( $value ) {
			$this->set_meta_prop( 'fgf_cheapest_gift_quantity', $value );
		}

		/**
		 * Set free shipping methods.
		 *
		 * @since 12.2.0
		 * @param array $value
		 */
		public function set_free_shipping_methods( $value ) {
			$this->set_meta_prop( 'fgf_free_shipping_methods', $value );
		}

		/**
		 * Set rule valid from date.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_rule_valid_from_date( $value ) {
			$this->set_meta_prop( 'fgf_rule_valid_from_date', $value );
		}

		/**
		 * Set rule valid to date.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_rule_valid_to_date( $value ) {
			$this->set_meta_prop( 'fgf_rule_valid_to_date', $value );
		}

		/**
		 * Set rule week days validation.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_rule_week_days_validation( $value ) {
			$this->set_meta_prop( 'fgf_rule_week_days_validation', $value );
		}

		/**
		 * Set automatic product qty.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_automatic_product_qty( $value ) {
			$this->set_meta_prop( 'fgf_automatic_product_qty', $value );
		}

		/**
		 * Set rule gifts count per order.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_rule_gifts_count_per_order( $value ) {
			$this->set_meta_prop( 'fgf_rule_gifts_count_per_order', $value );
		}

		/**
		 * Set rule restriction count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_rule_restriction_count( $value ) {
			$this->set_meta_prop( 'fgf_rule_restriction_count', $value );
		}

		/**
		 * Set rule usage count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_rule_usage_count( $value ) {
			$this->set_meta_prop( 'fgf_rule_usage_count', $value );
		}

		/**
		 * Set rule allowed user type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_rule_allowed_user_type( $value ) {
			$this->set_meta_prop( 'fgf_rule_allowed_user_type', $value );
		}

		/**
		 * Set rule allowed user count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_rule_allowed_user_count( $value ) {
			$this->set_meta_prop( 'fgf_rule_allowed_user_count', $value );
		}

		/**
		 * Set rule allowed user usage count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_rule_allowed_user_usage_count( $value ) {
			$this->set_meta_prop( 'fgf_rule_allowed_user_usage_count', $value );
		}

		/**
		 * Set rule user purchased order count type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_rule_user_purchased_order_count_type( $value ) {
			$this->set_meta_prop( 'fgf_rule_user_purchased_order_count_type', $value );
		}

		/**
		 * Set rule user purchased order minimum count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_rule_user_purchased_order_min_count( $value ) {
			$this->set_meta_prop( 'fgf_rule_user_purchased_order_min_count', $value );
		}

		/**
		 * Set rule user purchased order maximum count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_rule_user_purchased_order_max_count( $value ) {
			$this->set_meta_prop( 'fgf_rule_user_purchased_order_max_count', $value );
		}

		/**
		 * Set exclude subtotal discount amount.
		 *
		 * @since 9.6.0
		 * @param int $value
		 */
		public function set_exclude_category_subtotal_discount_amount( $value ) {
			$this->set_meta_prop( 'fgf_exclude_category_subtotal_discount_amount', $value );
		}

		/**
		 * Set rule restrict by WooCommerce coupon type.
		 *
		 * @since 10.7.0
		 * @param string $value
		 */
		public function set_rule_restrict_by_wocommerce_coupon_type( $value ) {
			$this->set_meta_prop( 'fgf_rule_restrict_by_wocommerce_coupon_type', $value );
		}

		/**
		 * Set rule restrict by WooCommerce coupon.
		 *
		 * @since 10.7.0
		 * @param string $value
		 */
		public function set_rule_restrict_by_wocommerce_coupon( $value ) {
			$this->set_meta_prop( 'fgf_rule_restrict_by_wocommerce_coupon', $value );
		}

		/**
		 * Set condition type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_condition_type( $value ) {
			$this->set_meta_prop( 'fgf_condition_type', $value );
		}

		/**
		 * Set total type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_total_type( $value ) {
			$this->set_meta_prop( 'fgf_total_type', $value );
		}

		/**
		 * Set cart categories.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_cart_categories( $value ) {
			$this->set_meta_prop( 'fgf_cart_categories', $value );
		}

		/**
		 * Set consider cart subcategories total.
		 *
		 * @since 1.0.0
		 * @param float $value
		 */
		public function set_consider_cart_subcategories_total( $value ) {
			$this->set_meta_prop( 'fgf_consider_cart_subcategories_total', $value );
		}

		/**
		 * Set cart subtotal minimum value.
		 *
		 * @since 1.0.0
		 * @param float $value
		 */
		public function set_cart_subtotal_minimum_value( $value ) {
			$this->set_meta_prop( 'fgf_cart_subtotal_min_value', $value );
		}

		/**
		 * Set cart subtotal maximum value.
		 *
		 * @since 1.0.0
		 * @param float $value
		 */
		public function set_cart_subtotal_maximum_value( $value ) {
			$this->set_meta_prop( 'fgf_cart_subtotal_max_value', $value );
		}

		/**
		 * Set quantity minimum value.
		 *
		 * @since 1.0.0
		 * @param float $value
		 */
		public function set_quantity_minimum_value( $value ) {
			$this->set_meta_prop( 'fgf_quantity_min_value', $value );
		}

		/**
		 * Set quantity maximum value.
		 *
		 * @since 1.0.0
		 * @param float $value
		 */
		public function set_quantity_maximum_value( $value ) {
			$this->set_meta_prop( 'fgf_quantity_min_value', $value );
		}

		/**
		 * Set product count minimum value.
		 *
		 * @since 1.0.0
		 * @param float $value
		 */
		public function set_product_count_min_value( $value ) {
			$this->set_meta_prop( 'fgf_product_count_min_value', $value );
		}

		/**
		 * Set product count maximum value.
		 *
		 * @since 1.0.0
		 * @param float $value
		 */
		public function set_product_count_max_value( $value ) {
			$this->set_meta_prop( 'fgf_product_count_max_value', $value );
		}

		/**
		 * Set show notice.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_show_notice( $value ) {
			$this->set_meta_prop( 'fgf_show_notice', $value );
		}

		/**
		 * Set notice.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_notice( $value ) {
			$this->set_meta_prop( 'fgf_notice', $value );
		}

		/**
		 * Set notice image ID.
		 *
		 * @since 10.4.0
		 * @param string/int $value
		 */
		public function set_notice_image_id( $value ) {
			$this->set_meta_prop( 'fgf_notice_image_id', $value );
		}

		/**
		 * Set show notice progress bar.
		 *
		 * @since 13.8.0
		 * @param string $value
		 */
		public function set_show_notice_progress_bar( $value ) {
			$this->set_meta_prop( 'fgf_show_notice_progress_bar', $value );
		}

		/**
		 * Set show bogo eligible notice.
		 *
		 * @since 11.9.0
		 * @param string $value
		 */
		public function set_show_bogo_eligible_notice( $value ) {
			$this->set_meta_prop( 'fgf_show_bogo_eligible_notice', $value );
		}

		/**
		 * Set bogo eligible notice.
		 *
		 * @since 11.9.0
		 * @param string $value
		 */
		public function set_bogo_eligible_notice( $value ) {
			$this->set_meta_prop( 'fgf_bogo_eligible_notice', $value );
		}

		/**
		 * Set show bulk eligible notice.
		 *
		 * @since 12.0.0
		 * @param string $value
		 */
		public function set_show_bulk_eligible_notice( $value ) {
			$this->set_meta_prop( 'fgf_show_bulk_eligible_notice', $value );
		}

		/**
		 * Set bulk eligible notice.
		 *
		 * @since 12.0.0
		 * @param string $value
		 */
		public function set_bulk_eligible_notice( $value ) {
			$this->set_meta_prop( 'fgf_bulk_eligible_notice', $value );
		}

		/**
		 * Set bulk notice image ID.
		 *
		 * @since 12.0.0
		 * @param string/int $value
		 */
		public function set_bulk_notice_image_id( $value ) {
			$this->set_meta_prop( 'fgf_bulk_notice_image_id', $value );
		}

		/**
		 * Set show bulk notice progress bar.
		 *
		 * @since 13.8.0
		 * @param string $value
		 */
		public function set_show_bulk_notice_progress_bar( $value ) {
			$this->set_meta_prop( 'fgf_show_bulk_notice_progress_bar', $value );
		}

		/**
		 * Set user filter type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_user_filter_type( $value ) {
			$this->set_meta_prop( 'fgf_user_filter_type', $value );
		}

		/**
		 * Set include users.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_include_users( $value ) {
			$this->set_meta_prop( 'fgf_include_users', $value );
		}

		/**
		 * Set exclude users.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_exclude_users( $value ) {
			$this->set_meta_prop( 'fgf_exclude_users', $value );
		}

		/**
		 * Set include user roles
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_include_user_roles( $value ) {
			$this->set_meta_prop( 'fgf_include_user_roles', $value );
		}

		/**
		 * Set exclude user roles.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_exclude_user_roles( $value ) {
			$this->set_meta_prop( 'fgf_exclude_user_roles', $value );
		}

		/**
		 * Set product filter type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_product_filter_type( $value ) {
			$this->set_meta_prop( 'fgf_product_filter_type', $value );
		}

		/**
		 * Set include products.
		 */
		public function set_include_products( $value ) {
			$this->set_meta_prop( 'fgf_include_products', $value );
		}

		/**
		 * Set exclude products.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_exclude_products( $value ) {
			$this->set_meta_prop( 'fgf_exclude_products', $value );
		}

		/**
		 * Set applicable products type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_applicable_products_type( $value ) {
			$this->set_meta_prop( 'fgf_applicable_products_type', $value );
		}

		/**
		 * Set include product count.
		 */
		public function set_include_product_count( $value ) {
			$this->set_meta_prop( 'fgf_include_product_count', $value );
		}

		/**
		 * Set applicable categories type.
		 *
		 * @since 1.0.0
		 * @param string $value
		 */
		public function set_applicable_categories_type( $value ) {
			$this->set_meta_prop( 'fgf_applicable_categories_type', $value );
		}

		/**
		 * Set include categories.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_include_categories( $value ) {
			$this->set_meta_prop( 'fgf_include_categories', $value );
		}

		/**
		 * Set include categories product count.
		 *
		 * @since 1.0.0
		 * @param int $value
		 */
		public function set_include_category_product_count( $value ) {
			$this->set_meta_prop( 'fgf_include_category_product_count', $value );
		}

		/**
		 * Set exclude categories.
		 *
		 * @since 1.0.0
		 * @param array $value
		 */
		public function set_exclude_categories( $value ) {
			$this->set_meta_prop( 'fgf_exclude_categories', $value );
		}

		/**
		 * Set virtual product restriction.
		 *
		 * @since 11.3.0
		 * @param string $value
		 */
		public function set_virtual_product_restriction( $value ) {
			$this->set_meta_prop( 'fgf_virtual_product_restriction', $value );
		}

		/**
		 * Set filter coupon type.
		 *
		 * @since 13.0.0
		 * @param string $value
		 */
		public function set_filter_coupon_type( $value ) {
			$this->set_meta_prop( 'fgf_filter_coupon_type', $value );
		}

		/**
		 * Set filter coupon applicable type.
		 *
		 * @since 13.0.0
		 * @param string $value
		 */
		public function set_filter_coupon_applicable_type( $value ) {
			$this->set_meta_prop( 'fgf_filter_coupon_applicable_type', $value );
		}

		/**
		 * Set filter coupon count.
		 *
		 * @since 13.0.0
		 * @param string $value
		 */
		public function set_filter_coupon_count( $value ) {
			$this->set_meta_prop( 'fgf_filter_coupon_count', $value );
		}

		/**
		 * Set filter include coupons.
		 *
		 * @since 13.0.0
		 * @param array $value
		 */
		public function set_filter_include_coupons( $value ) {
			$this->set_meta_prop( 'fgf_filter_include_coupons', $value );
		}

		/**
		 * Set filter exclude coupons.
		 *
		 * @since 13.0.0
		 * @param array $value
		 */
		public function set_filter_exclude_coupons( $value ) {
			$this->set_meta_prop( 'fgf_filter_exclude_coupons', $value );
		}

		/**
		 * Get the description.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_description() {
			return $this->get_post_prop( 'description' );
		}

		/**
		 * Get the rule type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_rule_type() {
			return $this->get_meta_prop( 'fgf_rule_type' );
		}

		/**
		 * Get the rule consider type.
		 *
		 * @since 10.3.0
		 * @retrun string
		 */
		public function get_rule_consider_type() {
			return $this->get_meta_prop( 'fgf_rule_consider_type' );
		}

		/**
		 * Get the gift award type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_gift_reward_type() {
			return $this->get_meta_prop( 'fgf_gift_reward_type' );
		}

		/**
		 * Get the gift discount type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_gift_discount_type() {
			return $this->get_meta_prop( 'fgf_gift_discount_type' );
		}

		/**
		 * Get the gift discount value.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_gift_discount_value() {
			return $this->get_meta_prop( 'fgf_gift_discount_value' );
		}

		/**
		 * Get the gift type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_gift_type() {
			return $this->get_meta_prop( 'fgf_gift_type' );
		}

		/**
		 * Get the gift products.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_gift_products() {
			return $this->get_meta_prop( 'fgf_gift_products' );
		}

		/**
		 * Get the gift categories.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_gift_categories() {
			return $this->get_meta_prop( 'fgf_gift_categories' );
		}

		/**
		 * Get the automatic gift selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_automatic_gift_selection() {
			return $this->get_meta_prop( 'fgf_automatic_gift_selection' );
		}

		/**
		 * Get the automatic gift price consideration type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_automatic_gift_price_consider_type() {
			return $this->get_meta_prop( 'fgf_automatic_gift_price_consider_type' );
		}

		/**
		 * Get the automatic gift selection count.
		 *
		 * @since 13.7.0
		 * @retrun int
		 */
		public function get_automatic_gift_count() {
			return absint( $this->get_meta_prop( 'fgf_automatic_gift_count' ) );
		}

		/**
		 * Get the automatic gift variation selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_automatic_variation_selection() {
			return $this->get_meta_prop( 'fgf_automatic_variation_selection' );
		}

		/**
		 * Get the BOGO gift type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_bogo_gift_type() {
			return $this->get_meta_prop( 'fgf_bogo_gift_type' );
		}

		/**
		 * Get the buy product type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_buy_product_type() {
			return $this->get_meta_prop( 'fgf_buy_product_type' );
		}

		/**
		 * Get the buy product.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_buy_product() {
			return $this->get_meta_prop( 'fgf_buy_product' );
		}

		/**
		 * Get the buy categories.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_buy_categories() {
			return $this->get_meta_prop( 'fgf_buy_categories' );
		}

		/**
		 * Get the buy product consider type.
		 *
		 * @since 11.1.0
		 * @retrun string
		 */
		public function get_buy_product_consider_type() {
			return $this->get_meta_prop( 'fgf_buy_product_consider_type' );
		}

		/**
		 * Get the buy category consider type.
		 *
		 * @since 11.1.0
		 * @retrun string
		 */
		public function get_buy_category_consider_type() {
			return $this->get_meta_prop( 'fgf_buy_category_consider_type' );
		}

		/**
		 * Get the buy category type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_buy_category_type() {
			return $this->get_meta_prop( 'fgf_buy_category_type' );
		}

		/**
		 * Get the buy product quantity consider type.
		 *
		 * @since 11.1.0
		 * @retrun string
		 */
		public function get_buy_product_quantity_consider_type() {
			return $this->get_meta_prop( 'fgf_buy_product_quantity_consider_type' );
		}

		/**
		 * Get the product type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_product_type() {
			return $this->get_meta_prop( 'fgf_get_product_type' );
		}

		/**
		 * Get the products.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_products() {
			return $this->get_meta_prop( 'fgf_get_products' );
		}

		/**
		 * Get the categories.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_categories() {
			return $this->get_meta_prop( 'fgf_get_categories' );
		}

		/**
		 * Get the BOGO automatic gift selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_bogo_automatic_gift_selection() {
			return $this->get_meta_prop( 'fgf_bogo_automatic_gift_selection' );
		}

		/**
		 * Get the BOGO automatic gift price consideration type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_bogo_automatic_gift_price_consider_type() {
			return $this->get_meta_prop( 'fgf_bogo_automatic_gift_price_consider_type' );
		}

		/**
		 * Get the BOGO automatic gift selection count.
		 *
		 * @since 13.7.0
		 * @retrun int
		 */
		public function get_bogo_automatic_gift_count() {
			return absint( $this->get_meta_prop( 'fgf_bogo_automatic_gift_count' ) );
		}

		/**
		 * Get the BOGO automatic gift variation selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_bogo_automatic_variation_selection() {
			return $this->get_meta_prop( 'fgf_bogo_automatic_variation_selection' );
		}

		/**
		 * Get the buy quantity type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_buy_quantity_type() {
			return $this->get_meta_prop( 'fgf_buy_quantity_type' );
		}

		/**
		 * Get the BOGO get gift type.
		 *
		 * @since 11.3.0
		 * @retrun string
		 */
		public function get_bogo_get_gift_type() {
			return $this->get_meta_prop( 'fgf_bogo_get_gift_type' );
		}

		/**
		 * Get the buy product count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_buy_product_count() {
			return $this->get_meta_prop( 'fgf_buy_product_count' );
		}

		/**
		 * Get the product count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_product_count() {
			return $this->get_meta_prop( 'fgf_get_product_count' );
		}

		/**
		 * Get the BOGO gift repeat.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_bogo_gift_repeat() {
			return $this->get_meta_prop( 'fgf_bogo_gift_repeat' );
		}

		/**
		 * Get the BOGO gift repeat mode.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_bogo_gift_repeat_mode() {
			return $this->get_meta_prop( 'fgf_bogo_gift_repeat_mode' );
		}

		/**
		 * Get the BOGO gift repeat limit.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_bogo_gift_repeat_limit() {
			return $this->get_meta_prop( 'fgf_bogo_gift_repeat_limit' );
		}

		/**
		 * Get the apply coupon.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_apply_coupon() {
			return $this->get_meta_prop( 'fgf_apply_coupon' );
		}

		/**
		 * Get the coupon gift type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_coupon_gift_type() {
			return $this->get_meta_prop( 'fgf_coupon_gift_type' );
		}

		/**
		 * Get the coupon gift products.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_coupon_gift_products() {
			return $this->get_meta_prop( 'fgf_coupon_gift_products' );
		}

		/**
		 * Get the coupon gift categories.
		 *
		 * @since 13.7.0
		 * @retrun array
		 */
		public function get_coupon_gift_categories() {
			return $this->get_meta_prop( 'fgf_coupon_gift_categories' );
		}

		/**
		 * Get the coupon automatic gift selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_coupon_automatic_gift_selection() {
			return $this->get_meta_prop( 'fgf_coupon_automatic_gift_selection' );
		}

		/**
		 * Get the coupon automatic gift price consideration type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_coupon_automatic_gift_price_consider_type() {
			return $this->get_meta_prop( 'fgf_coupon_automatic_gift_price_consider_type' );
		}

		/**
		 * Get the coupon automatic gift selection count.
		 *
		 * @since 13.7.0
		 * @retrun int
		 */
		public function get_coupon_automatic_gift_count() {
			return absint( $this->get_meta_prop( 'fgf_coupon_automatic_gift_count' ) );
		}

		/**
		 * Get the coupon automatic gift variation selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_coupon_automatic_variation_selection() {
			return $this->get_meta_prop( 'fgf_coupon_automatic_variation_selection' );
		}

		/**
		 * Get the coupon gift products quantity.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_coupon_gift_products_qty() {
			return $this->get_meta_prop( 'fgf_coupon_gift_products_qty' );
		}

		/**
		 * Get the subtotal price type.
		 *
		 * @since 11.5.0
		 * @retrun int
		 */
		public function get_subtotal_price_type() {
			return $this->get_meta_prop( 'fgf_subtotal_price_type' );
		}

		/**
		 * Get the total categories.
		 *
		 * @since 11.5.0
		 * @retrun array
		 */
		public function get_total_categories() {
			return $this->get_meta_prop( 'fgf_total_categories' );
		}

		/**
		 * Get the consider subcategories total.
		 *
		 * @since 11.5.0
		 * @retrun int
		 */
		public function get_consider_subcategories_total() {
			return $this->get_meta_prop( 'fgf_consider_subcategories_total' );
		}

		/**
		 * Get the calculate total discounted category total.
		 *
		 * @since 11.5.0
		 * @retrun int
		 */
		public function get_calculate_total_discounted_category_total() {
			return $this->get_meta_prop( 'fgf_calculate_total_discounted_category_total' );
		}

		/**
		 * Get the subtotal price.
		 *
		 * @since 11.1.0
		 * @retrun float
		 */
		public function get_subtotal_price() {
			return $this->get_meta_prop( 'fgf_subtotal_price' );
		}

		/**
		 * Get the subtotal gift type.
		 *
		 * @since 11.1.0
		 * @retrun string
		 */
		public function get_subtotal_gift_type() {
			return $this->get_meta_prop( 'fgf_subtotal_gift_type' );
		}

		/**
		 * Get the subtotal gift products.
		 *
		 * @since 11.1.0
		 * @retrun array
		 */
		public function get_subtotal_gift_products() {
			return $this->get_meta_prop( 'fgf_subtotal_gift_products' );
		}

		/**
		 * Get the subtotal gift categories.
		 *
		 * @since 11.1.0
		 * @retrun array
		 */
		public function get_subtotal_gift_categories() {
			return $this->get_meta_prop( 'fgf_subtotal_gift_categories' );
		}

		/**
		 * Get the total automatic gift selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_subtotal_automatic_gift_selection() {
			return $this->get_meta_prop( 'fgf_subtotal_automatic_gift_selection' );
		}

		/**
		 * Get the total automatic gift price consideration type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_subtotal_automatic_gift_price_consider_type() {
			return $this->get_meta_prop( 'fgf_subtotal_automatic_gift_price_consider_type' );
		}

		/**
		 * Get the total automatic gift selection count.
		 *
		 * @since 13.7.0
		 * @retrun int
		 */
		public function get_subtotal_automatic_gift_count() {
			return absint( $this->get_meta_prop( 'fgf_subtotal_automatic_gift_count' ) );
		}

		/**
		 * Get the total automatic gift variation selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_subtotal_automatic_variation_selection() {
			return $this->get_meta_prop( 'fgf_subtotal_automatic_variation_selection' );
		}

		/**
		 * Get the total gift products qty type.
		 *
		 * @since 12.5.0
		 * @retrun int
		 */
		public function get_total_gift_products_qty_type() {
			return $this->get_meta_prop( 'fgf_total_gift_products_qty_type' );
		}

		/**
		 * Get the subtotal gift products qty.
		 *
		 * @since 11.1.0
		 * @retrun int
		 */
		public function get_subtotal_gift_products_qty() {
			return $this->get_meta_prop( 'fgf_subtotal_gift_products_qty' );
		}

		/**
		 * Get the subtotal repeat gift.
		 *
		 * @since 11.1.0
		 * @retrun string
		 */
		public function get_subtotal_repeat_gift() {
			return $this->get_meta_prop( 'fgf_subtotal_repeat_gift' );
		}

		/**
		 * Get the subtotal repeat gift mode.
		 *
		 * @since 11.1.0
		 * @retrun string
		 */
		public function get_subtotal_repeat_gift_mode() {
			return $this->get_meta_prop( 'fgf_subtotal_repeat_gift_mode' );
		}

		/**
		 * Get the subtotal repeat gift limit.
		 *
		 * @since 11.1.0
		 * @retrun int
		 */
		public function get_subtotal_repeat_gift_limit() {
			return $this->get_meta_prop( 'fgf_subtotal_repeat_gift_limit' );
		}

		/**
		 * Get the bulk quantity rules consider type.
		 *
		 * @since 12.0.0
		 * @retrun string
		 */
		public function get_bulk_quantity_rules_consider_type() {
			return $this->get_meta_prop( 'fgf_bulk_quantity_rules_consider_type' );
		}

		/**
		 * Get the bulk quantity rules.
		 *
		 * @since 12.0.0
		 * @retrun array
		 */
		public function get_bulk_quantity_rules() {
			return $this->get_meta_prop( 'fgf_bulk_quantity_rules' );
		}

		/**
		 * Get the bulk quantity automatic gift selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_bulk_quantity_automatic_gift_selection() {
			return $this->get_meta_prop( 'fgf_bulk_quantity_automatic_gift_selection' );
		}

		/**
		 * Get the bulk quantity automatic gift price consideration type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_bulk_quantity_automatic_gift_price_consider_type() {
			return $this->get_meta_prop( 'fgf_bulk_quantity_automatic_gift_price_consider_type' );
		}

		/**
		 * Get the bulk quantity automatic gift selection count.
		 *
		 * @since 13.7.0
		 * @retrun int
		 */
		public function get_bulk_quantity_automatic_gift_count() {
			return absint( $this->get_meta_prop( 'fgf_bulk_quantity_automatic_gift_count' ) );
		}

		/**
		 * Get the bulk quantity automatic gift variation selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_bulk_quantity_automatic_variation_selection() {
			return $this->get_meta_prop( 'fgf_bulk_quantity_automatic_variation_selection' );
		}

		/**
		 * Get the bulk pricing total type.
		 *
		 * @since 12.0.0
		 * @retrun string
		 */
		public function get_bulk_pricing_total_type() {
			return $this->get_meta_prop( 'fgf_bulk_pricing_total_type' );
		}

		/**
		 * Get the bulk pricing categories.
		 *
		 * @since 12.0.0
		 * @retrun array
		 */
		public function get_bulk_pricing_categories() {
			return $this->get_meta_prop( 'fgf_bulk_pricing_categories' );
		}

		/**
		 * Get the consider bulk pricing subcategories total.
		 *
		 * @since 12.0.0
		 * @retrun string
		 */
		public function get_consider_bulk_pricing_subcategories_total() {
			return $this->get_meta_prop( 'fgf_consider_bulk_pricing_subcategories_total' );
		}

		/**
		 * Get the calculate bulk pricing discounted category total.
		 *
		 * @since 12.0.0
		 * @return int
		 */
		public function get_calculate_bulk_pricing_discounted_category_total() {
			return $this->get_meta_prop( 'fgf_calculate_bulk_pricing_discounted_category_total' );
		}

		/**
		 * Get the bulk pricing rules consider type.
		 *
		 * @since 12.0.0
		 * @retrun string
		 */
		public function get_bulk_pricing_rules_consider_type() {
			return $this->get_meta_prop( 'fgf_bulk_pricing_rules_consider_type' );
		}

		/**
		 * Get the bulk pricing rules.
		 *
		 * @since 12.0.0
		 * @retrun array
		 */
		public function get_bulk_pricing_rules() {
			return $this->get_meta_prop( 'fgf_bulk_pricing_rules' );
		}

		/**
		 * Get the bulk pricing automatic gift selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_bulk_pricing_automatic_gift_selection() {
			return $this->get_meta_prop( 'fgf_bulk_pricing_automatic_gift_selection' );
		}

		/**
		 * Get the bulk pricing automatic gift price consideration type.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_bulk_pricing_automatic_gift_price_consider_type() {
			return $this->get_meta_prop( 'fgf_bulk_pricing_automatic_gift_price_consider_type' );
		}

		/**
		 * Get the bulk pricing automatic gift selection count.
		 *
		 * @since 13.7.0
		 * @retrun int
		 */
		public function get_bulk_pricing_automatic_gift_count() {
			return absint( $this->get_meta_prop( 'fgf_bulk_pricing_automatic_gift_count' ) );
		}

		/**
		 * Get the bulk pricing automatic gift variation selection type.
		 *
		 * @since 13.7.0
		 * @retrun string
		 */
		public function get_bulk_pricing_automatic_variation_selection() {
			return $this->get_meta_prop( 'fgf_bulk_pricing_automatic_variation_selection' );
		}

		/**
		 * Get the cheapest gift price type.
		 *
		 * @since 12.0.0
		 * @retrun int
		 */
		public function get_cheapest_gift_price_type() {
			return $this->get_meta_prop( 'fgf_cheapest_gift_price_type' );
		}

		/**
		 * Get the cheapest gift quantity.
		 *
		 * @since 12.0.0
		 * @retrun int
		 */
		public function get_cheapest_gift_quantity() {
			return $this->get_meta_prop( 'fgf_cheapest_gift_quantity' );
		}

		/**
		 * Get the free shipping methods.
		 *
		 * @since 12.2.0
		 * @retrun array
		 */
		public function get_free_shipping_methods() {
			return $this->get_meta_prop( 'fgf_free_shipping_methods' );
		}

		/**
		 * Get the rule valid from date.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_rule_valid_from_date() {
			return $this->get_meta_prop( 'fgf_rule_valid_from_date' );
		}

		/**
		 * Get the rule valid to date.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_rule_valid_to_date() {
			return $this->get_meta_prop( 'fgf_rule_valid_to_date' );
		}

		/**
		 * Get the rule week days validation.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_rule_week_days_validation() {
			return $this->get_meta_prop( 'fgf_rule_week_days_validation' );
		}

		/**
		 * Get the automatic product qty.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_automatic_product_qty() {
			return $this->get_meta_prop( 'fgf_automatic_product_qty' );
		}

		/**
		 * Get the rule gifts count per order.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_rule_gifts_count_per_order() {
			return $this->get_meta_prop( 'fgf_rule_gifts_count_per_order' );
		}

		/**
		 * Get the rule restriction count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_rule_restriction_count() {
			return $this->get_meta_prop( 'fgf_rule_restriction_count' );
		}

		/**
		 * Get the rule usage count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_rule_usage_count() {
			return $this->get_meta_prop( 'fgf_rule_usage_count' );
		}

		/**
		 * Get the rule allowed user type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_rule_allowed_user_type() {
			return $this->get_meta_prop( 'fgf_rule_allowed_user_type' );
		}

		/**
		 * Get the rule allowed user count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_rule_allowed_user_count() {
			return $this->get_meta_prop( 'fgf_rule_allowed_user_count' );
		}

		/**
		 * Get the rule allowed user usage count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_rule_allowed_user_usage_count() {
			return $this->get_meta_prop( 'fgf_rule_allowed_user_usage_count' );
		}

		/**
		 * Get the rule user purchased order count type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_rule_user_purchased_order_count_type() {
			return $this->get_meta_prop( 'fgf_rule_user_purchased_order_count_type' );
		}

		/**
		 * Get the rule user purchased order minimum count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_rule_user_purchased_order_min_count() {
			return $this->get_meta_prop( 'fgf_rule_user_purchased_order_min_count' );
		}

		/**
		 * Get the rule user purchased order maximum count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_rule_user_purchased_order_max_count() {
			return $this->get_meta_prop( 'fgf_rule_user_purchased_order_max_count' );
		}

		/**
		 * Get the exclude subtotal discount amount.
		 *
		 * @since 9.6.0
		 * @return int
		 */
		public function get_exclude_category_subtotal_discount_amount() {
			return $this->get_meta_prop( 'fgf_exclude_category_subtotal_discount_amount' );
		}

		/**
		 * Get the rule restrict by WooCommerce coupon type.
		 *
		 * @since 10.7.0
		 * @retrun string
		 */
		public function get_rule_restrict_by_wocommerce_coupon_type() {
			return $this->get_meta_prop( 'fgf_rule_restrict_by_wocommerce_coupon_type' );
		}

		/**
		 * Get the rule restrict by WooCommerce coupon.
		 *
		 * @since 10.7.0
		 * @retrun string
		 */
		public function get_rule_restrict_by_wocommerce_coupon() {
			return $this->get_meta_prop( 'fgf_rule_restrict_by_wocommerce_coupon' );
		}

		/**
		 * Get the condition type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_condition_type() {
			return $this->get_meta_prop( 'fgf_condition_type' );
		}

		/**
		 * Get the total type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 * */
		public function get_total_type() {
			return $this->get_meta_prop( 'fgf_total_type' );
		}

		/**
		 * Get the cart categories.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_cart_categories() {
			return $this->get_meta_prop( 'fgf_cart_categories' );
		}

		/**
		 * Get the consider cart subcategories total.
		 *
		 * @since 1.0.0
		 * @retrun boolean
		 */
		public function get_consider_cart_subcategories_total() {
			return '2' == $this->get_meta_prop( 'fgf_consider_cart_subcategories_total' );
		}

		/**
		 * Get the cart subtotal minimum value.
		 *
		 * @since 1.0.0
		 * @retrun float
		 */
		public function get_cart_subtotal_minimum_value() {
			return $this->get_meta_prop( 'fgf_cart_subtotal_min_value' );
		}

		/**
		 * Get the cart subtotal maximum value.
		 *
		 * @since 1.0.0
		 * @retrun float
		 */
		public function get_cart_subtotal_maximum_value() {
			return $this->get_meta_prop( 'fgf_cart_subtotal_max_value' );
		}

		/**
		 * Get the quantity minimum value.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_quantity_minimum_value() {
			return $this->get_meta_prop( 'fgf_quantity_min_value' );
		}

		/**
		 * Get the quantity maximum value.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_quantity_maximum_value() {
			return $this->get_meta_prop( 'fgf_quantity_max_value' );
		}

		/**
		 * Get the product count minimum value.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_product_count_min_value() {
			return $this->get_meta_prop( 'fgf_product_count_min_value' );
		}

		/**
		 * Get the product count maximum value.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_product_count_max_value() {
			return $this->get_meta_prop( 'fgf_product_count_max_value' );
		}

		/**
		 * Get the show notice.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_show_notice() {
			return $this->get_meta_prop( 'fgf_show_notice' );
		}

		/**
		 * Get the notice.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_notice() {
			return $this->get_meta_prop( 'fgf_notice' );
		}

		/**
		 * Get the notice image ID.
		 *
		 * @since 10.4.0
		 * @retrun string/int
		 */
		public function get_notice_image_id() {
			return $this->get_meta_prop( 'fgf_notice_image_id' );
		}

		/**
		 * Get the show notice progress bar.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_show_notice_progress_bar() {
			return $this->get_meta_prop( 'fgf_show_notice_progress_bar' );
		}

		/**
		 * Get the show bogo eligible notice.
		 *
		 * @since 11.9.0
		 * @retrun string
		 */
		public function get_show_bogo_eligible_notice() {
			return $this->get_meta_prop( 'fgf_show_bogo_eligible_notice' );
		}

			/**
			 * Get the bogo eligible notice.
			 *
			 * @since 11.9.0
			 * @retrun string
			 */
		public function get_bogo_eligible_notice() {
			return $this->get_meta_prop( 'fgf_bogo_eligible_notice' );
		}

		/**
		 * Get the show bulk eligible notice.
		 *
		 * @since 12.0.0
		 * @retrun string
		 */
		public function get_show_bulk_eligible_notice() {
			return $this->get_meta_prop( 'fgf_show_bulk_eligible_notice' );
		}

		/**
		 * Get the bulk eligible notice.
		 *
		 * @since 12.0.0
		 * @retrun string
		 */
		public function get_bulk_eligible_notice() {
			return $this->get_meta_prop( 'fgf_bulk_eligible_notice' );
		}

		/**
		 * Get the bulk notice image ID.
		 *
		 * @since 12.0.0
		 * @retrun string/int
		 */
		public function get_bulk_notice_image_id() {
			return $this->get_meta_prop( 'fgf_bulk_notice_image_id' );
		}

		/**
		 * Get the show bulk notice progress bar.
		 *
		 * @since 13.8.0
		 * @retrun string
		 */
		public function get_show_bulk_notice_progress_bar() {
			return $this->get_meta_prop( 'fgf_show_bulk_notice_progress_bar' );
		}

		/**
		 * Get the user filter type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_user_filter_type() {
			return $this->get_meta_prop( 'fgf_user_filter_type' );
		}

		/**
		 * Get the include users.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_include_users() {
			return $this->get_meta_prop( 'fgf_include_users' );
		}

		/**
		 * Get the exclude users.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_exclude_users() {
			return $this->get_meta_prop( 'fgf_exclude_users' );
		}

		/**
		 * Get the include user roles.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_include_user_roles() {
			return $this->get_meta_prop( 'fgf_include_user_roles' );
		}

		/**
		 * Get the exclude user roles.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_exclude_user_roles() {
			return $this->get_meta_prop( 'fgf_exclude_user_roles' );
		}

		/**
		 * Get the product filter type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_product_filter_type() {
			return $this->get_meta_prop( 'fgf_product_filter_type' );
		}

		/**
		 * Get the include products.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_include_products() {
			return $this->get_meta_prop( 'fgf_include_products' );
		}

		/**
		 * Get the products count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_include_product_count() {
			return $this->get_meta_prop( 'fgf_include_product_count' );
		}

		/**
		 * Get the exclude products.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_exclude_products() {
			return $this->get_meta_prop( 'fgf_exclude_products' );
		}

		/**
		 * Get the applicable products type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_applicable_products_type() {
			return $this->get_meta_prop( 'fgf_applicable_products_type' );
		}

		/**
		 * Get the applicable categories type.
		 *
		 * @since 1.0.0
		 * @retrun string
		 */
		public function get_applicable_categories_type() {
			return $this->get_meta_prop( 'fgf_applicable_categories_type' );
		}

		/**
		 * Get the include categories.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_include_categories() {
			return $this->get_meta_prop( 'fgf_include_categories' );
		}

		/**
		 * Get the include categories product count.
		 *
		 * @since 1.0.0
		 * @retrun int
		 */
		public function get_include_category_product_count() {
			return $this->get_meta_prop( 'fgf_include_category_product_count' );
		}

		/**
		 * Get the exclude categories.
		 *
		 * @since 1.0.0
		 * @retrun array
		 */
		public function get_exclude_categories() {
			return $this->get_meta_prop( 'fgf_exclude_categories' );
		}

		/**
		 * Get the virtual product restriction.
		 *
		 * @since 11.3.0
		 * @retrun string
		 */
		public function get_virtual_product_restriction() {
			return $this->get_meta_prop( 'fgf_virtual_product_restriction' );
		}

		/**
		 * Get the filter coupon type.
		 *
		 * @since 13.0.0
		 * @return array
		 */
		public function get_filter_coupon_type() {
			return $this->get_meta_prop( 'fgf_filter_coupon_type' );
		}

		/**
		 * Get the filter coupon applicable type.
		 *
		 * @since 13.0.0
		 * @return array
		 */
		public function get_filter_coupon_applicable_type() {
			return $this->get_meta_prop( 'fgf_filter_coupon_applicable_type' );
		}

		/**
		 * Get the filter coupon count.
		 *
		 * @since 13.0.0
		 * @return array
		 */
		public function get_filter_coupon_count() {
			return $this->get_meta_prop( 'fgf_filter_coupon_count' );
		}

		/**
		 * Get the filter include coupons.
		 *
		 * @since 13.0.0
		 * @return array
		 */
		public function get_filter_include_coupons() {
			return $this->get_meta_prop( 'fgf_filter_include_coupons' );
		}

		/**
		 * Get the filter exclude coupons.
		 *
		 * @since 13.0.0
		 * @return array
		 */
		public function get_filter_exclude_coupons() {
			return $this->get_meta_prop( 'fgf_filter_exclude_coupons' );
		}
	}

}
