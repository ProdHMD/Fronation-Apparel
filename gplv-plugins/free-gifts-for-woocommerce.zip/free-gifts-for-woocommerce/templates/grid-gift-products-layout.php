<?php
/**
 * This template displays gift products in the grid layout.
 *
 * This template can be overridden by copying it to yourtheme/free-gifts-for-woocommerce/grid-gift-products-layout.php
 *
 * To maintain compatibility, Free Gifts for WooCommerce will update the template files and you have to copy the updated files to your theme
 * 
 * @since 12.8.0 
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

?>
<div class='fgf_gift_products_wrapper fgf-grid-gift-products-wrapper' id='fgf_gift_products_wrapper'>
	<?php
	/**
	 * This hook is used to display the extra content before gift products content.
	 * 
	 * @since 12.8.0
	 */
	do_action('fgf_before_gift_products_content');
	?>
	<h3><?php echo esc_html(get_option('fgf_settings_free_gift_heading_label')); ?></h3>
	<div class='fgf-gift-products-content fgf-grid-gift-products-content'>
		<?php if ($notice) : ?>
			<p class='fgf-gifts-notice'><?php echo wp_kses_post($notice); ?></p>
		<?php endif; ?>

		<div class="<?php echo esc_attr(implode(' ', fgf_grid_gift_items_classes())); ?>">
			<?php fgf_get_template('grid-gift-products.php', array( 'gift_products' => $gift_products, 'permalink'=>$permalink )); ?>
		</div>

		<?php if ($pagination['page_count'] > 1) : ?>
			<div class='fgf-gift-products-grid-footer'>
					<?php fgf_get_template('pagination.php', $pagination); ?>
				</div>
		<?php endif; ?>
	</div>
	<?php
	/**
	 * This hook is used to display the extra content after gift products content.
	 * 
	 * @since 12.8.0
	 */
	do_action('fgf_after_gift_products_content');
	?>
	<input type='hidden' id='fgf_gift_products_type' value='<?php echo esc_attr($mode); ?>'>
	<input type='hidden' id='fgf_gift_products_popup_location' value='<?php echo esc_attr($popup_location); ?>'>
	<input type='hidden' id='fgf_gift_products_display_type' value='<?php echo esc_attr($display_type); ?>'>
</div>
<?php
