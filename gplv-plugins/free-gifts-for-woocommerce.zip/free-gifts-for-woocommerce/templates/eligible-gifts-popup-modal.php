<?php
/**
 * This template displays the eligible notice gifts popup modal (lightcase target).
 *
 * Rendered outside the notice (in the footer) as raw HTML, so the gift layout
 * markup - including dropdown form elements, pagination and hidden inputs - is not
 * stripped by the WooCommerce notice sanitizer.
 *
 * This template can be overridden by copying it to yourtheme/free-gifts-for-woocommerce/eligible-gifts-popup-modal.php
 *
 * To maintain compatibility, Free Gifts for WooCommerce will update the template files and you have to copy the updated files to your theme
 *
 * @since 13.5.0
 * @var string $modal_id  Unique modal element id.
 * @var string $label     Trigger link label (used as the dialog aria-label).
 * @var string $heading   Popup heading (also available in $data_args['heading']).
 * @var array  $data_args Gift display template args.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="fgf_hide fgf-eligible-gifts-modal-holder">
	<div id="<?php echo esc_attr( $modal_id ); ?>" class="fgf-popup-gift-products-wrapper fgf-eligible-gifts-modal woocommerce" role="dialog" aria-label="<?php echo esc_attr( $label ); ?>">
		<?php fgf_get_template( $data_args['template'], $data_args ); ?>
	</div>
</div>
<?php
