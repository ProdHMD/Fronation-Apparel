<?php
/**
 * This template displays the eligible notice gifts popup trigger link.
 *
 * This template can be overridden by copying it to yourtheme/free-gifts-for-woocommerce/eligible-gifts-popup-trigger.php
 *
 * To maintain compatibility, Free Gifts for WooCommerce will update the template files and you have to copy the updated files to your theme
 *
 * @since 13.5.0
 * @var string $modal_id Unique modal element id.
 * @var string $label    Trigger link label.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<a href="#<?php echo esc_attr( $modal_id ); ?>" class="fgf-gifts-popup-trigger fgf-eligible-gifts-popup-trigger" role="button"><?php echo esc_html( $label ); ?></a>
<?php
