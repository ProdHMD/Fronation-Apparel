<?php
/**
 * This template displays the notice content.
 *
 * This template can be overridden by copying it to yourtheme/free-gifts-for-woocommerce/notices/content.php
 *
 * To maintain compatibility, Free Gifts for WooCommerce will update the template files and you have to copy the updated files to your theme.
 *
 * @since 10.4.0
 * @var $icon_url contains the icon URL
 * @var $notice Notice
 * @var $progress contains the eligible notice progress data, when the rule shows a progress bar
 * @var $progress_placeholder contains the id of the progress bar the block cart/checkout injects here
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! $notice ) {
	return;
}
?>
<span class='fgf-notice-content-wrapper'>
	<?php if ( $icon_url ) : ?>
		<span class='fgf-notice-icon'>
			<img src='<?php echo esc_url( $icon_url ); ?>'/>
		</span>
	<?php endif; ?>

	<span class='fgf-notice-content'><?php echo wc_kses_notice( $notice ); ?></span>
</span>
<?php
if ( ! empty( $progress ) ) {
	fgf_get_template( 'notices/progress-bar.php', array( 'progress' => $progress ) );
}

/*
 * The block cart and the block checkout sanitize the notice HTML down to a
 * handful of tags, which strips the bar markup. There, the bar is delivered
 * alongside the notices through the Store API and the script puts it back in
 * place of this anchor, which the sanitizer keeps.
 */
if ( ! empty( $progress_placeholder ) ) :
	?>
	<a name='<?php echo esc_attr( $progress_placeholder ); ?>'></a>
	<?php
endif;
