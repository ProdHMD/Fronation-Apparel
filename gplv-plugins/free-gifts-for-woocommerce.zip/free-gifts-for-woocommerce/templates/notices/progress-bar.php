<?php
/**
 * This template displays the progress bar of an eligible notice.
 *
 * It is rendered inline inside the notice on the classic cart/checkout, and
 * outside of it on the block cart/checkout, where the notice HTML is sanitized
 * and the bar is injected back into its placeholder - see notices/content.php.
 *
 * This template can be overridden by copying it to yourtheme/free-gifts-for-woocommerce/notices/progress-bar.php
 *
 * To maintain compatibility, Free Gifts for WooCommerce will update the template files and you have to copy the updated files to your theme.
 *
 * @since 13.8.0
 * @var $progress contains the eligible notice progress data (percentage, and the
 *                labels the percentage, the current value and the target are printed with)
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( empty( $progress ) ) {
	return;
}
?>
<span class='fgf-eligible-notice-progress-bar-wrapper'>
	<?php if ( ! empty( $progress['percentage_label'] ) ) : ?>
		<span class='fgf-eligible-notice-progress-bar-percentage'><?php echo esc_html( $progress['percentage_label'] ); ?></span>
	<?php endif; ?>
	<span class='fgf-eligible-notice-progress-bar-outer'>
		<span class='fgf-eligible-notice-progress-bar-fill' style='width:<?php echo esc_attr( $progress['percentage'] ); ?>%;'></span>
	</span>
	<span class='fgf-eligible-notice-progress-bar-labels'>
		<span class='fgf-eligible-notice-progress-bar-current'><?php echo wp_kses_post( $progress['current_label'] ); ?></span>
		<span class='fgf-eligible-notice-progress-bar-separator'> / </span>
		<span class='fgf-eligible-notice-progress-bar-target'><?php echo wp_kses_post( $progress['target_label'] ); ?></span>
	</span>
</span>
