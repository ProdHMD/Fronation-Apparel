=== Free Gifts for WooCommerce ===
Contributors: Flintop
Tags: woocommerce free gifts, free gifts plugin, gift plugin, buy one get one plugin, free gift coupons plugin, notices plugin
Requires at least: 6.2
WC requires at least: 8.2.0
Tested up to: 7.1
WC tested up to: 11.0.1
Requires PHP: 7.4.0
Stable tag: 13.7.0
