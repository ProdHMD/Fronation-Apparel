=== Free Gifts for WooCommerce ===
Contributors: Flintop
Tags: woocommerce free gifts, free gifts plugin, gift plugin
Requires at least: 4.6.0
Tested up to: 6.4.1
Tested up to WC: 8.3.1
Requires PHP: 5.6.0
Stable tag: 10.7.0
