=== Free Gifts for WooCommerce ===
Contributors: Flintop
Tags: woocommerce free gifts, free gifts plugin, gift plugin, buy one get one plugin, free gift coupons plugin, notices plugin
Requires at least: 6.2
WC requires at least: 8.2.0
Tested up to: 6.9
WC tested up to: 10.4.2
Requires PHP: 7.4.0
Stable tag: 12.8.0