=== Free Gifts for WooCommerce ===
Contributors: Flintop
Tags: woocommerce free gifts, free gifts plugin, gift plugin, buy one get one plugin, free gift coupons plugin, notices plugin
Requires at least: 4.6.0
Tested up to: 6.6.1
Tested up to WC: 9.2.3
Requires PHP: 5.6.0
Stable tag: 11.5.0
